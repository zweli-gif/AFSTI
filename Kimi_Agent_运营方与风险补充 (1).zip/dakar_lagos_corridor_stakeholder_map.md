# DAKAR-LAGOS CORRIDOR PLAY: COMPREHENSIVE STAKEHOLDER MAP
## AFSTI Project - Investment Components: Aquaculture, Cold Chain, Tomato Processing, Trade Finance, Border Facilitation

---

## 1. GOVERNMENT BODIES BY COUNTRY

### CÔTE D'IVOIRE (PEA: AMBER-GREEN - Best Positioned)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture, Rural Development & Food Production (MINADER)** | Lead agricultural policy; PSTACI program oversight | HIGH | HIGH | Primary government partner; PSTACI alignment critical |
| **Ministry of Animal & Fisheries Resources (MIRAH)** | Aquaculture regulation, broodstock programs | HIGH | HIGH | Key partner for ProDeCAP; hatchery licensing |
| **Centre de Promotion des Investissements en Côte d'Ivoire (CEPICI)** | Investment promotion; business facilitation | HIGH | HIGH | Entry point for investors; 48-hour company registration |
| **PSTACI (Strategic Program for Aquaculture Transformation)** | $1.3B flagship program; 30 ZEAD zones | VERY HIGH | VERY HIGH | CORE PARTNER - existing relationship |
| **CNRA (National Center for Agricultural Research)** | Broodstock genetics; aquaculture R&D | HIGH | MEDIUM | Technical partner with WorldFish |
| **ZEAD Zone Authorities** | Zone management; investor facilitation | HIGH | HIGH | Critical for site selection |
| **Customs Administration (DGD)** | Border clearance; ETLS implementation | MEDIUM | HIGH | Trade facilitation coordination |
| **Ministry of Transport** | Corridor infrastructure; logistics | MEDIUM | MEDIUM | Cold chain infrastructure alignment |

### GHANA (PEA: AMBER - Stable)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Food and Agriculture (MoFA)** | Agricultural policy; tomato program | HIGH | HIGH | Key partner for tomato processing initiative |
| **Ministry of Trade, Agribusiness & Industry** | Trade policy; industrial development | HIGH | HIGH | Tomato value chain coordination |
| **Ghana Free Zones Authority (GFZA)** | EPZ regulation; investment incentives | MEDIUM | HIGH | Cold chain facility incentives |
| **Ghana Shippers' Authority** | Trade facilitation; logistics | MEDIUM | MEDIUM | Corridor efficiency improvements |
| **Ghana Customs (GRA)** | Border management; revenue collection | MEDIUM | HIGH | ETLS implementation; trade facilitation |
| **Ghana Investment Promotion Centre (GIPC)** | Investor support; aftercare | HIGH | MEDIUM | Entry facilitation |
| **Chamber of Agribusiness Ghana (CAG)** | Private sector advocacy | HIGH | MEDIUM | Market intelligence; stakeholder engagement |

### NIGERIA (PEA: AMBER - Border Policy Volatility; Huge Demand)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Federal Ministry of Agriculture & Food Security** | National ag policy; food security | HIGH | HIGH | Policy alignment; import substitution goals |
| **Federal Ministry of Marine & Blue Economy** | Fisheries/aquaculture oversight | HIGH | HIGH | Growing priority under new ministry |
| **Federal Ministry of Industry, Trade & Investment** | Trade policy; industrial development | HIGH | HIGH | Market access; processing incentives |
| **Nigeria Customs Service (NCS)** | Border control; trade facilitation | HIGH | VERY HIGH | CRITICAL - modernization underway |
| **Nigerian Investment Promotion Commission (NIPC)** | Investment attraction; aftercare | HIGH | MEDIUM | Entry point for investors |
| **Nigerian Shippers' Council (NSC)** | Port/transport regulation | MEDIUM | MEDIUM | Corridor coordination |
| **Central Bank of Nigeria (CBN)** | Aquaculture financing; Anchor Borrowers | HIGH | HIGH | Trade finance facility potential |
| **Standards Organisation of Nigeria (SON)** | Product standards; quality control | MEDIUM | MEDIUM | Cold chain compliance |

### SENEGAL (PEA: AMBER - Rice Focus; Aquaculture Secondary)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture, Food Sovereignty & Livestock** | Agricultural policy; rice priority | MEDIUM | HIGH | Aquaculture as secondary priority |
| **Ministry of Fisheries & Maritime Economy** | Fisheries/aquaculture regulation | HIGH | HIGH | Growing focus on blue economy |
| **APIX (Investment Promotion Agency)** | Investment facilitation; SEZ management | HIGH | HIGH | Primary entry point; SEZ opportunities |
| **Senegal Customs** | Border management | MEDIUM | HIGH | ETLS implementation |
| **Dakar Chamber of Commerce (CCIAD)** | Business advocacy; networking | MEDIUM | MEDIUM | Private sector linkages |
| **Ministry of Infrastructure & Transport** | Corridor development | MEDIUM | MEDIUM | Dakar port logistics |

### BURKINA FASO (PEA: AMBER-RED - Security + ECOWAS Exit Risk)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture & Hydro-Agricultural Development** | Agricultural policy | MEDIUM | MEDIUM | Limited engagement due to ECOWAS exit |
| **Burkina Faso Customs** | Border control | MEDIUM | MEDIUM | Trade route complications |
| **Investment Promotion Agency** | Investor support | LOW | LOW | Monitor only - high risk |
| **National Rice Program** | Rice production focus | LOW | MEDIUM | Limited corridor relevance |

### MALI (PEA: AMBER-RED - Conflict; ECOWAS Exit)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture** | Agricultural policy | LOW | LOW | Monitor only - conflict zone |
| **Mali Customs** | Border management | LOW | LOW | Limited corridor access |
| **Investment Promotion Agency** | Investor support | LOW | LOW | High security risk |

---

## 2. REGIONAL BODIES

| Organization | Mandate | Relevance to Corridor | Current Programs | Engagement Priority |
|--------------|---------|----------------------|------------------|---------------------|
| **ECOWAS Commission** | Regional economic integration; trade liberalization | VERY HIGH - Core framework for corridor | ETLS (Trade Liberalization Scheme), EATM Scorecard, ECOWAP | VERY HIGH - Primary regional partner |
| **UEMOA/WAEMU** | Monetary union; customs coordination | HIGH - 8 member states including CIV | Common External Tariff; agricultural harmonization | HIGH - Currency stability |
| **AfCFTA Secretariat** | Continental free trade implementation | HIGH - Long-term market access | Guided Trade Initiative; Agri-Food Trade Action Plan | HIGH - Future expansion |
| **CORAF** | Agricultural research coordination | HIGH - Technology & innovation | TARSPro project; seed systems; post-harvest research | MEDIUM - Technical partner |
| **CILSS** | Food security; drought monitoring | MEDIUM - Sahel focus | Food System Resilience Program | MEDIUM - Coordination |
| **Alliance of Sahel States (AES)** | New bloc (Burkina, Mali, Niger) | NEGATIVE - Disrupts corridor | None relevant | MONITOR - Creates complications |

### ECOWAS Exit Complications (Burkina Faso, Mali, Niger - Effective January 2025)

**Key Implications:**
- Exit from ETLS (Trade Liberalization Scheme) - tariff barriers reinstated
- Loss of free movement protocols for goods and people
- Customs union disruption - WTO MFN rates apply
- Community levy (0.5%) on goods from AES countries
- 60% of Burkina vegetable exports to Ghana/CIV now face tariffs
- 90% of Burkina live animal exports affected
- Transit route complications for corridor goods

**ECOWAS Response (Grace Period until July 2025):**
- Continued recognition of passports/ID cards
- Goods still treated under ETLS temporarily
- Visa-free movement maintained
- Structure established for future engagement discussions

---

## 3. DEVELOPMENT FINANCE INSTITUTIONS

| DFI | Current Africa Ag Programs | Likely Role | Ticket Size | Engagement Status |
|-----|---------------------------|-------------|-------------|-------------------|
| **AfDB (African Development Bank)** | ProDeCAP ($25.6M CIV aquaculture); Feed Africa Strategy | LEAD DFI - anchor investor | $10-75M | ACTIVE - ProDeCAP partnership |
| **IFC (World Bank Group)** | Agribusiness value chains; SME finance | Co-investor; trade finance | $5-25M | POTENTIAL - corridor alignment |
| **Finnfund** | Sustainable agriculture; food security | Co-investor; aquaculture specialist | $5-15M | AVAILABLE - ag focus |
| **Norfund** | Agribusiness; value chain development | Co-investor | $5-15M | AVAILABLE - Africa focus |
| **BII (British International Investment)** | CASA program; agribusiness | Technical assistance; co-investment | $5-20M | POTENTIAL - CASA Plus alignment |
| **FMO (Dutch Development Bank)** | Agribusiness, Food & Water sector | Syndicated financing | $5-20M | AVAILABLE - West Africa active |
| **Proparco (France)** | Agriculture; climate finance | Co-investor; value chains | $5-15M | AVAILABLE - CIV presence |
| **DEG (Germany)** | Sustainable agriculture | Syndicated financing | $5-15M | AVAILABLE - Valency precedent |

### DFI Consortium Opportunity

**Existing Relationships:**
- AfDB (lead) - ProDeCAP partnership
- Finnfund - active agribusiness portfolio (€71.6M in 2024)
- Norfund - expanding Africa ag investments
- IFC - West Africa trade finance programs
- BII - CASA Plus technical assistance facility

**Potential Syndicated Structure:**
- Total Facility: $75-100M
- AfDB anchor: $25-30M
- IFC participation: $15-20M
- European DFIs (Finnfund, Norfund, FMO, Proparco, DEG): $30-40M
- BII technical assistance: $3-5M

---

## 4. PRIVATE SECTOR ASSOCIATIONS

| Association | Scope | Member Base | Relevance | Engagement Approach |
|-------------|-------|-------------|-----------|---------------------|
| **WACTAF** | West African cross-border trade in agro-forestry-fisheries | Cross-border traders; transporters | VERY HIGH - Corridor trade specialist | KEY PARTNER - trade facilitation |
| **FEWACCI** | Federation of West African Chambers of Commerce | 15 national chambers | HIGH - Business advocacy | Policy dialogue; private sector engagement |
| **ROPPA** | West African farmer organizations | 13 national farmer orgs + Nigeria | HIGH - Farmer representation | Smallholder integration; farmer voice |
| **Chamber of Agribusiness Ghana (CAG)** | Ghana agribusiness sector | Agribusiness companies | MEDIUM - Tomato value chain | Market intelligence; processor linkages |
| **National Fisheries Associations** | Country-level (CIV, Ghana, Nigeria) | Fish farmers; processors | HIGH - Aquaculture sector | Value chain coordination |
| **Cold Chain Associations** | National logistics/cold storage | Logistics providers | HIGH - ColdChainCo component | Technical standards; facility development |
| **De Heus/Koudijs** | Feed manufacturing | Commercial feed producers | HIGH - Feed supply | Existing partner - 120K MT factory |
| **Lagos Offtakers** | Wholesale distribution | Fish/tomato distributors | HIGH - Market access | Existing partnership |

### WACTAF (West African Association for Cross-Border Trade)

**Key Details:**
- Focus: Agro-forestry-pastoral, fisheries products, food
- Role: Trade facilitation; informal trade data collection (ECO-ICBT platform)
- Partners: ECOWAS, CILSS, GIZ EAT program
- Relevance: Critical for border facilitation component
- Engagement: Workshop participation; trader training; data sharing

### ROPPA (Network of Peasant Organizations and Producers of West Africa)

**Key Details:**
- Members: 13 national farmer organizations + Nigeria (associate)
- Headquarters: Ouagadougou, Burkina Faso
- Focus: Family farming; smallholder inclusion; policy advocacy
- Structure: Regional colleges for women, youth; sectoral frameworks (rice, cereals, fisheries, livestock)
- Relevance: Smallholder integration; farmer organization partnerships

---

## 5. CIVIL SOCIETY & FARMER ORGANIZATIONS

| Organization | Focus | Geographic Coverage | Influence | Role in Project |
|--------------|-------|---------------------|-----------|-----------------|
| **ROPPA** | Family farming; smallholder rights | 15 West African countries | HIGH - Farmer voice | Smallholder inclusion; farmer organization capacity |
| **West Africa Civil Society Institute (WACSI)** | Civil society strengthening | ECOWAS region | MEDIUM | Stakeholder engagement; community consultation |
| **National Farmer Cooperatives** | Country-level producer groups | Per country | MEDIUM | Input supply; aggregation; extension |
| **Women's Agricultural Networks** | Gender in agriculture | National/regional | MEDIUM | Women's economic empowerment |
| **Consumer Associations** | Food safety; consumer rights | National | LOW-MEDIUM | Market standards advocacy |
| **Environmental NGOs** | Sustainability; climate | National/regional | MEDIUM | ESG compliance; environmental monitoring |
| **FISON (Fisheries Society of Nigeria)** | Fisheries/aquaculture advocacy | Nigeria | MEDIUM | Technical support; farmer linkages |

### Women's Economic Empowerment Focus

**Key Considerations:**
- Women comprise 70% of cross-border traders (informal sector)
- ROPPA has dedicated Regional College for Women
- WACTAF focuses on gender-sensitive trade facilitation
- GIZ EAT program provides exclusive training for female traders
- Project should prioritize women's participation in:
  - Cold chain operations
  - Aquaculture processing
  - Trade finance access
  - Border trade activities

---

## 6. STAKEHOLDER INFLUENCE MATRIX

### 2x2 Matrix: INTEREST vs INFLUENCE

```
                    HIGH INFLUENCE
                           |
        KEEP SATISFIED     |     KEY PLAYERS
        (High Interest/    |     (High Interest/
         High Influence)    |      High Influence)
                           |
    • PSTACI (CIV)         |     • AfDB (Lead DFI)
    • ECOWAS Commission    |     • CIV Government
    • CEPICI               |     • ProDeCAP Partners
    • WACTAF               |     • ECOWAS (Trade Directorate)
    • Lagos Offtakers      |     • De Heus/Koudijs
    • CNRA/WorldFish       |     • WACTAF
                           |
--------------------------|--------------------------
                           |
        MONITOR            |     KEEP INFORMED
        (Low Interest/      |     (High Interest/
         High Influence)    |      Low Influence)
                           |
    • UEMOA/WAEMU          |     • ROPPA
    • AfCFTA Secretariat   |     • Farmer Cooperatives
    • CORAF                |     • Cold Chain Associations
    • Senegal Government   |     • Environmental NGOs
    • Standards Bodies     |     • Women's Networks
    • DFI Consortium       |     • Consumer Associations
                           |
                    LOW INFLUENCE
```

### KEY PLAYERS (Manage Closely)

| Stakeholder | Engagement Strategy | Frequency | Responsible |
|-------------|---------------------|-----------|-------------|
| **AfDB** | Regular coordination; syndication discussions | Weekly | Investment Lead |
| **CIV Government (MINADER/MIRAH)** | Formal partnership; PSTACI alignment | Monthly | Government Relations |
| **PSTACI** | Program integration; reporting | Bi-weekly | Program Manager |
| **ProDeCAP Partners** | Technical coordination | Monthly | Technical Lead |
| **ECOWAS Trade Directorate** | Policy alignment; ETLS optimization | Quarterly | Policy Advisor |
| **WACTAF** | Border facilitation; trader engagement | Monthly | Trade Facilitation Lead |
| **De Heus/Koudijs** | Feed supply coordination | Quarterly | Supply Chain Manager |

### KEEP SATISFIED (Monitor & Engage)

| Stakeholder | Engagement Strategy | Frequency |
|-------------|---------------------|-----------|
| **CEPICI** | Investment facilitation; regulatory support | Quarterly |
| **Ghana Government (MoFA)** | Tomato program alignment | Quarterly |
| **Nigeria Customs** | Trade facilitation; modernization | Quarterly |
| **FEWACCI** | Private sector dialogue | Bi-annually |
| **CNRA/WorldFish** | Technical support; broodstock | Quarterly |
| **Lagos Offtakers** | Market access; offtake agreements | Monthly |

### KEEP INFORMED (Regular Updates)

| Stakeholder | Engagement Strategy | Frequency |
|-------------|---------------------|-----------|
| **ROPPA** | Farmer organization updates; consultation | Quarterly |
| **Farmer Cooperatives** | Extension services; input programs | Monthly |
| **Cold Chain Associations** | Standards; facility development | Quarterly |
| **Women's Networks** | Gender program updates | Quarterly |
| **Environmental NGOs** | ESG reporting; sustainability | Bi-annually |

### MONITOR (Watch & Respond)

| Stakeholder | Monitoring Focus |
|-------------|------------------|
| **AfCFTA Secretariat** | Continental trade policy developments |
| **UEMOA/WAEMU** | Currency stability; CET changes |
| **Alliance of Sahel States** | ECOWAS exit implications; trade disruptions |
| **CORAF** | Research innovations; technology transfer |
| **Senegal Government** | Regional aquaculture developments |

---

## 7. STAKEHOLDER ENGAGEMENT ROADMAP

### Phase 1: Foundation (Months 1-3)

**Priority Actions:**
1. Formalize AfDB partnership (ProDeCAP coordination)
2. Sign MOU with PSTACI/CIV Government
3. Engage WACTAF for border baseline assessment
4. Establish DFI consortium working group
5. Conduct stakeholder mapping workshops in each country

**Key Deliverables:**
- Partnership agreements with CIV Government
- DFI term sheets
- Border facilitation assessment report
- Stakeholder engagement plan

### Phase 2: Implementation (Months 4-12)

**Priority Actions:**
1. Launch aquaculture investments (CIV)
2. Implement cold chain facilities
3. Roll out tomato processing (Ghana)
4. Activate trade finance facility
5. Deploy border facilitation measures

**Key Deliverables:**
- Operational hatcheries (ProDeCAP)
- Cold chain infrastructure
- Processing plant commissioning
- First trade finance disbursements
- Border time reduction metrics

### Phase 3: Scale (Months 13-24)

**Priority Actions:**
1. Expand aquaculture to additional ZEAD zones
2. Scale cold chain network
3. Integrate regional trade flows
4. Optimize border processes
5. Evaluate impact and refine

**Key Deliverables:**
- Regional aquaculture network
- Integrated cold chain corridor
- Increased intra-regional trade volumes
- Reduced border crossing times
- Impact assessment report

---

## 8. RISK FACTORS & MITIGATION

### Political Economy Risks

| Risk | Stakeholders Affected | Mitigation Strategy |
|------|----------------------|---------------------|
| ECOWAS exit disruption (Burkina/Mali) | Trade flows; border operations | Focus on coastal corridor (CIV-Ghana-Nigeria); monitor AES developments |
| Border policy volatility (Nigeria) | Trade finance; logistics | Diversify routes; strong customs relationship; insurance coverage |
| Election cycles (Ghana 2024/CIV 2025) | Government continuity | Multi-stakeholder engagement; institutionalize partnerships |
| Security concerns (Sahel) | Regional expansion | Coastal focus; security assessments; phased approach |

### Stakeholder-Related Risks

| Risk | Mitigation |
|------|------------|
| DFI coordination challenges | Clear lead arranger; syndication agreement; regular coordination |
| Government partner turnover | Institutional MOUs; multi-level engagement; political risk insurance |
| Private sector buy-in | Early engagement; demonstration projects; profit-sharing models |
| Farmer organization capacity | Technical assistance; training; gradual integration |

---

## 9. SUMMARY: CRITICAL STAKEHOLDER PRIORITIES

### Tier 1: Essential Partners (Must Engage)
1. **AfDB** - Lead DFI; ProDeCAP anchor
2. **CIV Government (MINADER/MIRAH/PSTACI)** - Host government; program alignment
3. **ECOWAS Commission** - Regional framework; ETLS
4. **WACTAF** - Border facilitation; trader networks
5. **De Heus/Koudijs** - Feed supply; existing partner

### Tier 2: Important Partners (Should Engage)
1. **Ghana Government (MoFA)** - Tomato program
2. **Nigeria Customs** - Trade facilitation
3. **DFI Consortium** (IFC, Finnfund, Norfund, BII, FMO, Proparco, DEG)
4. **FEWACCI** - Private sector advocacy
5. **ROPPA** - Farmer representation
6. **CNRA/WorldFish** - Technical support

### Tier 3: Supporting Partners (Monitor & Engage as Needed)
1. **AfCFTA Secretariat** - Long-term continental integration
2. **CORAF** - Research and innovation
3. **UEMOA** - Monetary coordination
4. **Cold Chain Associations** - Technical standards
5. **Environmental NGOs** - ESG compliance

---

*Document prepared for AFSTI Dakar-Lagos Corridor Play*
*Stakeholder mapping current as of research date*
*Recommend quarterly updates to reflect changing dynamics*

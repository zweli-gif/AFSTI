# DATA EXTRACTION PROMPT — Dakar-Lagos Corridor Play
## WITH LIKELY PLAYERS, KEY STAKEHOLDERS & COMPREHENSIVE RISKS

---

## INSTRUCTIONS FOR BUILDER

This document contains ALL data needed to build the interactive HTML dashboard for the Dakar-Lagos Corridor Play, including:
- Original 18 data tables (financials, metrics, timelines)
- **NEW: TABLE 19 - LIKELY PLAYERS TO OPERATE**
- **NEW: TABLE 20 - KEY STAKEHOLDERS**
- **NEW: TABLE 21 - COMPREHENSIVE RISK ANALYSIS**

The output should be a single markdown document with clearly labeled tables, ready for HTML implementation.

---

## CONTEXT

We are building an integrated "Corridor Play" for the AFSTI project's Dakar-Lagos corridor. This bundles multiple value chain investment cases (aquaculture, tomato, palm oil) + enabling investments (cold chain, trade finance, border facilitation) into ONE investable thesis.

The hero IC is CIV aquaculture (tilapia). The spine enabler is ColdChainCo (multi-commodity cold chain).

The thesis: ColdChainCo is the shared infrastructure that makes ALL commodity ICs bankable. Aquaculture alone justifies Hub 1, but tomato + palm oil + poultry volumes de-risk utilisation and create a platform worth $3B+ in addressable trade.

---

## ORIGINAL DATA TABLES (1-18)

[Tables 1-18 remain as in the original document - see DAKAR_LAGOS_DATA_EXTRACTION_PROMPT.md]

---

## NEW TABLE 19: LIKELY PLAYERS TO OPERATE

### Executive Summary: Tier 1 Recommended Operators

| Component | Recommended Operator | Operator Type | Key Strength |
|-----------|---------------------|---------------|--------------|
| **Hatchery** | ProDeCAP/AfDB + CNRA + WorldFish | PPP + Technical | $25.6M existing funding; GIFT genetics expertise |
| **Feed** | **De Heus/Koudijs** (Existing Partner) | International | Abidjan 120K MT factory operational since 2023 |
| **Anchor Farm** | **Tropo Farms** (Ghana) | Regional | Largest West Africa tilapia; $10M AgDevCo backing; explicit expansion plans |
| **Processing** | Integrated with Anchor Farm | Vertical | Quality control; traceability; margin capture |
| **Border/Reefer** | **AGL (MSC Group)** | International | 100+ years Africa; existing cold infrastructure at Abidjan |
| **Cold Hub Abidjan** | AGL + IPF Partnership | Mixed | Scale + local expertise; 120K ton capacity |
| **Cold Hub Sèmè-Kraké** | AGL + Benin operator | Regional | Cross-border expertise; ECOWAS transit experience |
| **Reefer Fleet** | EFAfrica + local operators | Leasing/Local | AgDevCo portfolio; equipment leasing expertise |
| **Ghana Tomato** | **GBfoods Africa** | International | $5M Tema facility; 2,428 hectares secured; rapid expansion |
| **Palm Oil Milling** | **SIFCA/PalmCI + Wilmar** | Regional/Int'l | Dominant CIV player; 27,000 village planters; 10 mills |

---

### 19.1 AQUACULTURE OPERATORS

#### Hatchery ($3-5M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Hatchery (Public Good) | **Public-Private Partnership** | **ProDeCAP / AfDB + CNRA + Private Operator** | ProDeCAP already funded ($25.6M); CNRA has genetic program; requires private efficiency | ProDeCAP approved 2024-2030; CNRA breeding nucleus; WorldFish GIFT in 17 countries | Critical fit - public good with commercial sustainability |
| Hatchery | **International Technical Partner** | **WorldFish Center** | Manages GIFT genetics globally; established African programs | GIFT in 17 countries; 28 years selective breeding; 10-15% gains per generation | Essential for genetic quality assurance |
| Hatchery | **Regional Operator** | **Victory Farms (Kenya)** | Successful hatcheries in Kenya/Rwanda; innovative HEAP outgrower model | 18,000 MT annual; vertically integrated; ASC improver program | Technical consultancy/JV potential |
| Hatchery | **Local Private Operator** | **Emerging CIV Entrepreneur (500+ MT)** | Local market understanding; existing farmer relationships | Several operators producing 500-1,000 MT in CIV | Local ownership; long-term sustainability |

#### Feed Partnership ($2-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Feed Partnership | **International Feed Major (EXISTING)** | **De Heus / Koudijs (Netherlands)** | 120K MT factory inaugurated Abidjan 2023; committed to Ivorian aquaculture | EUR multi-million investment; 75+ countries; established distribution | **EXISTING PARTNER** - Natural fit |
| Feed Partnership | **Alternative International** | **Skretting (Nutreco)** | World's largest aquafeed producer; Africa presence (Egypt, Nigeria) | 2M+ MT annual; 19 countries; 60+ species; expanded Nigeria operations | Alternative if De Heus unavailable |
| Feed Partnership | **Alternative International** | **Cargill/EWOS** | Major aquafeed player; expanding emerging market presence | 80+ years EWOS experience; strong R&D; global supply chain | Specialized formulations |
| Feed Partnership | **Regional Model** | **Victory Farms Feed Mill JV (Kenya)** | Successful feed mill JV in Kenya; produces at scale | Produces for 18,000 MT; vertically integrated; AgDevCo supported | Technical assistance potential |

#### Anchor Farm + Outgrowers ($5-8M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Anchor Farm | **International Proven (EXISTING)** | **Yalelo (Zambia/Uganda) - First Wave Group** | Largest freshwater fish producer in SSA (18K MT); proven DFI relationships ($18M); 5-country export | 18,000 MT; 1,500 employees; $84M project financing; gender-focused | **EXISTING CANDIDATE** - Proven at scale |
| Anchor Farm | **Regional West Africa (EXISTING)** | **Tropo Farms (Ghana)** | Largest tilapia producer in West Africa; $10M AgDevCo for expansion to 30K MT; explicit West Africa expansion | 15,000 MT → 30K MT; 917 employees; 3,000 market traders (majority women) | **STRONGEST FIT** - Regional leader; expansion interest |
| Anchor Farm | **East Africa Fast-Grower** | **Victory Farms (Kenya)** | Fastest-growing tilapia farm in SSA; 18K MT; innovative outgrower schemes | 18,000 MT; 750+ employees; 15,000+ market women; HEAP program | Strong outgrower model |
| Anchor Farm | **Southern Africa Integrated** | **Lake Harvest (Zimbabwe/Zambia/Uganda)** | Largest integrated tilapia operation in Africa; indigenous breeding focus; multi-country | Operations in 6 African countries; cage farming; premium quality | Technical expertise |
| Anchor Farm | **Local Private/Cooperative** | **CIV Cooperative (50-100 farmers near ZEAD)** | PSTACI developing 30 ZEAD zones; existing farmer relationships; government support | FISH4ACP supporting cooperatives; CNRA technical support | Critical for outgrower success |
| Anchor Farm | **Local Entrepreneur** | **Emerging CIV 500+ MT Operator** | Several operators achieving commercial scale; local market knowledge | Multiple operators at 500-1,000 MT; established buyer relationships | Growth candidates |

#### Processing Facility ($3-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Processing | **Anchor Farm Integrated** | **Tropo Farms / Yalelo / Victory Farms** | Major operators vertically integrated; Tropo building modern facility with AgDevCo | Tropo: 30K MT capacity facility; Yalelo: full lifecycle; Victory Farms: processing + retail | Natural fit - quality and traceability |
| Processing | **Regional Fish Processor** | **Mr Fish Processing Hub (Ghana/Uganda)** | Specialized freshwater fish processor; Ghana and Uganda operations; export experience | Tilapia fillets, whole fish, value-added; HACCP compliance; air/sea freight | Established African processor |
| Processing | **Local CIV Processor** | **IPF Commercial Logistics Park (Abidjan)** | Chinese-invested facility near Port of Abidjan; 120,000 ton cold storage; blast freezing | 12 hectare park; 2 low-temp warehouses; 1,000 sqm fast-freezing; seafood focus | Existing cold chain; port proximity |
| Processing | **International Processor** | **Pioneer Food Cannery (Ghana) / GIHOC** | Established Ghanaian fish processors; canning and freezing; export experience | Major Ghanaian processor; state-owned experience | Technical partnership |

#### Border + Reefer Operations ($3-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Border/Reefer | **International Logistics Major** | **AGL (Africa Global Logistics) - MSC Group** | Largest logistics operator in Africa; 21,000 employees; 49 countries; cold storage expertise | 100+ years Africa; tri-temperature platform Abidjan airport (6,000 sqm); bonded warehousing | **STRONGEST CANDIDATE** - Established cold chain |
| Border/Reefer | **Global Port Operator** | **DP World** | Major West Africa port operator; developing $1.2B Ndayane Port; cold chain capabilities | $1.2B Ndayane Port; cold storage Dakar; reefer expansion (450→715 plugs Maputo) | Port and logistics capabilities |
| Border/Reefer | **International Freight Forwarder** | **Kuehne+Nagel** | Expanded Africa network to 18 countries; healthcare/pharma cold chain; perishables focus | OR Tambo airside facility; temperature-controlled pharma; cold chain solutions | Cold chain credentials |
| Border/Reefer | **International Express** | **DHL Group** | EUR 300M+ investment Sub-Saharan Africa; cold chain and perishables logistics | GDP-certified healthcare facilities; expanding agricultural cold chain; digital customs | Strong investment commitment |
| Border/Reefer | **Shipping Line Reefer** | **Maersk / CMA CGM** | Major container lines with reefer fleets; Maersk investing $100M+ South African cold chain | Belcon, Cato, PreCool facilities; global reefer fleet; West Africa routes | Container capabilities |
| Border/Reefer | **Local West African Operator** | **Benin/Ghana Transport Cooperatives** | Established cross-border relationships; lower cost structure; community connections | Established trucking networks; ECOWAS cross-border experience | Last-mile distribution |

---

### 19.2 COLDCHAINCO OPERATORS

#### Hub 1: Abidjan Port Zone ($5-7M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Cold Hub Abidjan | **International Logistics Major** | **AGL (Africa Global Logistics)** | Existing tri-temperature facility at Abidjan airport (Aerohub - 6,000 sqm); expanding to 9,000 sqm | Aerohub: 3,500 sq m warehouse with cold room; bonded area; EDGE certified; intelligent temperature control | **STRONGEST CANDIDATE** - Existing infrastructure |
| Cold Hub Abidjan | **Chinese Infrastructure Investor** | **IPF Commercial Logistics Park** | 12-hectare facility near Port of Abidjan; 120,000 ton capacity; 2 low-temp warehouses; blast-freezing | 120,000 ton processing/storage; 3 x 5,000 sqm warehouses; fast-freezing production line | Large-scale cold storage; blast freezing |
| Cold Hub Abidjan | **Port Terminal Operator** | **APM Terminals + AGL JV** | APM Terminals operates Abidjan container terminal; JV with AGL for equipment; expanding capacity | Modern terminal equipment; reefer container handling; port logistics integration | Port integration |
| Cold Hub Abidjan | **Local Private Operator** | **SOTRA / Local Cold Storage Operators** | Local market understanding; established customer relationships; government relationships | Existing cold storage in Abidjan; serving local market | Potential JV partners |

#### Hub 2: Sèmè-Kraké Border Buffer ($3-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Cold Hub Seme-Krake | **Regional Logistics Operator** | **AGL Border Logistics** | Extensive West Africa border operations; ECOWAS transit experience; customs expertise | Cross-border operations throughout West Africa; customs clearing; bonded transport | Established border logistics |
| Cold Hub Seme-Krake | **Benin National Operator** | **Benin Logistics Company (State/Private JV)** | Benin vested interest in border efficiency; Seme-Krake critical trade corridor; local knowledge | Seme-Krake major Benin-Nigeria border; government investment in border infrastructure | Local ownership; government support |
| Cold Hub Seme-Krake | **Nigeria-Benin Cross-Border Operator** | **Nigerian Logistics Companies with Benin Operations** | Nigerian operators understand Lagos market; established relationships; last-mile delivery | Lagos-based distributors; cross-border experience; market women networks | Market access |
| Cold Hub Seme-Krake | **Cold Chain Specialist** | **DHL / Kuehne+Nagel Border Solutions** | International operators have border clearance expertise; temperature monitoring; compliance | Cross-border cold chain solutions; customs expertise; tracking systems | Technical expertise |

#### Reefer Fleet: 10-15 Trucks ($2-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Reefer Fleet | **International Logistics Leasing** | **EFAfrica Group (AgDevCo Portfolio)** | Equipment leasing company for African agriculture; $7.2M AgDevCo follow-on; 1,500+ entrepreneurs | 1,500+ lessee entrepreneurs across Kenya, Tanzania, Zambia; trucks and tractors focus; typical lease $10K-$80K | AgDevCo relationship; agricultural focus |
| Reefer Fleet | **Regional Transport Operator** | **West African Transport Companies** | Established trucking companies with reefer capabilities; ECOWAS cross-border experience | Reefer trucking in West Africa; cross-border permits; established routes | Local expertise; cost efficiency |
| Reefer Fleet | **International Leasing** | **Equipment Leasing Companies (Caterpillar, etc.)** | Major equipment manufacturers have African leasing arms; modern reefer trucks; maintenance support | Equipment leasing across Africa; technical support; maintenance networks | Modern equipment; reliability |
| Reefer Fleet | **Local Cooperative Model** | **Transport Cooperatives / Owner-Driver Networks** | Lower capital requirement; local ownership; flexible operations | Truck owner associations; cooperative models; established in West Africa | Local employment; community integration |

---

### 19.3 GHANA TOMATO OPERATORS

#### Processing Facilities ($8-15M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Tomato Processing | **International Food Major (STRONGEST)** | **GBfoods Africa (Spain)** | Commissioned $5M Tema facility (2023); secured 2,428 hectares Afram Plains (2026); Gino and Pomo brands; "seed-to-shelf" strategy | $5M Tema facility operational; 2,428 hectares secured (3x Nigeria farm); yields improved to 60-70 tonnes/acre Nigeria; targeting 40 tonnes/acre Ghana | **STRONGEST CANDIDATE** - Already invested; rapid expansion |
| Tomato Processing | **Local Ghanaian Processor** | **Trusty Foods / Expom Ghana Ltd** | Established 2003 in Tema; supplies West African market; sources some Ghana tomatoes | Tema processing facility; West African market supply; 7% Ghana fresh tomatoes, 93% bulk paste imports | Existing facility; market relationships |
| Tomato Processing | **Revived State Facility** | **Northern Star Tomato Company (Pwalugu)** | Former state tomato factory refurbished 2006-2007; reopened 2010; configured to supply Trusty Foods Tema | Pwalugu factory refurbishment; Ministry of Trade involvement; local tomato sourcing | Government support; production area location |
| Tomato Processing | **Private-Public Partnership** | **Afrique Link Ltd (Wenchi) / TOMACAN** | Former GIHOC cannery; produces natural tomato pulp and chopped tomatoes; niche market focus | Wenchi location in production area; natural pulp/chopped tomatoes; South African technical expertise | Niche product positioning |
| Tomato Processing | **International Agribusiness** | **OLAM / SIFCA (if diversifying)** | Major West African agribusiness players; existing processing capabilities; regional distribution | OLAM: integrated supply chains; SIFCA: palm oil, rubber, sugar processing | Potential diversifiers |

---

### 19.4 PALM OIL CIV OPERATORS

#### Milling Upgrade ($5-10M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Palm Oil Milling | **West Africa Palm Major (STRONGEST)** | **SIFCA Group / PalmCI (Cote d'Ivoire)** | West Africa's largest fully integrated palm player; 39,000 hectares industrial; 27,000 village planters; 10 mills; BRVM-listed | PalmCI: 60% supply from private planters; village plantation rehabilitation program; Dinor and Palme d'Or brands; leading UEMOA market share | **STRONGEST CANDIDATE** - Dominant CIV player; smallholder integration |
| Palm Oil Milling | **International Palm Major** | **Wilmar International (Singapore)** | 27% strategic stake in SIFCA; sources from PalmCI mills; world's largest palm oil trader; African expansion (PZ Wilmar full acquisition) | 27% SIFCA stake; PZ Wilmar full acquisition ($70M); 3 African refineries; 8 refineries through associates | Existing SIFCA relationship; capital for expansion |
| Palm Oil Milling | **International Agribusiness** | **OLAM International (Singapore)** | African palm operations (Gabon); joint venture with Wilmar (Nauvu Investments); 50:50 partnership for African palm, rubber, sugar | 64,000 hectares in Gabon; Nauvu JV with Wilmar; acquired 27% SIFCA stake | Existing African palm presence |
| Palm Oil Milling | **Regional Palm Operator** | **Socfin Group (Luxembourg/Belgium)** | Major African palm player; operations in Cameroon, Cote d'Ivoire, Ghana, Liberia, Nigeria, Sierra Leone; 91,000+ hectares | 91,207 hectares across 7 African countries; 319,289 MT palm oil production; Socapalm Cameroon | Regional expertise; CIV presence |
| Palm Oil Milling | **Cooperative/Outgrower Model** | **PalmCI Village Plantation Program Expansion** | PalmCI already works with 27,000 village planters; 60% supply from private planters; rehabilitation program in place | 133,000 hectares village plantations; 27,000 planters; rehabilitation program | Smallholder integration; rural development |

---

### 19.5 SUMMARY: RECOMMENDED OPERATOR PRIORITIES

#### Tier 1: Strongest Strategic Fit (Immediate Engagement)

| Component | Recommended Operator | Rationale |
|-----------|---------------------|-----------|
| **Hatchery** | ProDeCAP/AfDB + CNRA + WorldFish technical partnership | Public good mandate; existing funding; genetic expertise |
| **Feed** | De Heus/Koudijs (existing partnership) | Abidjan facility operational; partnership framework exists |
| **Anchor Farm** | Tropo Farms (Ghana) | Regional leader; explicit expansion interest; $10M AgDevCo backing |
| **Processing** | Integrated with Anchor Farm (Tropo/Yalelo) | Vertical integration ensures quality and traceability |
| **Border/Reefer** | AGL (MSC Group) | Existing cold infrastructure; port zone presence; border expertise |
| **Cold Hub Abidjan** | AGL + IPF partnership | Complementary capabilities; scale and expertise |
| **Cold Hub Seme-Krake** | AGL border logistics + Benin operator | Cross-border expertise; local knowledge |
| **Reefer Fleet** | EFAfrica (AgDevCo) + local operators | Equipment leasing expertise; local flexibility |
| **Ghana Tomato** | GBfoods Africa | Already invested; rapid expansion; committed to local production |
| **Palm Oil Milling** | SIFCA/PalmCI + Wilmar | Dominant CIV player; existing smallholder integration |

#### Tier 2: Alternative/Backup Options

| Component | Alternative Operators |
|-----------|----------------------|
| Anchor Farm | Yalelo (Zambia), Victory Farms (Kenya), Lake Harvest (Zimbabwe) |
| Feed | Skretting (Nigeria expansion), Cargill/EWOS |
| Cold Chain | DP World, Kuehne+Nagel, DHL |
| Tomato Processing | Trusty Foods/Expom, Northern Star (PPP) |
| Palm Oil | Socfin (regional), OLAM (Gabon expertise) |

---

## NEW TABLE 20: KEY STAKEHOLDERS

### 20.1 GOVERNMENT BODIES BY COUNTRY

#### Côte d'Ivoire (PEA: AMBER-GREEN - Best Positioned)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture, Rural Development & Food Production (MINADER)** | Lead agricultural policy; PSTACI program oversight | HIGH | HIGH | Primary government partner; PSTACI alignment critical |
| **Ministry of Animal & Fisheries Resources (MIRAH)** | Aquaculture regulation, broodstock programs | HIGH | HIGH | Key partner for ProDeCAP; hatchery licensing |
| **Centre de Promotion des Investissements en Côte d'Ivoire (CEPICI)** | Investment promotion; business facilitation | HIGH | HIGH | Entry point for investors; 48-hour company registration |
| **PSTACI (Strategic Program for Aquaculture Transformation)** | $1.3B flagship program; 30 ZEAD zones | VERY HIGH | VERY HIGH | CORE PARTNER - existing relationship |
| **CNRA (National Center for Agricultural Research)** | Broodstock genetics; aquaculture R&D | HIGH | MEDIUM | Technical partner with WorldFish |
| **ZEAD Zone Authorities** | Zone management; investor facilitation | HIGH | HIGH | Critical for site selection |
| **Customs Administration (DGD)** | Border clearance; ETLS implementation | MEDIUM | HIGH | Trade facilitation coordination |
| **Ministry of Transport** | Corridor infrastructure; logistics | MEDIUM | MEDIUM | Cold chain infrastructure alignment |

#### Ghana (PEA: AMBER - Stable)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Food and Agriculture (MoFA)** | Agricultural policy; tomato program | HIGH | HIGH | Key partner for tomato processing initiative |
| **Ministry of Trade, Agribusiness & Industry** | Trade policy; industrial development | HIGH | HIGH | Tomato value chain coordination |
| **Ghana Free Zones Authority (GFZA)** | EPZ regulation; investment incentives | MEDIUM | HIGH | Cold chain facility incentives |
| **Ghana Shippers' Authority** | Trade facilitation; logistics | MEDIUM | MEDIUM | Corridor efficiency improvements |
| **Ghana Customs (GRA)** | Border management; revenue collection | MEDIUM | HIGH | ETLS implementation; trade facilitation |
| **Ghana Investment Promotion Centre (GIPC)** | Investor support; aftercare | HIGH | MEDIUM | Entry facilitation |
| **Chamber of Agribusiness Ghana (CAG)** | Private sector advocacy | HIGH | MEDIUM | Market intelligence; stakeholder engagement |

#### Nigeria (PEA: AMBER - Border Policy Volatility; Huge Demand)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Federal Ministry of Agriculture & Food Security** | National ag policy; food security | HIGH | HIGH | Policy alignment; import substitution goals |
| **Federal Ministry of Marine & Blue Economy** | Fisheries/aquaculture oversight | HIGH | HIGH | Growing priority under new ministry |
| **Federal Ministry of Industry, Trade & Investment** | Trade policy; industrial development | HIGH | HIGH | Market access; processing incentives |
| **Nigeria Customs Service (NCS)** | Border control; trade facilitation | HIGH | VERY HIGH | CRITICAL - modernization underway |
| **Nigerian Investment Promotion Commission (NIPC)** | Investment attraction; aftercare | HIGH | MEDIUM | Entry point for investors |
| **Nigerian Shippers' Council (NSC)** | Port/transport regulation | MEDIUM | MEDIUM | Corridor coordination |
| **Central Bank of Nigeria (CBN)** | Aquaculture financing; Anchor Borrowers | HIGH | HIGH | Trade finance facility potential |
| **Standards Organisation of Nigeria (SON)** | Product standards; quality control | MEDIUM | MEDIUM | Cold chain compliance |

#### Senegal (PEA: AMBER - Rice Focus; Aquaculture Secondary)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Agriculture, Food Sovereignty & Livestock** | Agricultural policy; rice priority | MEDIUM | HIGH | Aquaculture as secondary priority |
| **Ministry of Fisheries & Maritime Economy** | Fisheries/aquaculture regulation | HIGH | HIGH | Growing focus on blue economy |
| **APIX (Investment Promotion Agency)** | Investment facilitation; SEZ management | HIGH | HIGH | Primary entry point; SEZ opportunities |
| **Senegal Customs** | Border management | MEDIUM | HIGH | ETLS implementation |
| **Dakar Chamber of Commerce (CCIAD)** | Business advocacy; networking | MEDIUM | MEDIUM | Private sector linkages |
| **Ministry of Infrastructure & Transport** | Corridor development | MEDIUM | MEDIUM | Dakar port logistics |

#### Burkina Faso & Mali (PEA: AMBER-RED - Limited Engagement)

| Country | Status | Rationale |
|---------|--------|-----------|
| **Burkina Faso** | MONITOR ONLY | Security + ECOWAS exit risk; limited corridor engagement |
| **Mali** | MONITOR ONLY | Conflict; ECOWAS exit; high security risk |

---

### 20.2 REGIONAL BODIES

| Organization | Mandate | Relevance to Corridor | Current Programs | Engagement Priority |
|--------------|---------|----------------------|------------------|---------------------|
| **ECOWAS Commission** | Regional economic integration; trade liberalization | VERY HIGH - Core framework for corridor | ETLS (Trade Liberalization Scheme), EATM Scorecard, ECOWAP | VERY HIGH - Primary regional partner |
| **UEMOA/WAEMU** | Monetary union; customs coordination | HIGH - 8 member states including CIV | Common External Tariff; agricultural harmonization | HIGH - Currency stability |
| **AfCFTA Secretariat** | Continental free trade implementation | HIGH - Long-term market access | Guided Trade Initiative; Agri-Food Trade Action Plan | HIGH - Future expansion |
| **CORAF** | Agricultural research coordination | HIGH - Technology & innovation | TARSPro project; seed systems; post-harvest research | MEDIUM - Technical partner |
| **CILSS** | Food security; drought monitoring | MEDIUM - Sahel focus | Food System Resilience Program | MEDIUM - Coordination |
| **Alliance of Sahel States (AES)** | New bloc (Burkina, Mali, Niger) | NEGATIVE - Disrupts corridor | None relevant | MONITOR - Creates complications |

#### ECOWAS Exit Complications (Burkina Faso, Mali, Niger - Effective January 2025)

**Key Implications:**
- Exit from ETLS (Trade Liberalization Scheme) - tariff barriers reinstated
- Loss of free movement protocols for goods and people
- Customs union disruption - WTO MFN rates apply
- Community levy (0.5%) on goods from AES countries
- 60% of Burkina vegetable exports to Ghana/CIV now face tariffs
- 90% of Burkina live animal exports affected
- Transit route complications for corridor goods

**ECOWAS Response (Grace Period until July 2025):**
- Continued recognition of passports/ID cards
- Goods still treated under ETLS temporarily
- Visa-free movement maintained
- Structure established for future engagement discussions

---

### 20.3 DEVELOPMENT FINANCE INSTITUTIONS

| DFI | Current Africa Ag Programs | Likely Role | Ticket Size | Engagement Status |
|-----|---------------------------|-------------|-------------|-------------------|
| **AfDB (African Development Bank)** | ProDeCAP ($25.6M CIV aquaculture); Feed Africa Strategy | LEAD DFI - anchor investor | $10-75M | ACTIVE - ProDeCAP partnership |
| **IFC (World Bank Group)** | Agribusiness value chains; SME finance | Co-investor; trade finance | $5-25M | POTENTIAL - corridor alignment |
| **Finnfund** | Sustainable agriculture; food security | Co-investor; aquaculture specialist | $5-15M | AVAILABLE - ag focus |
| **Norfund** | Agribusiness; value chain development | Co-investor | $5-15M | AVAILABLE - Africa focus |
| **BII (British International Investment)** | CASA program; agribusiness | Technical assistance; co-investment | $5-20M | POTENTIAL - CASA Plus alignment |
| **FMO (Dutch Development Bank)** | Agribusiness, Food & Water sector | Syndicated financing | $5-20M | AVAILABLE - West Africa active |
| **Proparco (France)** | Agriculture; climate finance | Co-investor; value chains | $5-15M | AVAILABLE - CIV presence |
| **DEG (Germany)** | Sustainable agriculture | Syndicated financing | $5-15M | AVAILABLE - Valency precedent |

#### DFI Consortium Opportunity

**Existing Relationships:**
- AfDB (lead) - ProDeCAP partnership
- Finnfund - active agribusiness portfolio (€71.6M in 2024)
- Norfund - expanding Africa ag investments
- IFC - West Africa trade finance programs
- BII - CASA Plus technical assistance facility

**Potential Syndicated Structure:**
- Total Facility: $75-100M
- AfDB anchor: $25-30M
- IFC participation: $15-20M
- European DFIs (Finnfund, Norfund, FMO, Proparco, DEG): $30-40M
- BII technical assistance: $3-5M

---

### 20.4 PRIVATE SECTOR ASSOCIATIONS

| Association | Scope | Member Base | Relevance | Engagement Approach |
|-------------|-------|-------------|-----------|---------------------|
| **WACTAF** | West African cross-border trade in agro-forestry-fisheries | Cross-border traders; transporters | VERY HIGH - Corridor trade specialist | KEY PARTNER - trade facilitation |
| **FEWACCI** | Federation of West African Chambers of Commerce | 15 national chambers | HIGH - Business advocacy | Policy dialogue; private sector engagement |
| **ROPPA** | West African farmer organizations | 13 national farmer orgs + Nigeria | HIGH - Farmer representation | Smallholder integration; farmer voice |
| **Chamber of Agribusiness Ghana (CAG)** | Ghana agribusiness sector | Agribusiness companies | MEDIUM - Tomato value chain | Market intelligence; processor linkages |
| **National Fisheries Associations** | Country-level (CIV, Ghana, Nigeria) | Fish farmers; processors | HIGH - Aquaculture sector | Value chain coordination |
| **Cold Chain Associations** | National logistics/cold storage | Logistics providers | HIGH - ColdChainCo component | Technical standards; facility development |
| **De Heus/Koudijs** | Feed manufacturing | Commercial feed producers | HIGH - Feed supply | Existing partner - 120K MT factory |
| **Lagos Offtakers** | Wholesale distribution | Fish/tomato distributors | HIGH - Market access | Existing partnership |

#### WACTAF (West African Association for Cross-Border Trade)

**Key Details:**
- Focus: Agro-forestry-pastoral, fisheries products, food
- Role: Trade facilitation; informal trade data collection (ECO-ICBT platform)
- Partners: ECOWAS, CILSS, GIZ EAT program
- Relevance: Critical for border facilitation component
- Engagement: Workshop participation; trader training; data sharing

#### ROPPA (Network of Peasant Organizations and Producers of West Africa)

**Key Details:**
- Members: 13 national farmer organizations + Nigeria (associate)
- Headquarters: Ouagadougou, Burkina Faso
- Focus: Family farming; smallholder inclusion; policy advocacy
- Structure: Regional colleges for women, youth; sectoral frameworks (rice, cereals, fisheries, livestock)
- Relevance: Smallholder integration; farmer organization partnerships

---

### 20.5 CIVIL SOCIETY & FARMER ORGANIZATIONS

| Organization | Focus | Geographic Coverage | Influence | Role in Project |
|--------------|-------|---------------------|-----------|-----------------|
| **ROPPA** | Family farming; smallholder rights | 15 West African countries | HIGH - Farmer voice | Smallholder inclusion; farmer organization capacity |
| **West Africa Civil Society Institute (WACSI)** | Civil society strengthening | ECOWAS region | MEDIUM | Stakeholder engagement; community consultation |
| **National Farmer Cooperatives** | Country-level producer groups | Per country | MEDIUM | Input supply; aggregation; extension |
| **Women's Agricultural Networks** | Gender in agriculture | National/regional | MEDIUM | Women's economic empowerment |
| **Consumer Associations** | Food safety; consumer rights | National | LOW-MEDIUM | Market standards advocacy |
| **Environmental NGOs** | Sustainability; climate | National/regional | MEDIUM | ESG compliance; environmental monitoring |
| **FISON (Fisheries Society of Nigeria)** | Fisheries/aquaculture advocacy | Nigeria | MEDIUM | Technical support; farmer linkages |

#### Women's Economic Empowerment Focus

**Key Considerations:**
- Women comprise 70% of cross-border traders (informal sector)
- ROPPA has dedicated Regional College for Women
- WACTAF focuses on gender-sensitive trade facilitation
- GIZ EAT program provides exclusive training for female traders
- Project should prioritize women's participation in:
  - Cold chain operations
  - Aquaculture processing
  - Trade finance access
  - Border trade activities

---

### 20.6 STAKEHOLDER INFLUENCE MATRIX

#### 2x2 Matrix: INTEREST vs INFLUENCE

```
                    HIGH INFLUENCE
                           |
        KEEP SATISFIED     |     KEY PLAYERS
        (High Interest/    |     (High Interest/
         High Influence)    |      High Influence)
                           |
    • PSTACI (CIV)         |     • AfDB (Lead DFI)
    • ECOWAS Commission    |     • CIV Government
    • CEPICI               |     • ProDeCAP Partners
    • WACTAF               |     • ECOWAS (Trade Directorate)
    • Lagos Offtakers      |     • De Heus/Koudijs
    • CNRA/WorldFish       |     • WACTAF
                           |
--------------------------|--------------------------
                           |
        MONITOR            |     KEEP INFORMED
        (Low Interest/      |     (High Interest/
         High Influence)    |      Low Influence)
                           |
    • UEMOA/WAEMU          |     • ROPPA
    • AfCFTA Secretariat   |     • Farmer Cooperatives
    • CORAF                |     • Cold Chain Associations
    • Senegal Government   |     • Environmental NGOs
    • Standards Bodies     |     • Women's Networks
    • DFI Consortium       |     • Consumer Associations
                           |
                    LOW INFLUENCE
```

#### KEY PLAYERS (Manage Closely)

| Stakeholder | Engagement Strategy | Frequency | Responsible |
|-------------|---------------------|-----------|-------------|
| **AfDB** | Regular coordination; syndication discussions | Weekly | Investment Lead |
| **CIV Government (MINADER/MIRAH)** | Formal partnership; PSTACI alignment | Monthly | Government Relations |
| **PSTACI** | Program integration; reporting | Bi-weekly | Program Manager |
| **ProDeCAP Partners** | Technical coordination | Monthly | Technical Lead |
| **ECOWAS Trade Directorate** | Policy alignment; ETLS optimization | Quarterly | Policy Advisor |
| **WACTAF** | Border facilitation; trader engagement | Monthly | Trade Facilitation Lead |
| **De Heus/Koudijs** | Feed supply coordination | Quarterly | Supply Chain Manager |

---

### 20.7 STAKEHOLDER ENGAGEMENT ROADMAP

#### Phase 1: Foundation (Months 1-3)

**Priority Actions:**
1. Formalize AfDB partnership (ProDeCAP coordination)
2. Sign MOU with PSTACI/CIV Government
3. Engage WACTAF for border baseline assessment
4. Establish DFI consortium working group
5. Conduct stakeholder mapping workshops in each country

**Key Deliverables:**
- Partnership agreements with CIV Government
- DFI term sheets
- Border facilitation assessment report
- Stakeholder engagement plan

#### Phase 2: Implementation (Months 4-12)

**Priority Actions:**
1. Launch aquaculture investments (CIV)
2. Implement cold chain facilities
3. Roll out tomato processing (Ghana)
4. Activate trade finance facility
5. Deploy border facilitation measures

**Key Deliverables:**
- Operational hatcheries (ProDeCAP)
- Cold chain infrastructure
- Processing plant commissioning
- First trade finance disbursements
- Border time reduction metrics

#### Phase 3: Scale (Months 13-24)

**Priority Actions:**
1. Expand aquaculture to additional ZEAD zones
2. Scale cold chain network
3. Integrate regional trade flows
4. Optimize border processes
5. Evaluate impact and refine

**Key Deliverables:**
- Regional aquaculture network
- Integrated cold chain corridor
- Increased intra-regional trade volumes
- Reduced border crossing times
- Impact assessment report

---

### 20.8 CRITICAL STAKEHOLDER PRIORITIES

#### Tier 1: Essential Partners (Must Engage)
1. **AfDB** - Lead DFI; ProDeCAP anchor
2. **CIV Government (MINADER/MIRAH/PSTACI)** - Host government; program alignment
3. **ECOWAS Commission** - Regional framework; ETLS
4. **WACTAF** - Border facilitation; trader networks
5. **De Heus/Koudijs** - Feed supply; existing partner

#### Tier 2: Important Partners (Should Engage)
1. **Ghana Government (MoFA)** - Tomato program
2. **Nigeria Customs** - Trade facilitation
3. **DFI Consortium** (IFC, Finnfund, Norfund, BII, FMO, Proparco, DEG)
4. **FEWACCI** - Private sector advocacy
5. **ROPPA** - Farmer representation
6. **CNRA/WorldFish** - Technical support

#### Tier 3: Supporting Partners (Monitor & Engage as Needed)
1. **AfCFTA Secretariat** - Long-term continental integration
2. **CORAF** - Research and innovation
3. **UEMOA** - Monetary coordination
4. **Cold Chain Associations** - Technical standards
5. **Environmental NGOs** - ESG compliance

---

## NEW TABLE 21: COMPREHENSIVE RISK ANALYSIS

### Executive Summary

**Overall Risk Profile: MODERATE-HIGH (AMBER)**

| Risk Category | Number of Risks | High P/I | Med P/I | Low P/I | Overall Rating |
|---------------|-----------------|----------|---------|---------|----------------|
| Political/Policy | 8 | 2 | 4 | 2 | **AMBER-RED** |
| Economic/Market | 8 | 2 | 5 | 1 | **AMBER** |
| Operational/Technical | 9 | 2 | 5 | 2 | **AMBER** |
| Environmental/Climate | 6 | 1 | 4 | 1 | **AMBER-GREEN** |
| Social/Community | 6 | 1 | 5 | 0 | **AMBER** |
| Financial/Currency | 8 | 2 | 5 | 1 | **AMBER** |
| **TOTAL** | **45** | **10** | **28** | **7** | **AMBER** |

### Top 10 Critical Risks

| Rank | Risk ID | Risk | Probability | Impact | Combined Score |
|------|---------|------|-------------|--------|----------------|
| 1 | POL-001 | Nigeria Export Ban | HIGH | HIGH | **CRITICAL** |
| 2 | ECO-001 | Chinese Fish Dumping | HIGH | HIGH | **CRITICAL** |
| 3 | FIN-006 | Cash Flow Timing | HIGH | HIGH | **CRITICAL** |
| 4 | OPR-005 | Anchor Farm Underperformance | MEDIUM | HIGH | **HIGH** |
| 5 | ECO-002 | Feed Price Volatility | MEDIUM | HIGH | **HIGH** |
| 6 | POL-002 | Border Closure | MEDIUM | HIGH | **HIGH** |
| 7 | FIN-002 | Currency Mismatch | MEDIUM | HIGH | **HIGH** |
| 8 | OPR-001 | Hatchery Failure | MEDIUM | HIGH | **HIGH** |
| 9 | OPR-003 | Cold Chain Failure | MEDIUM | HIGH | **HIGH** |
| 10 | SOC-001 | Community Land Conflicts | MEDIUM | HIGH | **HIGH** |

---

### 21.1 POLITICAL/POLICY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| POL-001 | **Nigeria Export Ban Policy** | Nigerian government imposes fish import restrictions or bans (historical precedent: 2015-2016 rice ban, periodic poultry bans) | HIGH | HIGH | AFSTI Policy Team + AGRA | 1) Pre-negotiate quota agreements with FMARD 2) Build relationships with Nigerian Aquaculture Society 3) Position as "complementary" not competitive 4) Secure LOIs from Lagos offtakers with political risk clauses | Pivot to 100% domestic CIV/Ghana markets; Phase 1 profitable standalone at $1.80/kg domestic price |
| POL-002 | **Border Closure (Nigeria-Benin)** | Nigeria closes Seme-Kraké border (historically: 2019 rice/poultry ban lasted 2+ years) | MEDIUM | HIGH | AFSTI + ECOWAS Secretariat | 1) Diversify export routes (Togo, Ghana ports) 2) Pre-position inventory at Hub 2 buffer 3) Secure fast-track perishable corridor agreements 4) Build Ghana market as alternative | Route through Lomé port to eastern Nigeria; Air freight premium fillets to Lagos; Domestic market absorption |
| POL-003 | **ECOWAS Fragmentation** | Burkina Faso and Mali ECOWAS exit creates trade barriers, visa restrictions, customs complexity | HIGH | MEDIUM | AFSTI + Regional Trade Advisors | 1) Focus Phase 1-2 on CIV-Ghana-Nigeria triangle 2) Build bilateral agreements outside ECOWAS framework 3) Establish separate legal entities per country 4) Avoid Burkina/Mali routing until stability returns | Exclude Burkina/Mali from corridor logistics; Use maritime routes exclusively; Wait for reintegration |
| POL-004 | **CIV Government Commitment Change** | Post-election policy shift reduces PSTACI support, ZEAD access delays, permit revocations | MEDIUM | MEDIUM | AFSTI + CIV Ministry of Fisheries | 1) Multi-party MoU with binding terms 2) Performance-linked incentives (jobs, FX savings) 3) Opposition party briefings for continuity 4) International visibility (World Bank, AfDB) | Accelerate Ghana anchor farm development; Reduce CIV exposure to processing only |
| POL-005 | **Ghana Election Cycle Disruption** | 2024/2028 elections create policy uncertainty, tomato processing incentives change | MEDIUM | MEDIUM | AFSTI + Ghana MOFA | 1) Cross-party engagement before elections 2) Local employment commitments in swing regions 3) Align with "Planting for Food and Jobs" program 4) Secure parliamentary committee endorsements | Shift tomato volumes to CIV processing; Delay Ghana expansion until post-election clarity |
| POL-006 | **ZEAD Land Tenure Issues** | Disputes over aquaculture zone allocations, community resistance, overlapping claims | MEDIUM | HIGH | Anchor Farm Operator + CIV Govt | 1) Pre-investment land audits with traditional authorities 2) Community benefit-sharing agreements (5-10% employment) 3) Formal registration with CNRA 4) Escrow for land compensation | Relocate to secondary ZEAD sites; Negotiate lease terms vs. ownership; Legal arbitration |
| POL-007 | **SPS/Phytosanitary Rule Changes** | New certification requirements, testing protocols, border inspection delays | MEDIUM | MEDIUM | ColdChainCo + National Standards Bodies | 1) Pre-emptive compliance with EU-equivalent standards 2) Laboratory partnerships for rapid testing 3) Digital certification systems 4) Training for border officials | In-country processing to bypass raw material restrictions; Upgrade to meet new standards |
| POL-008 | **Trade Finance Regulatory Changes** | Central bank restrictions on foreign currency lending, interest rate caps, DFI eligibility | LOW | MEDIUM | Trade Finance Facility Manager | 1) Multi-currency facility structures 2) Local currency hedging instruments 3) Relationships with central bank governors 4) Compliance with Basel/IFC standards | Shift to supplier credit structures; Reduce facility size; Focus on hard currency commodities |

---

### 21.2 ECONOMIC/MARKET RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ECO-001 | **Chinese Frozen Fish Dumping** | Chinese tilapia imports flood market at $1.45/kg, depressing local prices | HIGH | HIGH | Anchor Farm + Industry Association | 1) Quality differentiation (fresh vs. frozen) 2) "Made in CIV" branding campaign 3) Lobby for anti-dumping duties 4) Premium segment focus (hotels, restaurants) | Shift to processed/fillet products with higher margins; Export to premium West African markets |
| ECO-002 | **Feed Price Volatility** | Global soy/corn prices spike, De Heus factory delays, feed costs exceed $0.65/kg | MEDIUM | HIGH | Anchor Farm + Feed Partner | 1) 3-year feed price lock at $0.55/kg with De Heus 2) Strategic soy inventory (6-month buffer) 3) Alternative protein sources (insect meal, local soy) 4) Price escalation clauses in offtake contracts | Reduce FCR through genetics; Extend grow-out periods; Blend lower-cost feeds |
| ECO-003 | **CFA Franc Devaluation** | 15-20% devaluation against USD increases import costs, debt service burden | MEDIUM | HIGH | CFO + Treasury | 1) USD revenue matching (50%+ exports) 2) Local currency debt where possible 3) Natural hedging through CFA-denominated costs 4) Currency hedging instruments (forward contracts) | Accelerate export ratio; Renegotiate debt terms; Cost pass-through to customers |
| ECO-004 | **Lagos Price Collapse** | Nigerian wholesale prices drop below $2.30/kg due to oversupply or demand shock | MEDIUM | MEDIUM | Commercial Team | 1) Diversified customer base (5+ offtakers) 2) Long-term contracts with floor prices 3) Value-added processing (fillets command $3.50+/kg) 4) Alternative markets (Accra, Lomé, Dakar) | Shift volumes to domestic markets; Reduce export ratio; Activate cold storage buffer |
| ECO-005 | **Tomato Price Volatility** | Ghana tomato prices swing ±40% due to seasonal gluts, import competition | HIGH | MEDIUM | Tomato VC Manager | 1) Processing capacity to absorb gluts 2) Cold storage for price arbitrage 3) Contract farming with floor prices 4) Export to Nigeria during scarcity | Process to paste for shelf stability; Reduce fresh tomato exposure; Pivot to other vegetables |
| ECO-006 | **Palm Oil Price Collapse** | Global CPO prices drop below $700/MT making CIV processing uneconomic | MEDIUM | MEDIUM | Palm Oil VC Manager | 1) Conditional investment triggers at price thresholds 2) Integrated processing (refining adds margin) 3) Long-term supply contracts with manufacturers 4) Biodiesel offtake agreements | Delay palm oil investment; Focus on high-value derivatives; Exit to traders at cost |
| ECO-007 | **Interest Rate Spike** | Regional rates rise above 15%, increasing debt service, reducing project IRR | MEDIUM | MEDIUM | CFO + DFI Partners | 1) Fixed-rate concessional debt (8-10%) 2) Long tenors (10-12 years) 3) Grace periods during ramp (3-5 years) 4) Blended finance to reduce weighted cost | Extend grace periods; Convert to equity; Reduce leverage ratio |
| ECO-008 | **Global Recession/Demand Shock** | Economic downturn reduces protein demand, hotel/restaurant closures | MEDIUM | MEDIUM | Commercial Team | 1) Retail channel diversification 2) Lower-cost product lines 3) Government institutional contracts 4) Regional market diversification | Focus on affordable whole fish; Reduce premium segment exposure; Activate domestic programs |

---

### 21.3 OPERATIONAL/TECHNICAL RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| OPR-001 | **Hatchery Failure/Broodstock Disease** | GIFT strain underperforms, disease outbreak wipes out broodstock, fry supply interrupted | MEDIUM | HIGH | Hatchery Manager + CNRA | 1) Multiple broodstock sources (WorldFish, Yalelo, local) 2) Biosecurity protocols (quarantine, testing) 3) Backup hatchery arrangements 4) Genetic diversity maintenance | Import fry from Ghana/Zambia; Extend grow-out cycles; Emergency restocking protocol |
| OPR-002 | **Feed Quality Inconsistency** | De Heus factory produces substandard feed, FCR exceeds 1.8, growth rates decline | MEDIUM | HIGH | Production Manager + QA | 1) Feed specification contracts with penalties 2) Monthly laboratory testing 3) Alternative supplier agreements (Skretting, local) 4) On-site feed storage quality control | Switch to alternative suppliers; Adjust feeding regimes; Source from Ghana/Zambia |
| OPR-003 | **Cold Chain Equipment Failure** | Hub refrigeration fails, reefer trucks break down, product spoilage | MEDIUM | HIGH | ColdChainCo Operations | 1) Redundant cooling systems (N+1) 2) Preventive maintenance contracts 3) 24/7 monitoring systems 4) Emergency repair networks | Backup generators; Mobile refrigeration units; Insurance coverage for spoilage |
| OPR-004 | **Border Delays Exceeding Limits** | Customs processing >48 hours, documentation errors, inspection backlogs | HIGH | MEDIUM | ColdChainCo + Border Facilitation | 1) Pre-clearance systems (single window) 2) Dedicated perishable lanes 3) Digital documentation 4) Relationships with customs officials | Air freight for premium products; Local processing to bypass raw restrictions; Buffer inventory |
| OPR-005 | **Anchor Farm Underperformance** | Production fails to reach 5K MT by Year 3, mortality >20%, FCR >1.8 | MEDIUM | HIGH | Anchor Farm GM + AFSTI TA | 1) Sequential gating with performance milestones 2) Yalelo/Tropo technical assistance 3) Monthly production reviews 4) Early intervention protocols | Extend timeline; Reduce outgrower commitments; Bring in professional operator |
| OPR-006 | **Outgrower Coordination Failure** | Smallholders don't meet quality standards, delivery unreliable, side-selling | HIGH | MEDIUM | Outgrower Coordinator | 1) Formal contracts with penalties/incentives 2) Extension services and training 3) Input financing (fingerlings, feed on credit) 4) Collection center network | Reduce outgrower ratio; Increase anchor farm capacity; Vertical integration |
| OPR-007 | **Processing Equipment Failure** | Filleting line breakdown, blast freezer malfunction, packaging issues | LOW | MEDIUM | Processing Manager | 1) Equipment redundancy (backup lines) 2) Maintenance contracts with OEMs 3) Spare parts inventory 4) Operator training programs | Outsource processing to third parties; Manual processing backup; Reduce processing ratio |
| OPR-008 | **Water Quality Degradation** | Lake Kossou pollution, algae blooms, oxygen depletion affecting fish health | MEDIUM | MEDIUM | Environmental Manager | 1) Water quality monitoring (weekly) 2) Cage positioning optimization 3) Aeration systems 4) Government pollution control advocacy | Relocate cages to deeper water; Reduce stocking density; Water treatment systems |
| OPR-009 | **Skills Gap/Staff Turnover** | Key technical staff leave, local talent pool insufficient, knowledge loss | MEDIUM | MEDIUM | HR Manager + Training | 1) Competitive compensation packages 2) Career development programs 3) International training placements 4) Documentation and SOPs | Expat technical support; Regional recruitment; University partnerships |

---

### 21.4 ENVIRONMENTAL/CLIMATE RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ENV-001 | **Lake Water Quality Deterioration** | Agricultural runoff, industrial pollution, eutrophication affecting fish health | MEDIUM | HIGH | Environmental Manager + Govt | 1) Watershed management programs 2) Regular water quality monitoring 3) Cage site rotation 4) Advocacy for pollution controls | Filtered water systems; Relocate to better sites; Intensive water quality management |
| ENV-002 | **Climate Change Production Impact** | Rising water temperatures reduce growth rates, alter seasonal patterns | HIGH | MEDIUM | Production Manager | 1) Heat-tolerant strain selection (GIFT+) 2) Deeper cage positioning 3) Shade structures 4) Seasonal stocking adjustments | Adjust feeding regimes; Reduce stocking density; Genetic improvement program |
| ENV-003 | **Extreme Weather Events** | Floods damage cages, storms disrupt logistics, drought affects water levels | MEDIUM | MEDIUM | Operations + Risk Manager | 1) Weather monitoring and early warning 2) Reinforced cage anchoring 3) Insurance coverage (crop, asset) 4) Emergency response plans | Emergency harvesting; Temporary relocation; Insurance claims |
| ENV-004 | **Fish Disease Outbreak** | Streptococcus, columnaris, or viral outbreaks cause mass mortality | MEDIUM | HIGH | Veterinary Manager | 1) Biosecurity protocols (quarantine, disinfection) 2) Vaccination programs 3) Health monitoring (weekly sampling) 4) Rapid response isolation | Emergency harvest; Antibiotic treatment (last resort); Restocking from clean sources |
| ENV-005 | **Harmful Algal Blooms** | Toxic algae reduce oxygen, produce toxins affecting fish and human health | MEDIUM | MEDIUM | Environmental Manager | 1) Algae monitoring systems 2) Early warning protocols 3) Aeration systems 4) Site selection away from nutrient sources | Emergency relocation; Water exchange; Filtration systems |
| ENV-006 | **Drought/Water Level Decline** | Lake Kossou water levels drop, reducing cage volume, concentrating pollutants | LOW | MEDIUM | Production Manager | 1) Multi-site diversification 2) Flexible cage configurations 3) Water level monitoring 4) Alternative water sources | Reduce stocking density; Emergency harvest; Temporary suspension |

---

### 21.5 SOCIAL/COMMUNITY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| SOC-001 | **Community Land Conflicts** | Local communities dispute ZEAD allocations, demand compensation, block access | MEDIUM | HIGH | Community Relations + Govt | 1) FPIC (Free, Prior, Informed Consent) process 2) Community benefit-sharing agreements (5-10% employment) 3) Traditional authority engagement 4) Grievance mechanisms | Legal arbitration; Relocate to alternative sites; Enhanced compensation |
| SOC-002 | **Employment Disputes** | Labor unrest, unionization challenges, wage disputes affecting operations | MEDIUM | MEDIUM | HR Manager + Legal | 1) Competitive wages (above minimum +20%) 2) Clear employment contracts 3) Worker representation 4) Dispute resolution mechanisms | Mediation; Legal action; Operational adjustments |
| SOC-003 | **Gender Inclusion Challenges** | Women excluded from outgrower programs, leadership positions, technical roles | MEDIUM | MEDIUM | Gender Specialist + HR | 1) 40% women target for employment 2) Women-focused extension services 3) Childcare facilities 4) Leadership training programs | Partner with women's cooperatives; Targeted recruitment; Flexible work arrangements |
| SOC-004 | **Smallholder Integration Difficulties** | Outgrowers lack technical capacity, cannot meet standards, drop out of program | HIGH | MEDIUM | Outgrower Coordinator | 1) Comprehensive training programs 2) Input financing and credit 3) Technical assistance (extension agents) 4) Group formation for collective bargaining | Reduce outgrower targets; Increase anchor farm focus; Pay premium for lower quality |
| SOC-005 | **Youth Unemployment Tensions** | High youth unemployment creates social pressure, expectations not met | MEDIUM | MEDIUM | Community Relations | 1) Youth employment targets (60% under 35) 2) Skills training and apprenticeships 3) Local procurement preferences 4) Community development projects | Expand training programs; Partner with vocational schools; Increase local hiring |
| SOC-006 | **Conflict with Existing Fishers** | Wild capture fishers view aquaculture as competition, sabotage cages | LOW | HIGH | Community Relations | 1) Inclusive dialogue with fisher associations 2) Employment opportunities for fishers 3) No-fishing zone compensation 4) Co-management agreements | Security measures; Legal protection; Relocation |

---

### 21.6 FINANCIAL/CURRENCY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| FIN-001 | **DFI Funding Gap** | DFI commitments don't materialize, funding shortfall delays project | MEDIUM | HIGH | CFO + AFSTI Fundraising | 1) Multiple DFI pipeline (AfDB, IFC, Finnfund, BII) 2) Phased commitments linked to milestones 3) Alternative funding sources (impact investors) 4) Contingency budget reduction | Reduce Phase 1 scope; Delay non-critical investments; Seek commercial co-investors |
| FIN-002 | **Currency Mismatch (USD Debt vs Local Revenue)** | CFA revenue cannot service USD debt during devaluation | MEDIUM | HIGH | CFO + Treasury | 1) 50%+ USD revenue from exports 2) Local currency debt where available 3) Currency hedging (forwards, options) 4) Natural hedging (CFA-denominated costs) | Renegotiate debt terms; Increase export ratio; Debt rescheduling |
| FIN-003 | **Working Capital Constraints** | Trade finance facility insufficient, SME borrowers default, liquidity crisis | MEDIUM | MEDIUM | Trade Finance Manager | 1) Conservative facility sizing ($30-75M range) 2) First-loss protection from grants 3) Credit risk assessment protocols 4) Diversified borrower portfolio | Reduce facility size; Tighten credit standards; Recapitalize from DFIs |
| FIN-004 | **Counterparty Default (Offtakers)** | Lagos wholesalers fail to pay, contracts unenforceable across borders | MEDIUM | HIGH | Commercial Manager | 1) Credit insurance (ATPC, ECIC) 2) Letters of credit for exports 3) Diversified customer base (5+ offtakers) 4) Parent company guarantees | Domestic market pivot; Legal action; Credit insurance claims |
| FIN-005 | **Interest Rate Volatility** | Regional rates rise, debt service increases, project economics deteriorate | MEDIUM | MEDIUM | CFO | 1) Fixed-rate concessional debt 2) Long tenors (10-12 years) 3) Grace periods (3-5 years) 4) Interest rate caps | Refinancing; Extend grace periods; Equity conversion |
| FIN-006 | **Cash Flow Timing Mismatch** | Revenue lags behind costs during ramp, liquidity crisis in Years 2-3 | HIGH | HIGH | CFO + Treasury | 1) Working capital facility ($2-3M) 2) Phased CAPEX deployment 3) Grant funding for early years 4) Contingency reserves (10% of CAPEX) | Draw on contingency; Delay non-essential spending; Seek bridge financing |
| FIN-007 | **Tax/Regulatory Changes** | New taxes, withholding changes, double taxation issues | MEDIUM | MEDIUM | Tax Advisor + Legal | 1) Tax incentive negotiations 2) Double taxation treaties 3) Transfer pricing documentation 4) Local tax compliance | Tax planning; Legal challenges; Pass-through to customers |
| FIN-008 | **Insurance Market Capacity** | Political risk, crop insurance unavailable or prohibitively expensive | LOW | MEDIUM | Risk Manager | 1) DFI political risk guarantees 2) Regional insurance pools 3) Self-insurance reserves 4) Multilateral insurance (MIGA, ATPC) | Self-insurance; Risk retention; Alternative structures |

---

### 21.7 RISK INTERDEPENDENCY MAP

#### Critical Risk Cascades

```
PRIMARY RISKS (Triggers)
═══════════════════════════════════════════════════════════════════════════════

POL-001: Nigeria Export Ban ──┬──► ECO-004: Lagos Price Collapse
                              │    └──► FIN-004: Counterparty Default
                              │         └──► FIN-006: Cash Flow Crisis
                              │
                              └──► OPR-004: Border Delays
                                   └──► ColdChainCo Underutilization
                                        └──► FIN-003: Working Capital Constraints

POL-002: Border Closure ──────┬──► OPR-004: Border Delays (compounded)
                              │
                              └──► ECO-004: Lagos Price Collapse
                                   └──► [Same cascade as above]

ECO-002: Feed Price Spike ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► FIN-006: Cash Flow Crisis
                              │
                              └──► FIN-002: Currency Mismatch (if USD feed)

ENV-004: Disease Outbreak ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► [Same cascade as above]
                              │
                              └──► OPR-001: Hatchery Failure
                                   └──► Production Cascade Failure

FIN-001: DFI Funding Gap ─────┬──► FIN-006: Cash Flow Crisis
                              │
                              └──► Delayed ColdChainCo
                                   └──► ECO-004: Lagos Price Collapse
                                        └──► [Same cascade as above]

SOC-001: Land Conflicts ──────► Delayed Anchor Farm
                              └──► OPR-005: Underperformance
                                   └──► [Same cascade as above]
```

#### Compound Risk Scenarios

**Scenario A: "Perfect Storm" (5-10% probability)**
- Nigeria export ban + Feed price spike + Disease outbreak = Project failure
- **Mitigation:** Sequential gating ensures exit before full commitment

**Scenario B: "Death by a Thousand Cuts" (20-30% probability)**
- Border delays (+15% costs) + Chinese competition (-10% prices) + Currency devaluation (-15%) + Outgrower issues (-20% volumes) = IRR drops from 22% to 8-10%
- **Mitigation:** Price sensitivity shows project viable down to $2.30/kg with $0.60/kg feed

**Scenario C: "Cold Chain Collapse" (15-20% probability)**
- Equipment failure + Border delays >48h + Reefer breakdown = Product spoilage
- **Mitigation:** Insurance coverage, redundant systems, buffer inventory

---

### 21.8 EARLY WARNING INDICATORS

| Risk Category | Indicator | Threshold | Monitoring Frequency | Data Source | Owner |
|---------------|-----------|-----------|---------------------|-------------|-------|
| **POLITICAL** | | | | | |
| POL-001 | Nigerian aquaculture production growth | >20% YoY for 2 quarters | Quarterly | FMARD reports | Policy Team |
| POL-001 | Import ban rhetoric in media | >5 negative articles/month | Monthly | Media monitoring | Policy Team |
| POL-002 | Border crossing time | >24 hours average | Weekly | ColdChainCo logs | Operations |
| POL-003 | ECOWAS meeting outcomes | Suspension/expulsion votes | Per meeting | ECOWAS Secretariat | Policy Team |
| POL-006 | Land dispute complaints | >3 formal grievances | Monthly | Community relations | Community Mgr |
| **ECONOMIC** | | | | | |
| ECO-001 | Chinese import volumes | >15% YoY increase | Monthly | Customs data | Commercial |
| ECO-001 | CIV wholesale price | <$1.65/kg for 4 weeks | Weekly | Market surveys | Commercial |
| ECO-002 | Global soy price (CBOT) | >$500/MT for 3 months | Daily | Commodity exchanges | Procurement |
| ECO-002 | De Heus contract price | >$0.60/kg | Monthly | Contract reviews | Procurement |
| ECO-003 | CFA/USD exchange rate | >5% depreciation in 30 days | Daily | Central bank | Treasury |
| ECO-004 | Lagos wholesale price | <$2.30/kg for 4 weeks | Weekly | Offtaker reports | Commercial |
| **OPERATIONAL** | | | | | |
| OPR-001 | Hatchery mortality rate | >5% weekly | Weekly | Production reports | Hatchery Mgr |
| OPR-002 | Feed FCR | >1.7 for 2 cycles | Per cycle | Production data | Production Mgr |
| OPR-003 | Cold chain uptime | <98% monthly | Daily | Monitoring systems | ColdChainCo Ops |
| OPR-004 | Border clearance time | >48 hours | Per shipment | Logistics tracking | ColdChainCo Ops |
| OPR-005 | Anchor farm production | <80% of target for 2 quarters | Quarterly | Production reports | Farm GM |
| OPR-005 | Mortality rate | >15% for 2 months | Monthly | Health records | Veterinary |
| OPR-006 | Outgrower delivery compliance | <70% of contracted volume | Monthly | Collection data | Outgrower Coord |
| **ENVIRONMENTAL** | | | | | |
| ENV-001 | Water quality index | Below Class II for 2 weeks | Weekly | Lab testing | Environmental |
| ENV-002 | Water temperature | >30°C for 5 consecutive days | Daily | Monitoring systems | Production |
| ENV-004 | Disease incidence | >2% weekly mortality | Weekly | Health monitoring | Veterinary |
| **SOCIAL** | | | | | |
| SOC-001 | Community grievances | >5 unresolved complaints | Monthly | Grievance log | Community Relations |
| SOC-004 | Outgrower dropout rate | >20% in 6 months | Semi-annual | Program data | Outgrower Coord |
| **FINANCIAL** | | | | | |
| FIN-001 | DFI commitment delays | >6 months beyond target | Quarterly | Funding pipeline | CFO |
| FIN-002 | USD/CFA rate movement | >10% depreciation | Daily | FX markets | Treasury |
| FIN-003 | Trade finance utilization | >90% of facility | Monthly | Facility reports | Trade Finance Mgr |
| FIN-004 | Offtaker payment delays | >30 days past due | Monthly | AR aging | Commercial |
| FIN-006 | Cash position | <3 months operating expenses | Monthly | Cash flow forecast | CFO |

---

### 21.9 RISK ALLOCATION FRAMEWORK

| Risk ID | Risk | Public Sector | Private Operator | DFIs | Shared/Transfer |
|---------|------|---------------|------------------|------|-----------------|
| **POLITICAL** | | | | | |
| POL-001 | Nigeria Export Ban | 40% | 30% | 20% | 10% (insurance) |
| POL-002 | Border Closure | 50% | 30% | 10% | 10% (buffer) |
| POL-003 | ECOWAS Fragmentation | 40% | 30% | 20% | 10% (diversification) |
| POL-004 | CIV Govt Commitment | 60% | 25% | 10% | 5% (monitoring) |
| POL-006 | ZEAD Land Tenure | 40% | 35% | 15% | 10% (legal) |
| **ECONOMIC** | | | | | |
| ECO-001 | Chinese Dumping | 30% | 40% | 10% | 20% (market) |
| ECO-002 | Feed Price Volatility | 10% | 50% | 20% | 20% (market) |
| ECO-003 | CFA Devaluation | 20% | 40% | 20% | 20% (hedging) |
| ECO-004 | Lagos Price Collapse | 10% | 50% | 20% | 20% (insurance) |
| **OPERATIONAL** | | | | | |
| OPR-001 | Hatchery Failure | 10% | 60% | 20% | 10% (backup) |
| OPR-002 | Feed Quality | 10% | 60% | 20% | 10% (alternatives) |
| OPR-003 | Cold Chain Failure | 10% | 60% | 15% | 15% (insurance) |
| OPR-004 | Border Delays | 50% | 30% | 15% | 5% (buffer) |
| OPR-005 | Farm Underperformance | 10% | 65% | 20% | 5% (gating) |
| OPR-006 | Outgrower Issues | 15% | 55% | 25% | 5% (adjustment) |
| **ENVIRONMENTAL** | | | | | |
| ENV-001 | Water Quality | 40% | 35% | 15% | 10% (insurance) |
| ENV-002 | Climate Change | 30% | 40% | 20% | 10% (diversification) |
| ENV-004 | Disease Outbreak | 20% | 50% | 20% | 10% (insurance) |
| **SOCIAL** | | | | | |
| SOC-001 | Land Conflicts | 35% | 45% | 15% | 5% (legal) |
| SOC-004 | Outgrower Integration | 20% | 50% | 25% | 5% (adjustment) |
| **FINANCIAL** | | | | | |
| FIN-001 | DFI Funding Gap | 10% | 30% | 55% | 5% (alternatives) |
| FIN-002 | Currency Mismatch | 15% | 45% | 30% | 10% (natural hedge) |
| FIN-003 | Working Capital | 10% | 45% | 40% | 5% (reserves) |
| FIN-004 | Counterparty Default | 10% | 45% | 30% | 15% (insurance) |
| FIN-006 | Cash Flow Timing | 5% | 50% | 40% | 5% (contingency) |

---

### 21.10 RISK-ADJUSTED RETURNS

| Scenario | Probability | IRR | NPV @ 10% |
|----------|-------------|-----|-----------|
| Bull Case (risks mitigated) | 25% | 25% | $30M |
| Base Case (expected risks) | 50% | 22% | $10.2M |
| Bear Case (major risk event) | 20% | 8-10% | $2-5M |
| Failure (catastrophic) | 5% | -10% | -$5M |
| **Probability-Weighted** | **100%** | **18.5%** | **$12.8M** |

---

### 21.11 IMMEDIATE RISK MITIGATION ACTIONS

#### Immediate Actions (0-6 months)
1. **Secure Political Risk Insurance** for Nigeria export exposure (MIGA/ATPC)
2. **Negotiate feed price lock** with De Heus at $0.55/kg for 3 years
3. **Establish working capital facility** of $2-3M for cash flow management
4. **Complete FPIC process** for all ZEAD sites before construction
5. **Secure letters of intent** from 3+ Lagos offtakers with risk clauses

#### Short-Term Actions (6-18 months)
1. **Implement sequential gating** with clear go/no-go criteria
2. **Establish risk monitoring dashboard** with automated alerts
3. **Negotiate quota agreements** with Nigerian FMARD
4. **Diversify export routes** through Togo and Ghana ports
5. **Build community benefit-sharing** agreements with local stakeholders

#### Medium-Term Actions (18-36 months)
1. **Develop alternative protein sources** to reduce feed cost risk
2. **Establish regional insurance pool** participation for crop/disease coverage
3. **Build strategic feed inventory** (6-month buffer)
4. **Develop Ghana anchor farm** as CIV backup
5. **Create crisis management protocols** for compound risk scenarios

---

## SUMMARY: NEW TABLES ADDED

| Table | Title | Description |
|-------|-------|-------------|
| **19** | LIKELY PLAYERS TO OPERATE | Comprehensive operator analysis for all investment components |
| **19.1** | Aquaculture Operators | Hatchery, Feed, Anchor Farm, Processing, Border/Reefer |
| **19.2** | ColdChainCo Operators | Hub 1 Abidjan, Hub 2 Sèmè-Kraké, Reefer Fleet |
| **19.3** | Ghana Tomato Operators | Processing facilities |
| **19.4** | Palm Oil CIV Operators | Milling upgrade |
| **20** | KEY STAKEHOLDERS | Complete stakeholder mapping across 6 countries |
| **20.1** | Government Bodies | Ministries, agencies, authorities by country |
| **20.2** | Regional Bodies | ECOWAS, UEMOA, AfCFTA, CORAF |
| **20.3** | Development Finance Institutions | AfDB, IFC, Finnfund, Norfund, BII, FMO, Proparco, DEG |
| **20.4** | Private Sector Associations | WACTAF, FEWACCI, ROPPA, Chambers |
| **20.5** | Civil Society & Farmer Organizations | ROPPA, cooperatives, women's networks |
| **20.6** | Stakeholder Influence Matrix | 2x2 Interest vs Influence framework |
| **20.7** | Engagement Roadmap | Phased engagement strategy (Months 1-24) |
| **21** | COMPREHENSIVE RISK ANALYSIS | 45 risks across 6 categories |
| **21.1** | Political/Policy Risks | 8 risks including Nigeria export ban, border closure |
| **21.2** | Economic/Market Risks | 8 risks including Chinese dumping, feed volatility |
| **21.3** | Operational/Technical Risks | 9 risks including hatchery failure, cold chain failure |
| **21.4** | Environmental/Climate Risks | 6 risks including water quality, disease outbreak |
| **21.5** | Social/Community Risks | 6 risks including land conflicts, outgrower integration |
| **21.6** | Financial/Currency Risks | 8 risks including DFI funding gap, currency mismatch |
| **21.7** | Risk Interdependency Map | Cascade analysis and compound scenarios |
| **21.8** | Early Warning Indicators | 35+ indicators with thresholds and monitoring |
| **21.9** | Risk Allocation Framework | Public/Private/DFI risk sharing |
| **21.10** | Risk-Adjusted Returns | Probability-weighted IRR and NPV |
| **21.11** | Mitigation Actions | Immediate, short-term, medium-term actions |

---

*Document prepared for AFSTI Dakar-Lagos Corridor Play*
*Original tables 1-18: See DAKAR_LAGOS_DATA_EXTRACTION_PROMPT.md*
*New tables 19-21: Added February 2026*

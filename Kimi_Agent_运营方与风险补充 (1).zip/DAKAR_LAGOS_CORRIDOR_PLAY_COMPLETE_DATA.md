# DAKAR-LAGOS CORRIDOR PLAY — COMPLETE DATA EXTRACTION
## With Real Data from Source Files (PPT, Excel, Binding Constraints)

---

## EXECUTIVE SUMMARY

**Corridor Play:** Dakar-Lagos "Protein & Fresh Food Belt"
- **Total Investment:** $74-150M across 6 components
- **Hero Investment:** CIV Tilapia Aquaculture ($16-25M)
- **Spine Enabler:** ColdChainCo ($10-15M)
- **Thesis:** ColdChainCo shared infrastructure makes ALL commodity ICs bankable
- **Addressable Market:** $3.5B fish imports + $300M tomato + $300M palm oil = $4B+

---

## TABLE 1: CORRIDOR HEADLINE KPIs

| KPI | Value | Source |
|-----|-------|--------|
| Total corridor food imports | $15.9B | PPTX slide 5 |
| Average annual growth (2019-23) | +4.2% | PPTX slide 5 |
| Fish imports (corridor) | $3.5B | PPTX slide 5 (fastest growing) |
| CIV fish deficit | 490K MT | PPTX slide 7 |
| CIV annual fish imports | $841M | PPTX slide 7 |
| CIV current aquaculture production | 10K MT | PPTX slide 7 |
| CIV fish demand | 600K MT | PPTX slide 7 |
| PSTACI programme commitment | $1.3B (FCFA 825B) | PPTX slide 7 |
| Countries in corridor | 6 (Nigeria, CIV, Ghana, Senegal, Mali, BF) | RFP |
| Corridor import growth rate | ~4.2% CAGR | PPTX slide 5 |

---

## TABLE 2: STACKED INVESTMENT SUMMARY

| Component | Type | Investment ($M) | Target IRR | Jobs | Timeline | Key Dependency | Source |
|-----------|------|----------------|------------|------|----------|---------------|--------|
| **AQUACULTURE (CIV Tilapia)** | | **$16-25M** | **15-25%** | **5-15K** | | | |
| 1. Hatchery | Production | $3-5M | N/A (public good) | Sector-wide | Yr 1-2 | ProDeCAP co-invest | PPTX slide 13 |
| 2. Feed Partnership | Production | $2-4M | N/A (equity) | Sector-wide | Yr 1-2 | De Heus factory | PPTX slide 13 |
| 3. Anchor Farm + Outgrowers | Production | $5-8M | 15-25% | 5-15K | Yr 1-3 | Hatchery + Feed | PPTX slide 13 |
| 4. Processing | Processing | $3-4M | Part of above | Included | Yr 3-4 | Farm at scale | PPTX slide 13 |
| 5. Border + Reefer | Trade | $3-4M | Part of above | Included | Yr 4-5 | ColdChainCo | PPTX slide 13 |
| **COLDCHAINCO** | Enabler | **$10-15M** | **12-18%** | **500-1K** | | | |
| Hub 1 Abidjan | Enabler | $5-7M | Part of above | Included | Yr 2-3 | Anchor volumes | PPTX slide 21 |
| Hub 2 Sèmè-Kraké | Enabler | $3-4M | Part of above | Included | Yr 3-4 | Hub 1 operational | PPTX slide 21 |
| Reefer Fleet | Enabler | $2-4M | Part of above | Included | Yr 3-4 | Hub 1 + 2 | PPTX slide 21 |
| **GHANA TOMATO** | VC | **$8-15M** | **12-18%** | **20K+ farmers** | Yr 1-4 | Processing, Cold chain | Cards / SteerCo |
| **PALM OIL CIV** | VC (conditional) | **$5-10M** | **10-15%** | **10K+ farmers** | Yr 3+ | Milling upgrade | Cards / SteerCo |
| **TRADE FINANCE FACILITY** | Enabler | **$30-75M** | N/A (facility) | **2K+ SMEs** | Yr 2+ | DFI anchor | Card 15 |
| **BORDER FACILITATION** | Enabler | **$5-10M** | N/A | System-wide | Yr 1-3 | ECOWAS | Card 10 |
| **TOTAL CORRIDOR PLAY** | | **$74-150M** | **15-22%** | **34K+** | Yr 1-10 | | |

---

## TABLE 3: AQUACULTURE 10-YEAR P&L (from Financial Model V4)

| Line Item | Yr 1 | Yr 2 | Yr 3 | Yr 4 | Yr 5 | Yr 6 | Yr 7 | Yr 8 | Yr 9 | Yr 10 |
|-----------|------|------|------|------|------|------|------|------|------|-------|
| **Total volume (MT)** | 1,500 | 3,500 | 6,000 | 9,000 | 12,000 | 14,000 | 15,500 | 16,500 | 17,500 | 18,000 |
| Domestic (MT) | 1,500 | 3,500 | 5,000 | 6,500 | 8,000 | 8,500 | 9,000 | 9,500 | 9,500 | 10,000 |
| Export Lagos (MT) | 0 | 0 | 1,000 | 2,500 | 4,000 | 5,500 | 6,500 | 7,000 | 8,000 | 8,000 |
| **Domestic revenue ($M)** | $2.7 | $6.3 | $9.0 | $11.7 | $14.4 | $15.3 | $16.2 | $17.1 | $17.1 | $18.0 |
| Export revenue ($M) | $0 | $0 | $2.85 | $7.125 | $11.4 | $15.675 | $18.525 | $19.95 | $22.8 | $22.8 |
| **Total Revenue ($M)** | $2.7 | $6.3 | $11.85 | $18.825 | $25.8 | $30.975 | $34.725 | $37.05 | $39.9 | $40.8 |
| **Total COGS ($M)** | $2.29 | $5.34 | $9.5 | $14.6 | $19.7 | $23.28 | $25.91 | $27.61 | $29.49 | $30.25 |
| **Gross Profit ($M)** | $0.41 | $0.96 | $2.35 | $4.23 | $6.1 | $7.7 | $8.81 | $9.44 | $10.41 | $10.55 |
| Gross Margin (%) | 15.3% | 15.3% | 19.8% | 22.4% | 23.6% | 24.9% | 25.4% | 25.5% | 26.1% | 25.9% |
| **EBITDA ($M)** | -$0.39 | $0.16 | $1.55 | $3.43 | $5.3 | $6.9 | $8.01 | $8.64 | $9.61 | $9.75 |
| EBITDA Margin (%) | -14.4% | 2.6% | 13.1% | 18.2% | 20.5% | 22.3% | 23.1% | 23.3% | 24.1% | 23.9% |
| **Project IRR (unlevered)** | **22.2%** | | | | | | | | | |
| **NPV @ 10% ($M)** | **$10.2M** | | | | | | | | | |

---

## TABLE 4: AQUACULTURE ASSUMPTIONS (from Excel V4)

| Parameter | Value | Unit | Source |
|-----------|-------|------|--------|
| Anchor farm steady-state capacity | 10,000 | MT/yr | Yalelo benchmark: 18K MT on $18M |
| Feed Conversion Ratio (FCR) | 1.5 | ratio | Industry standard; Yalelo achieves 1.4-1.6 |
| Feed cost (local, De Heus target) | $0.55 | $/kg | Target with dedicated aquafeed line |
| Feed cost per kg fish (feed × FCR) | $0.825 | $/kg | FORMULA: feed cost × FCR |
| Fingerling cost per kg fish | $0.10 | $/kg | Own hatchery but still $0.10/kg |
| Direct labour per kg | $0.15 | $/kg | Farm labour, technicians, management |
| Other direct costs per kg | $0.30 | $/kg | Energy, water, pond maint, mortality (5%), medication |
| **Total production cost per kg** | **$1.375** | **$/kg** | Sum of above |
| Post-harvest loss (current) | 25% | % | FAO 2020: 25-30% for fish in SSA |
| Post-harvest loss (with ColdChainCo) | 3% | % | Target with industrial cold chain |
| Domestic whole fish price | $1.80 | $/kg | CIV wholesale |
| Export blended price (base) | $2.85 | $/kg | Mix of whole, fresh fillet, frozen fillet |
| Export blended price (bear) | $2.30 | $/kg | Mostly whole fish, low fillet share |
| Export blended price (bull) | $3.20 | $/kg | High fillet %, strong Lagos demand |
| Nigeria wholesale tilapia | $2.69 | $/kg | Selina Wamucii 2025 (range $2.69-$4.03) |
| Chinese frozen landed CIV | $1.45 | $/kg | IndexBox 2025 (CIF $1.12 + duties/handling) |
| ColdChainCo rental | $0.15 | $/kg | Storage + blast freeze |
| Processing cost (export) | $0.12 | $/kg | Filleting, packaging, QC |
| Reefer transport (export) | $0.18 | $/kg | Abidjan → Lagos via Sèmè-Kraké |
| Border + handling (export) | $0.05 | $/kg | Customs, phytosanitary, dwell costs |

---

## TABLE 5: PRICE SENSITIVITY MATRIX (from Financial Model V4)

| Feed Cost ↓ \ Blended Price → | $2.30 | $2.55 | $2.85 | $3.00 | $3.20 |
|-------------------------------|-------|-------|-------|-------|-------|
| **$0.45** | 12.5% | 16.4% | 20.8% | 23.1% | 26.1% |
| **$0.50** | 10.8% | 14.7% | 19.1% | 21.4% | 24.4% |
| **$0.55 (BASE)** | 9.1% | 13.0% | **17.4%** | 19.7% | 22.7% |
| **$0.60** | 7.4% | 11.3% | 15.7% | 18.0% | 21.0% |
| **$0.65** | 5.7% | 9.6% | 14.0% | 16.3% | 19.3% |

**Color Coding:**
- 🟢 Green = >10% (DFI threshold)
- 🟡 Yellow = 8-10%
- 🔴 Red = <8%

---

## TABLE 6: PRODUCTION RAMP 2025-2035 (from Financial Model V4)

| Year | PSTACI Target | AFSTI Conservative (30%) | Domestic Use | Export to Lagos |
|------|--------------|-------------------------|-------------|----------------|
| 2025 | 10,000 | 10,000 | 10,000 | 0 |
| 2026 | 50,000 | 15,000 | 15,000 | 0 |
| 2027 | 100,000 | 30,000 | 28,000 | 2,000 |
| 2028 | 200,000 | 50,000 | 44,000 | 6,000 |
| 2029 | 300,000 | 80,000 | 68,000 | 12,000 |
| 2030 | 500,000 | 100,000 | 82,000 | 18,000 |
| 2031 | 500,000 | 120,000 | 97,000 | 23,000 |
| 2032 | 500,000 | 140,000 | 112,000 | 28,000 |
| 2033 | 500,000 | 165,000 | 131,000 | 34,000 |
| 2034 | 500,000 | 190,000 | 148,000 | 42,000 |
| 2035 | 500,000 | 220,000 | 170,000 | 50,000 |

---

## TABLE 7: RETURNS SUMMARY (3 scenarios from Excel)

| Metric | Bear | Base | Bull |
|--------|------|------|------|
| Blended export price ($/kg) | $2.30 | $2.85 | $3.20 |
| Feed cost ($/kg) | $0.60 | $0.55 | $0.50 |
| Export share at steady state | 30% | 50% | 60% |
| Total CAPEX | $25M | $20.5M | $16M |
| Project IRR (unlevered) | 8-10% | **22.2%** | 22-25% |
| NPV @ 10% ($M) | $2-5M | **$10.2M** | $25-30M |
| Payback period | Yr 8-9 | Yr 5-6 | Yr 4 |
| EBITDA at steady state ($M) | $2-3M | $9.75M | $7-9M |
| EBITDA margin | 15-18% | 24% | 32-35% |

---

## TABLE 8: SUPPLY SECURITY CALENDAR (Year 5 Steady State)

| Month | Anchor (MT) | Outgrower (MT) | Total (MT) | Fresh Alloc | Frozen Buffer | Lagos Weekly |
|-------|------------|----------------|-----------|------------|---------------|-------------|
| Jan | 1,800 | 350 | 2,150 | 1,075 | 1,075 | 497 |
| Feb | 1,800 | 350 | 2,150 | 1,075 | 1,075 | 497 |
| Mar | 1,900 | 380 | 2,280 | 1,140 | 1,140 | 527 |
| Apr | 1,700 | 330 | 2,030 | 1,015 | 1,015 | 469 |
| May | 1,600 | 300 | 1,900 | 950 | 950 | 439 |
| Jun | 1,500 | 280 | 1,780 | 890 | 890 | 411 |
| Jul | 1,400 | 260 | 1,660 | 830 | 830 | 383 |
| Aug | 1,400 | 260 | 1,660 | 830 | 830 | 383 |
| Sep | 1,500 | 280 | 1,780 | 890 | 890 | 411 |
| Oct | 1,600 | 300 | 1,900 | 950 | 950 | 439 |
| Nov | 1,700 | 330 | 2,030 | 1,015 | 1,015 | 469 |
| Dec | 1,800 | 350 | 2,150 | 1,075 | 1,075 | 497 |

---

## TABLE 9: CAPITAL STACK

| Tranche | Amount | Share | What it funds | Risk profile | DFI targets |
|---------|--------|-------|--------------|-------------|-------------|
| Equity/Grant | $5-8M | 25% | Hatchery + TA (public goods) | Highest — market failure | AfDB ProDeCAP |
| Concessional | $5-7M | 30% | Anchor farm + feed (patient capital) | High — 5yr ramp | Finnfund, Norfund, BII |
| Senior Debt | $6-11M | 45% | Processing + reefer (bankable assets) | Standard — cash flows Yr 3+ | IFC, AfDB, commercial |
| **TOTAL** | **$16-25M** | 100% | + ColdChainCo ($10-15M separate) | | |

---

## TABLE 10: ANCHOR FARM CANDIDATES (from PPTX slide 15)

| Candidate | Type | Profile | Why | Risk | Mitigation |
|-----------|------|---------|-----|------|-----------|
| **Yalelo (Zambia)** | International — Proven | $18M DFI, 18K MT/yr, 5-country export, 1,500 jobs | W.Africa expansion logical; Finnfund relationship for co-investment | May not want CIV exposure | AFSTI de-risks first 3 years |
| **Tropo Farms (Ghana)** | International — Regional | Largest W.Africa tilapia farm, Lake Volta operations | Could replicate in CIV ZEAD zones; 2-3 hour flight from Abidjan | Ghana-focused, lacks CIV govt ties | AFSTI provides policy bridge |
| **Local CIV Cooperative** | Local — Community | 50-100 existing farmers near ZEAD zone with road access | Lowest cost structure; Govt/PSTACI alignment; Community ownership | Management capacity, governance | AFSTI provides PMO + technical assistance |
| **Emerging CIV Entrepreneur** | Local — Growth | 500+ MT operator, ambitious scale-up | Local ownership = strongest govt support; Entrepreneurial energy; Lower overhead | Unproven at scale, thin balance sheet | Structured equity + mentorship programme |

**Recommendation:** Dual track — approach Yalelo/Tropo AND identify local cooperative/entrepreneur in parallel

---

## TABLE 11: KEY PARTNERS (from PPTX slide 16)

| Partner | Role | Why Essential | Without Them | With Them |
|---------|------|--------------|-------------|----------|
| **ProDeCAP / AfDB** | $25.6M hatcheries + broodstock (launching 2025) | Co-invest on hatchery (#1); Align ZEAD zones; Avoid duplication | Hatchery investment doubles; No credibility | Shared cost; Faster scale; AfDB lead DFI |
| **De Heus / Koudijs** | 120K MT feed factory Abidjan (2023); 2nd plant Korhogo | Dedicated aquafeed formulation line; Feed is 60-80% of production cost | Feed stays imported at $0.82/kg; IRR unviable | Local feed at $0.55/kg; Makes or breaks IRR |
| **PSTACI / CIV Govt** | $1.3B programme; 30 ZEAD zones designated | Regulatory environment; Land access; Export permits; Tax incentives | Land acquisition slow; Permits uncertain | Fast-track approvals; Political will |
| **DFI Consortium** | AfDB (lead), Finnfund (Yalelo track record), IFC, Norfund, BII | No single DFI takes full $16-25M ticket; Blended finance matches risk appetite | Funding gap; No bankability | 25/30/45 capital stack; De-risked for each DFI |
| **Lagos Offtakers** | 2-3 wholesale distributors in Lagos fish markets | Blended offtake contracts guarantee demand; $3.5B import market | No bankability; Uncontracted volumes | Contracted volumes; $2.69-4.03/kg pricing |
| **CNRA / WorldFish** | Broodstock genetics (GIFT tilapia); Fry production; Training | Genetic quality determines growth rates, FCR, farm economics | High mortality; Slow growth; Poor FCR | Yalelo-level performance; 10-15% gains per generation |

**Alternatives for Feed:** Aller Aqua (Yalelo JV model), Raanan Fish Feed (Israel, active W.Africa)

---

## TABLE 12: RISK MATRIX (from PPTX slide 19)

| Risk | Rating | Impact | Mitigation | Status |
|------|--------|--------|-----------|--------|
| **Production Ramp Risk** | AMBER | PSTACI + ProDeCAP deliver <30% of target; Anchor farm cannot reach 5K MT; Investment stranded; IRR <8% | Phase 1 investments (#1-3) de-risk sequentially; Gate reviews at each stage; ProDeCAP co-invests | AMBER - Monitor PSTACI quarterly |
| **Price / Margin Risk** | GREEN | Feed costs spike or Lagos wholesale price drops; Blended revenue <$2.30/kg; Bear case IRR 8-10% | Local feed partnership (#2) locks in <$0.55/kg; $1.26/kg structural margin buffer; Sensitivity matrix shows viability | GREEN - Structural advantage verified |
| **Policy / Export Ban Risk** | AMBER | CIV or Nigeria imposes ad hoc trade restrictions; Corridor trade blocked | Domestic demand absorbs 100% of production; Phase 1 profitable standalone; Export is upside, not base | AMBER - PEA rates CIV AMBER-GREEN; Domestic fallback protects downside |

---

## TABLE 13: PEA RATINGS — DAKAR-LAGOS COUNTRIES

| Country | Production | Trade Posture | PE Incentives | Overall | Key Issue |
|---------|-----------|--------------|--------------|---------|-----------|
| CIV | Amber-Green | Amber | Amber-Green | **AMBER-GREEN** | Best positioned; PSTACI backing |
| Ghana | Amber-Green | Amber | Amber | **AMBER** | Stable; tomato processing potential |
| Nigeria | Amber-Green | Amber-Red | Amber-Red | **AMBER** | Border policy volatility; huge demand |
| Senegal | Amber | Amber | Amber | **AMBER** | Rice focus; aquaculture secondary |
| Burkina Faso | Amber-Red | Red | Red | **AMBER-RED** | Security + ECOWAS exit risk |
| Mali | Amber-Red | Amber-Red | Red | **AMBER-RED** | Conflict; ECOWAS exit |

---

## TABLE 14: COLDCHAINCO DETAILS (from PPTX slide 21)

| Component | Investment | Revenue Model | Capacity | Timeline | Key Features |
|-----------|-----------|--------------|----------|----------|--------------|
| Hub 1: Abidjan port zone | $5-7M | Per tonne-km + per pallet-day | 5K MT/yr Phase 1 | Yr 2-3 | Multi-commodity: fish, palm oil, tomatoes, poultry |
| Hub 2: Sèmè-Kraké border | $3-4M | Buffer storage, fast-track | 500-1K MT | Yr 3-4 | Pre-positions stock; reduces border dwell risk |
| Reefer fleet | $2-4M | $/tonne-km + $/pallet-day | 10-15 trucks | Yr 3-4 | Hybrid backup (solar + diesel); efficient refrigeration |
| **Total ColdChainCo** | **$10-15M** | **IRR 12-18%** | **30K+ MT/yr at scale** | **Yr 2-5** | First-mover advantage; shared services lower unit costs |

**Addressable Market:** Fish $841M + Palm oil $300M+ + Tomato $300M + Poultry = $2B+
**Post-harvest loss elimination:** 25-30% fish → near-zero; 40%+ tomatoes → near-zero

---

## TABLE 15: CROSS-VC SYNERGY MATRIX

| Shared Enabler | Aquaculture (IC2) | Tomato (IC5) | Palm Oil (conditional) | Future Poultry |
|---------------|-------------------|-------------|----------------------|---------------|
| ColdChainCo Hub 1 (Abidjan) | Blast freeze fish ✓ | Tomato paste storage ✓ | Palm oil temp control ✓ | Frozen storage ○ |
| ColdChainCo Hub 2 (Sèmè-Kraké) | Border buffer ✓ | Border buffer ✓ | Border buffer ✓ | Border buffer ○ |
| Reefer Fleet (10-15 trucks) | Fish → Lagos ✓ | Paste → Lagos ✓ | Oil → Lagos ✓ | Chicken → Lagos ○ |
| Trade Finance Facility | WC for processors ✓ | WC for processors ✓ | WC for processors ✓ | WC for processors ○ |
| SPS Harmonisation | Fish certification ✓ | Phyto certification ✓ | Quality standards ✓ | HACCP ○ |
| Border Facilitation | Perishable fast-track ✓ | Shared benefit ✓ | Shared benefit ✓ | Shared benefit ○ |

✓ = active in this play  ○ = future upside

---

## TABLE 16: IMPACT CASCADE

| Metric | Aquaculture | Tomato | Palm Oil | ColdChainCo | Trade Finance | TOTAL |
|--------|------------|--------|---------|------------|--------------|-------|
| Direct jobs | 5-15K | 2-5K | 1-3K | 500-1K | 100-200 | 9-24K |
| SHF reached | 1,800+ cage farmers | 20K+ outgrowers | 10K+ farmers | N/A | 2K+ SMEs | 34K+ |
| Import substitution ($/yr) | $120-180M | $50-100M | $30-50M | Enabling | Enabling | $200-330M |
| FX savings ($/yr) | $84-126M | $35-70M | $21-35M | Enabling | Enabling | $140-231M |

---

## TABLE 17: PHASED DEPLOYMENT TIMELINE

| Investment | Start | Gate 1 | Gate 2 | Gate 3 | Full Scale |
|-----------|-------|--------|--------|--------|-----------|
| Hatchery | Yr 1 Q1 | Yr 1 Q4: 50M fry | Yr 2 Q4: scale | - | Yr 3 |
| Feed Partnership | Yr 1 Q1 | Yr 1 Q3: <$0.55/kg | Yr 2: at scale | - | Yr 2 |
| Anchor Farm | Yr 1 Q2 | Yr 2 Q2: 5K MT | Yr 3: 10K MT | Yr 4: outgrowers | Yr 5 |
| ColdChainCo Hub 1 | Yr 2 Q1 | Yr 2 Q4: operational | Yr 3: 5K MT thru | - | Yr 3 |
| Processing | Yr 3 Q1 | Yr 3 Q3: blended product | Yr 4: at capacity | - | Yr 4 |
| ColdChainCo Hub 2 | Yr 3 Q1 | Yr 3 Q4: border buffer | Yr 4: multi-commodity | - | Yr 4 |
| Border + Reefer | Yr 4 Q1 | Yr 4 Q3: 52-week supply | Yr 5: full corridor | - | Yr 5 |
| Ghana Tomato | Yr 1 Q3 | Yr 2: processing pilot | Yr 3: export volumes | Yr 4: ColdChainCo | Yr 4 |
| Trade Finance | Yr 2 Q1 | Yr 2 Q4: 3 banks signed | Yr 3: $50M deployed | Yr 4: self-sustaining | Yr 4 |

---

## TABLE 18: FINANCING ARCHITECTURE (FULL CORRIDOR PLAY)

| Source | Aquaculture | ColdChainCo | Tomato | Palm Oil | Trade Finance | Border | TOTAL |
|--------|-----------|------------|--------|---------|-------------|--------|-------|
| DFI Grant/Concessional | $5-8M | $2-3M | $2-4M | $1-2M | $10-15M (first-loss) | $3-5M | $23-37M |
| DFI Equity | $5-7M | $3-5M | $3-5M | $2-4M | - | - | $13-21M |
| Senior Debt | $6-11M | $5-7M | $3-6M | $2-4M | $20-60M (bank syndicate) | $2-5M | $38-93M |
| **TOTAL** | **$16-25M** | **$10-15M** | **$8-15M** | **$5-10M** | **$30-75M** | **$5-10M** | **$74-150M** |

---

## TABLE 19: LIKELY PLAYERS TO OPERATE

### 19.1 AQUACULTURE OPERATORS

#### Hatchery ($3-5M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Hatchery | **Public-Private Partnership** | **ProDeCAP / AfDB + CNRA + Private Operator** | ProDeCAP already funded ($25.6M); CNRA has genetic program; requires private efficiency | ProDeCAP approved 2024-2030; CNRA operates breeding nucleus; WorldFish GIFT in 17 countries | Critical fit - public good with commercial sustainability |
| Hatchery | **International Technical Partner** | **WorldFish Center** | Manages GIFT genetics globally; established African programs | GIFT in 17 countries; 28 years selective breeding; 10-15% gains per generation | Essential for genetic quality |
| Hatchery | **Regional Operator** | **Til-Aqua (Netherlands)** | Specialized tilapia hatchery technology; has worked in Africa | Advanced hatchery systems; disease-free fingerling production | Technical expertise |

#### Feed Partnership ($2-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Feed Partnership | **International Feed Major (EXISTING)** | **De Heus / Koudijs (Netherlands)** | 120K MT factory inaugurated Abidjan 2023; 2nd plant in Korhogo; expressed commitment to Ivorian aquaculture | EUR multi-million investment; 75+ countries; strong technical support; established distribution | **EXISTING PARTNER** - Natural fit |
| Feed Partnership | **Alternative International** | **Aller Aqua (Denmark)** | Yalelo JV model partner; produces specialized aquafeed; expanding in Africa | Supplies Yalelo; proven African aquafeed experience | Alternative if De Heus unavailable |
| Feed Partnership | **Alternative International** | **Raanan Fish Feed (Israel)** | Active in West Africa; specialized fish feed formulations; technical support | Israeli aquafeed expertise; regional presence | Backup option |

#### Anchor Farm + Outgrowers ($5-8M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Anchor Farm | **International Proven (EXISTING)** | **Yalelo (Zambia/Uganda) - First Wave Group** | Largest freshwater fish producer in SSA (18K MT); proven DFI relationships ($18M); 5-country export | 18,000 MT; 1,500 employees; $84M project financing; gender-focused | **EXISTING CANDIDATE** - Proven at scale |
| Anchor Farm | **Regional West Africa (EXISTING)** | **Tropo Farms (Ghana)** | Largest tilapia producer in West Africa; Lake Volta operations; explicit West Africa expansion | 15,000 MT current; 917 employees; 3,000 market traders (majority women) | **STRONGEST FIT** - Regional leader |
| Anchor Farm | **Local Private/Cooperative** | **Local CIV Cooperative (50-100 farmers)** | PSTACI developing 30 ZEAD zones; existing farmer relationships; government support | FISH4ACP supporting cooperatives; CNRA technical support | Critical for outgrower success |
| Anchor Farm | **Local Entrepreneur** | **Emerging CIV 500+ MT Operator** | Several operators achieving commercial scale; local market knowledge; lower cost structure | Multiple operators at 500-1,000 MT; established buyer relationships | Growth candidates |

#### Processing Facility ($3-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Processing | **Anchor Farm Integrated** | **Tropo Farms / Yalelo / Victory Farms** | Major operators vertically integrated; ensures quality and traceability | Tropo building modern facility; Yalelo has processing capabilities | Natural fit |
| Processing | **Local CIV Processor** | **IPF Commercial Logistics Park (Abidjan)** | Chinese-invested facility near Port of Abidjan; 120,000 ton cold storage; blast freezing | 12-hectare park; 2 low-temp warehouses; 1,000 sqm fast-freezing | Existing cold chain; port proximity |

#### Border + Reefer Operations ($3-4M)

| Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Border/Reefer | **International Logistics Major** | **AGL (Africa Global Logistics) - MSC Group** | Largest logistics operator in Africa; 21,000 employees; 49 countries; cold storage expertise | 100+ years Africa; tri-temperature platform Abidjan airport (6,000 sqm); bonded warehousing | **STRONGEST CANDIDATE** |
| Border/Reefer | **Global Port Operator** | **DP World** | Major West Africa port operator; developing $1.2B Ndayane Port; cold chain capabilities | $1.2B Ndayane Port; cold storage Dakar; reefer expansion | Port and logistics capabilities |
| Border/Reefer | **International Freight Forwarder** | **Kuehne+Nagel** | Expanded Africa network to 18 countries; healthcare/pharma cold chain; perishables focus | OR Tambo airside facility; temperature-controlled pharma logistics | Cold chain credentials |

---

### 19.2 COLDCHAINCO OPERATORS

| Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------------|---------------------|-----------|--------------|---------------|
| Hub 1 Abidjan | **International Logistics Major** | **AGL (Africa Global Logistics)** | Existing tri-temperature facility at Abidjan airport (Aerohub - 6,000 sqm); expanding to 9,000 sqm | Aerohub: 3,500 sq m warehouse with cold room; bonded area; EDGE certified | **STRONGEST CANDIDATE** |
| Hub 1 Abidjan | **Chinese Infrastructure Investor** | **IPF Commercial Logistics Park** | 12-hectare facility near Port of Abidjan; 120,000 ton capacity; 2 low-temp warehouses; blast-freezing | 120,000 ton processing/storage; 3 x 5,000 sqm warehouses; fast-freezing | Large-scale cold storage |
| Hub 2 Seme-Krake | **Regional Logistics Operator** | **AGL Border Logistics** | Extensive West Africa border operations; ECOWAS transit experience; customs expertise | Cross-border operations throughout West Africa; customs clearing; bonded transport | Established border logistics |
| Hub 2 Seme-Krake | **Benin National Operator** | **Benin Logistics Company (State/Private JV)** | Benin vested interest in border efficiency; Seme-Krake critical trade corridor; local knowledge | Seme-Krake major Benin-Nigeria border; government investment in border infrastructure | Local ownership |
| Reefer Fleet | **International Logistics Leasing** | **EFAfrica Group (AgDevCo Portfolio)** | Equipment leasing company for African agriculture; $7.2M AgDevCo follow-on; 1,500+ entrepreneurs | 1,500+ lessee entrepreneurs; trucks and tractors focus; typical lease $10K-$80K | AgDevCo relationship |
| Reefer Fleet | **Regional Transport Operator** | **West African Transport Companies** | Established trucking companies with reefer capabilities; ECOWAS cross-border experience | Reefer trucking in West Africa; cross-border permits; established routes | Local expertise |

---

### 19.3 GHANA TOMATO OPERATORS

| Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------------|---------------------|-----------|--------------|---------------|
| Tomato Processing | **International Food Major** | **GBfoods Africa (Spain)** | Commissioned $5M Tema facility (2023); secured 2,428 hectares Afram Plains (2026); Gino and Pomo brands; "seed-to-shelf" strategy | $5M Tema facility operational; 2,428 hectares secured (3x Nigeria farm); yields improved to 60-70 tonnes/acre Nigeria | **STRONGEST CANDIDATE** |
| Tomato Processing | **Local Ghanaian Processor** | **Trusty Foods / Expom Ghana Ltd** | Established 2003 in Tema; supplies West African market; sources some Ghana tomatoes | Tema processing facility; West African market supply; 7% Ghana fresh tomatoes, 93% bulk paste imports | Existing facility |
| Tomato Processing | **Revived State Facility** | **Northern Star Tomato Company (Pwalugu)** | Former state tomato factory refurbished 2006-2007; reopened 2010; configured to supply Trusty Foods Tema | Pwalugu factory refurbishment; Ministry of Trade involvement; local tomato sourcing | Government support |

---

### 19.4 PALM OIL CIV OPERATORS

| Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------------|---------------------|-----------|--------------|---------------|
| Palm Oil Milling | **West Africa Palm Major** | **SIFCA Group / PalmCI (Cote d'Ivoire)** | West Africa's largest fully integrated palm player; 39,000 hectares industrial; 27,000 village planters; 10 mills; BRVM-listed | PalmCI: 60% supply from private planters; village plantation rehabilitation program; Dinor and Palme d'Or brands; leading UEMOA market share | **STRONGEST CANDIDATE** |
| Palm Oil Milling | **International Palm Major** | **Wilmar International (Singapore)** | 27% strategic stake in SIFCA; sources from PalmCI mills; world's largest palm oil trader; African expansion strategy | 27% SIFCA stake; PZ Wilmar full acquisition ($70M); 3 African refineries; 8 refineries through associates | Existing SIFCA relationship |
| Palm Oil Milling | **Regional Palm Operator** | **Socfin Group (Luxembourg/Belgium)** | Major African palm player; operations in Cameroon, Cote d'Ivoire, Ghana, Liberia, Nigeria, Sierra Leone; 91,000+ hectares | 91,207 hectares across 7 African countries; 319,289 MT palm oil production | Regional expertise |

---

## TABLE 20: KEY STAKEHOLDERS

### 20.1 GOVERNMENT BODIES BY COUNTRY

#### Côte d'Ivoire (PEA: AMBER-GREEN)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **PSTACI (Strategic Program for Aquaculture Transformation)** | $1.3B flagship program; 30 ZEAD zones | VERY HIGH | VERY HIGH | CORE PARTNER - existing relationship |
| **Ministry of Animal & Fisheries Resources (MIRAH)** | Aquaculture regulation, broodstock programs | HIGH | HIGH | Key partner for ProDeCAP; hatchery licensing |
| **Ministry of Agriculture, Rural Development & Food Production (MINADER)** | Lead agricultural policy; PSTACI oversight | HIGH | HIGH | Primary government partner |
| **Centre de Promotion des Investissements en Côte d'Ivoire (CEPICI)** | Investment promotion; business facilitation | HIGH | HIGH | Entry point for investors; 48-hour company registration |
| **CNRA (National Center for Agricultural Research)** | Broodstock genetics; aquaculture R&D | HIGH | MEDIUM | Technical partner with WorldFish |
| **ZEAD Zone Authorities** | Zone management; investor facilitation | HIGH | HIGH | Critical for site selection |
| **Customs Administration (DGD)** | Border clearance; ETLS implementation | MEDIUM | HIGH | Trade facilitation coordination |

#### Ghana (PEA: AMBER)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Ministry of Food and Agriculture (MoFA)** | Agricultural policy; tomato program | HIGH | HIGH | Key partner for tomato processing initiative |
| **Ghana Free Zones Authority (GFZA)** | EPZ regulation; investment incentives | MEDIUM | HIGH | Cold chain facility incentives |
| **Ghana Customs (GRA)** | Border management; revenue collection | MEDIUM | HIGH | ETLS implementation; trade facilitation |

#### Nigeria (PEA: AMBER)

| Ministry/Agency | Role | Interest Level | Influence | Engagement Strategy |
|----------------|------|----------------|-----------|---------------------|
| **Nigeria Customs Service (NCS)** | Border control; trade facilitation | HIGH | VERY HIGH | CRITICAL - modernization underway |
| **Federal Ministry of Agriculture & Food Security** | National ag policy; food security | HIGH | HIGH | Policy alignment; import substitution goals |
| **Federal Ministry of Marine & Blue Economy** | Fisheries/aquaculture oversight | HIGH | HIGH | Growing priority under new ministry |
| **Central Bank of Nigeria (CBN)** | Aquaculture financing; Anchor Borrowers | HIGH | HIGH | Trade finance facility potential |

---

### 20.2 REGIONAL BODIES

| Organization | Mandate | Relevance | Current Programs | Priority |
|--------------|---------|-----------|------------------|----------|
| **ECOWAS Commission** | Regional economic integration; trade liberalization | VERY HIGH - Core framework | ETLS (Trade Liberalization Scheme), EATM Scorecard | VERY HIGH |
| **UEMOA/WAEMU** | Monetary union; customs coordination | HIGH - 8 member states including CIV | Common External Tariff; agricultural harmonization | HIGH |
| **AfCFTA Secretariat** | Continental free trade implementation | HIGH - Long-term market access | Guided Trade Initiative; Agri-Food Trade Action Plan | HIGH |
| **CORAF** | Agricultural research coordination | MEDIUM - Technology & innovation | TARSPro project; seed systems; post-harvest research | MEDIUM |

---

### 20.3 DEVELOPMENT FINANCE INSTITUTIONS

| DFI | Current Programs | Likely Role | Ticket Size | Status |
|-----|-----------------|-------------|-------------|--------|
| **AfDB (African Development Bank)** | ProDeCAP ($25.6M CIV aquaculture); Feed Africa Strategy | LEAD DFI - anchor investor | $10-75M | ACTIVE |
| **IFC (World Bank Group)** | Agribusiness value chains; SME finance | Co-investor; trade finance | $5-25M | POTENTIAL |
| **Finnfund** | Sustainable agriculture; food security; Yalelo track record | Co-investor; aquaculture specialist | $5-15M | AVAILABLE |
| **Norfund** | Agribusiness; value chain development | Co-investor | $5-15M | AVAILABLE |
| **BII (British International Investment)** | CASA program; agribusiness | Technical assistance; co-investment | $5-20M | POTENTIAL |
| **FMO (Dutch Development Bank)** | Agribusiness, Food & Water sector | Syndicated financing | $5-20M | AVAILABLE |
| **Proparco (France)** | Agriculture; climate finance | Co-investor; value chains | $5-15M | AVAILABLE |
| **DEG (Germany)** | Sustainable agriculture | Syndicated financing | $5-15M | AVAILABLE |

---

### 20.4 PRIVATE SECTOR ASSOCIATIONS

| Association | Scope | Relevance | Engagement |
|-------------|-------|-----------|------------|
| **WACTAF** | West African cross-border trade in agro-forestry-fisheries | VERY HIGH - Corridor trade specialist | KEY PARTNER |
| **FEWACCI** | Federation of West African Chambers of Commerce | HIGH - Business advocacy | Policy dialogue |
| **ROPPA** | West African farmer organizations | HIGH - Farmer representation | Smallholder integration |
| **Chamber of Agribusiness Ghana (CAG)** | Ghana agribusiness sector | MEDIUM - Tomato value chain | Market intelligence |

---

### 20.5 STAKEHOLDER INFLUENCE MATRIX

#### KEY PLAYERS (High Interest + High Influence)
- AfDB (Lead DFI)
- CIV Government (MINADER/MIRAH/PSTACI)
- ProDeCAP Partners
- ECOWAS Trade Directorate
- De Heus/Koudijs
- WACTAF

#### KEEP SATISFIED
- CEPICI
- Ghana MoFA
- Nigeria Customs
- FEWACCI
- CNRA/WorldFish
- Lagos Offtakers

#### KEEP INFORMED
- ROPPA
- Farmer Cooperatives
- Cold Chain Associations
- Women's Networks

#### MONITOR
- AfCFTA Secretariat
- UEMOA/WAEMU
- Alliance of Sahel States

---

## TABLE 21: COMPREHENSIVE RISK ANALYSIS

### 21.1 POLITICAL/POLICY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| POL-001 | **Nigeria Export Ban Policy** | Nigerian government imposes fish import restrictions (historical precedent: 2015-2016 rice ban, periodic poultry bans) | HIGH | HIGH | AFSTI Policy Team | 1) Pre-negotiate quota agreements with FMARD 2) Build relationships with Nigerian Aquaculture Society 3) Position as "complementary" not competitive 4) Secure LOIs from Lagos offtakers with risk clauses | Pivot to 100% domestic CIV/Ghana markets; Phase 1 profitable standalone at $1.80/kg |
| POL-002 | **Border Closure (Nigeria-Benin)** | Nigeria closes Seme-Kraké border (historically: 2019 rice/poultry ban lasted 2+ years) | MEDIUM | HIGH | AFSTI + ECOWAS | 1) Diversify export routes (Togo, Ghana ports) 2) Pre-position inventory at Hub 2 buffer 3) Secure fast-track perishable corridor agreements | Route through Lomé port; Air freight premium fillets; Domestic market absorption |
| POL-003 | **ECOWAS Fragmentation** | Burkina Faso and Mali ECOWAS exit creates trade barriers | HIGH | MEDIUM | AFSTI + Regional Advisors | 1) Focus Phase 1-2 on CIV-Ghana-Nigeria triangle 2) Build bilateral agreements outside ECOWAS framework | Exclude Burkina/Mali from corridor logistics; Use maritime routes exclusively |
| POL-004 | **CIV Government Commitment Change** | Post-election policy shift reduces PSTACI support | MEDIUM | MEDIUM | AFSTI + CIV Ministry | 1) Multi-party MoU with binding terms 2) Performance-linked incentives (jobs, FX savings) | Accelerate Ghana anchor farm development; Reduce CIV exposure |
| POL-006 | **ZEAD Land Tenure Issues** | Disputes over aquaculture zone allocations, community resistance | MEDIUM | HIGH | Anchor Farm Operator + CIV Govt | 1) Pre-investment land audits with traditional authorities 2) Community benefit-sharing agreements (5-10% employment) | Relocate to secondary ZEAD sites; Negotiate lease terms |

---

### 21.2 ECONOMIC/MARKET RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ECO-001 | **Chinese Frozen Fish Dumping** | Chinese tilapia imports flood market at $1.45/kg, depressing local prices | HIGH | HIGH | Anchor Farm + Industry Association | 1) Quality differentiation (fresh vs. frozen) 2) "Made in CIV" branding campaign 3) Lobby for anti-dumping duties 4) Premium segment focus | Shift to processed/fillet products with higher margins; Export to premium West African markets |
| ECO-002 | **Feed Price Volatility** | Global soy/corn prices spike, De Heus factory delays, feed costs exceed $0.65/kg | MEDIUM | HIGH | Anchor Farm + Feed Partner | 1) 3-year feed price lock at $0.55/kg with De Heus 2) Strategic soy inventory (6-month buffer) 3) Alternative protein sources (insect meal, local soy) | Reduce FCR through genetics; Extend grow-out periods; Blend lower-cost feeds |
| ECO-003 | **CFA Franc Devaluation** | 15-20% devaluation against USD increases import costs, debt service burden | MEDIUM | HIGH | CFO + Treasury | 1) USD revenue matching (50%+ exports) 2) Local currency debt where possible 3) Currency hedging instruments (forward contracts) | Accelerate export ratio; Renegotiate debt terms; Cost pass-through to customers |
| ECO-004 | **Lagos Price Collapse** | Nigerian wholesale prices drop below $2.30/kg due to oversupply or demand shock | MEDIUM | MEDIUM | Commercial Team | 1) Diversified customer base (5+ offtakers) 2) Long-term contracts with floor prices 3) Value-added processing (fillets command $3.50+/kg) | Shift volumes to domestic markets; Reduce export ratio; Activate cold storage buffer |

---

### 21.3 OPERATIONAL/TECHNICAL RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| OPR-001 | **Hatchery Failure/Broodstock Disease** | GIFT strain underperforms, disease outbreak wipes out broodstock | MEDIUM | HIGH | Hatchery Manager + CNRA | 1) Multiple broodstock sources (WorldFish, Yalelo, local) 2) Biosecurity protocols (quarantine, testing) 3) Backup hatchery arrangements | Import fry from Ghana/Zambia; Extend grow-out cycles; Emergency restocking protocol |
| OPR-002 | **Feed Quality Inconsistency** | De Heus factory produces substandard feed, FCR exceeds 1.8 | MEDIUM | HIGH | Production Manager + QA | 1) Feed specification contracts with penalties 2) Monthly laboratory testing 3) Alternative supplier agreements (Aller Aqua, local) | Switch to alternative suppliers; Adjust feeding regimes; Source from Ghana/Zambia |
| OPR-003 | **Cold Chain Equipment Failure** | Hub refrigeration fails, reefer trucks break down, product spoilage | MEDIUM | HIGH | ColdChainCo Operations | 1) Redundant cooling systems (N+1) 2) Preventive maintenance contracts 3) 24/7 monitoring systems | Backup generators; Mobile refrigeration units; Insurance coverage for spoilage |
| OPR-004 | **Border Delays Exceeding Limits** | Customs processing >48 hours, documentation errors, inspection backlogs | HIGH | MEDIUM | ColdChainCo + Border Facilitation | 1) Pre-clearance systems (single window) 2) Dedicated perishable lanes 3) Digital documentation | Air freight for premium products; Local processing to bypass raw restrictions; Buffer inventory |
| OPR-005 | **Anchor Farm Underperformance** | Production fails to reach 5K MT by Year 3, mortality >20%, FCR >1.8 | MEDIUM | HIGH | Anchor Farm GM + AFSTI TA | 1) Sequential gating with performance milestones 2) Yalelo/Tropo technical assistance 3) Monthly production reviews | Extend timeline; Reduce outgrower commitments; Bring in professional operator |
| OPR-006 | **Outgrower Coordination Failure** | Smallholders don't meet quality standards, delivery unreliable, side-selling | HIGH | MEDIUM | Outgrower Coordinator | 1) Formal contracts with penalties/incentives 2) Extension services and training 3) Input financing (fingerlings, feed on credit) | Reduce outgrower ratio; Increase anchor farm capacity; Vertical integration |

---

### 21.4 ENVIRONMENTAL/CLIMATE RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ENV-001 | **Lake Water Quality Deterioration** | Agricultural runoff, industrial pollution, eutrophication affecting fish health | MEDIUM | HIGH | Environmental Manager + Govt | 1) Watershed management programs 2) Regular water quality monitoring 3) Cage site rotation | Filtered water systems; Relocate to better sites; Intensive water quality management |
| ENV-002 | **Climate Change Production Impact** | Rising water temperatures reduce growth rates, alter seasonal patterns | HIGH | MEDIUM | Production Manager | 1) Heat-tolerant strain selection (GIFT+) 2) Deeper cage positioning 3) Shade structures | Adjust feeding regimes; Reduce stocking density; Genetic improvement program |
| ENV-004 | **Fish Disease Outbreak** | Streptococcus, columnaris, or viral outbreaks cause mass mortality | MEDIUM | HIGH | Veterinary Manager | 1) Biosecurity protocols (quarantine, disinfection) 2) Vaccination programs 3) Health monitoring (weekly sampling) | Emergency harvest; Antibiotic treatment (last resort); Restocking from clean sources |

---

### 21.5 SOCIAL/COMMUNITY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| SOC-001 | **Community Land Conflicts** | Local communities dispute ZEAD allocations, demand compensation, block access | MEDIUM | HIGH | Community Relations + Govt | 1) FPIC (Free, Prior, Informed Consent) process 2) Community benefit-sharing agreements (5-10% employment) 3) Traditional authority engagement | Legal arbitration; Relocate to alternative sites; Enhanced compensation |
| SOC-004 | **Smallholder Integration Difficulties** | Outgrowers lack technical capacity, cannot meet standards, drop out of program | HIGH | MEDIUM | Outgrower Coordinator | 1) Comprehensive training programs 2) Input financing and credit 3) Technical assistance (extension agents) | Reduce outgrower targets; Increase anchor farm focus; Pay premium for lower quality |

---

### 21.6 FINANCIAL/CURRENCY RISKS

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| FIN-001 | **DFI Funding Gap** | DFI commitments don't materialize, funding shortfall delays project | MEDIUM | HIGH | CFO + AFSTI Fundraising | 1) Multiple DFI pipeline (AfDB, IFC, Finnfund, BII) 2) Phased commitments linked to milestones 3) Alternative funding sources (impact investors) | Reduce Phase 1 scope; Delay non-critical investments; Seek commercial co-investors |
| FIN-002 | **Currency Mismatch (USD Debt vs Local Revenue)** | CFA revenue cannot service USD debt during devaluation | MEDIUM | HIGH | CFO + Treasury | 1) 50%+ USD revenue from exports 2) Local currency debt where available 3) Currency hedging (forwards, options) | Renegotiate debt terms; Increase export ratio; Debt rescheduling |
| FIN-004 | **Counterparty Default (Offtakers)** | Lagos wholesalers fail to pay, contracts unenforceable across borders | MEDIUM | HIGH | Commercial Manager | 1) Credit insurance (ATPC, ECIC) 2) Letters of credit for exports 3) Diversified customer base (5+ offtakers) 4) Parent company guarantees | Domestic market pivot; Legal action; Credit insurance claims |
| FIN-006 | **Cash Flow Timing Mismatch** | Revenue lags behind costs during ramp, liquidity crisis in Years 2-3 | HIGH | HIGH | CFO + Treasury | 1) Working capital facility ($2-3M) 2) Phased CAPEX deployment 3) Grant funding for early years 4) Contingency reserves (10% of CAPEX) | Draw on contingency; Delay non-essential spending; Seek bridge financing |

---

### 21.7 RISK INTERDEPENDENCY MAP

```
PRIMARY RISKS (Triggers)
═══════════════════════════════════════════════════════════════════════════════

POL-001: Nigeria Export Ban ──┬──► ECO-004: Lagos Price Collapse
                              │    └──► FIN-004: Counterparty Default
                              │         └──► FIN-006: Cash Flow Crisis
                              │
                              └──► OPR-004: Border Delays
                                   └──► ColdChainCo Underutilization
                                        └──► FIN-003: Working Capital Constraints

POL-002: Border Closure ──────┬──► OPR-004: Border Delays (compounded)
                              │
                              └──► ECO-004: Lagos Price Collapse
                                   └──► [Same cascade as above]

ECO-002: Feed Price Spike ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► FIN-006: Cash Flow Crisis
                              │
                              └──► FIN-002: Currency Mismatch (if USD feed)

ENV-004: Disease Outbreak ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► [Same cascade as above]
                              │
                              └──► OPR-001: Hatchery Failure
                                   └──► Production Cascade Failure

FIN-001: DFI Funding Gap ─────┬──► FIN-006: Cash Flow Crisis
                              │
                              └──► Delayed ColdChainCo
                                   └──► ECO-004: Lagos Price Collapse
                                        └──► [Same cascade as above]

SOC-001: Land Conflicts ──────► Delayed Anchor Farm
                              └──► OPR-005: Underperformance
                                   └──► [Same cascade as above]
```

---

### 21.8 TOP 10 CRITICAL RISKS SUMMARY

| Rank | Risk ID | Risk | Probability | Impact | Combined Score |
|------|---------|------|-------------|--------|----------------|
| 1 | POL-001 | Nigeria Export Ban | HIGH | HIGH | **CRITICAL** |
| 2 | ECO-001 | Chinese Fish Dumping | HIGH | HIGH | **CRITICAL** |
| 3 | FIN-006 | Cash Flow Timing | HIGH | HIGH | **CRITICAL** |
| 4 | OPR-005 | Anchor Farm Underperformance | MEDIUM | HIGH | **HIGH** |
| 5 | ECO-002 | Feed Price Volatility | MEDIUM | HIGH | **HIGH** |
| 6 | POL-002 | Border Closure | MEDIUM | HIGH | **HIGH** |
| 7 | FIN-002 | Currency Mismatch | MEDIUM | HIGH | **HIGH** |
| 8 | OPR-001 | Hatchery Failure | MEDIUM | HIGH | **HIGH** |
| 9 | OPR-003 | Cold Chain Failure | MEDIUM | HIGH | **HIGH** |
| 10 | SOC-001 | Community Land Conflicts | MEDIUM | HIGH | **HIGH** |

---

### 21.9 RISK-ADJUSTED RETURNS

| Scenario | Probability | IRR | NPV @ 10% |
|----------|-------------|-----|-----------|
| Bull Case (risks mitigated) | 25% | 25% | $30M |
| Base Case (expected risks) | 50% | **22.2%** | **$10.2M** |
| Bear Case (major risk event) | 20% | 8-10% | $2-5M |
| Failure (catastrophic) | 5% | -10% | -$5M |
| **Probability-Weighted** | **100%** | **18.5%** | **$12.8M** |

---

### 21.10 IMMEDIATE RISK MITIGATION ACTIONS

#### Immediate Actions (0-6 months)
1. **Secure Political Risk Insurance** for Nigeria export exposure (MIGA/ATPC)
2. **Negotiate feed price lock** with De Heus at $0.55/kg for 3 years
3. **Establish working capital facility** of $2-3M for cash flow management
4. **Complete FPIC process** for all ZEAD sites before construction
5. **Secure letters of intent** from 3+ Lagos offtakers with risk clauses

#### Short-Term Actions (6-18 months)
1. **Implement sequential gating** with clear go/no-go criteria
2. **Establish risk monitoring dashboard** with automated alerts
3. **Negotiate quota agreements** with Nigerian FMARD
4. **Diversify export routes** through Togo and Ghana ports
5. **Build community benefit-sharing** agreements with local stakeholders

---

## APPENDIX: BINDING CONSTRAINTS FRAMEWORK (from aquaculture_binding_constraints_v02.pptx)

### The Six Constraints (in order of priority)

| Priority | Constraint | Current State | Binding? | AFSTI Solution |
|----------|-----------|---------------|----------|----------------|
| **#1** | **Fingerlings (Fry)** | CNRA capacity grossly insufficient; High larval mortality; No commercial hatchery | **BINDING** | Commercial hatchery ($3-5M) with ProDeCAP |
| **#2** | **Feed Supply** | Imported $0.82/kg; Local artisanal low quality; De Heus exists but needs aquafeed line | **BINDING** | Aquafeed co-investment ($2-4M) with De Heus/Aller Aqua |
| **#3** | **Production Scale** | 1,800 farms averaging <1 MT each; No anchor enterprise | **FOLLOWS #1+#2** | Anchor farm + outgrowers ($5-8M) |
| **#4** | **Cold Chain** | Near-zero for fish; ~25% post-harvest loss | **PHASE 2** | ColdChainCo ($10-15M) - separate investment |
| **#5** | **Corridor Transport** | Trucks exist, no reefer fleet; $0.18/kg Abidjan-Lagos | **PHASE 2** | Reefer fleet ($3-4M) |
| **#6** | **End Market** | $3.5B import market; Lagos/Accra ready buyers | **READY** | Blended offtake contracts |

**Key Insight:** Fingerlings (#1) and Feed (#2) are the ROOT binding constraints. Production (#3) cannot scale without them. Cold chain (#4) and aggregation only matter AFTER production reaches scale. This is the lesson of Yalelo: solve inputs first, production follows, infrastructure last.

---

## DOCUMENT SOURCES

| Source File | Data Extracted |
|-------------|----------------|
| AFSTI_Aquaculture_Investment_Case_V5.pptx | Investment logic, 5 sequenced investments, anchor farm candidates, key partners, risk matrix, ColdChainCo details |
| AFSTI_Aquaculture_Financial_Model_V4.xlsx | 10-year P&L, production parameters, price sensitivity matrix, production ramp 2025-2035, supply security calendar, returns summary |
| aquaculture_binding_constraints_v02.pptx | 6 binding constraints framework, root cause analysis |
| https://zweli-gif.github.io/AFSTI/ | Design language, corridor context, PEA ratings |

---

*Document prepared for AFSTI Dakar-Lagos Corridor Play*
*Date: February 2026*
*Complete data extraction with real figures from source files*

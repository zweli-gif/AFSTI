# COMPREHENSIVE RISK ANALYSIS
## Dakar-Lagos Corridor Play — AFSTI Project
### Investment Scale: $74-150M | 6 Countries | 4 Value Chains + Enablers

---

## EXECUTIVE SUMMARY

This risk analysis covers the integrated Dakar-Lagos Corridor Play spanning six West African countries (Côte d'Ivoire, Ghana, Nigeria, Senegal, Burkina Faso, Mali) with total investment of $74-150M across aquaculture, tomato processing, palm oil, cold chain infrastructure, trade finance, and border facilitation.

**Overall Risk Profile: MODERATE-HIGH (AMBER)**

The corridor faces elevated political/policy risks due to ECOWAS fragmentation, border volatility (especially Nigeria), and security concerns in Burkina Faso and Mali. However, strong mitigations exist through domestic market absorption, diversified revenue streams, and sequential gating mechanisms.

**Critical Risk Thresholds:**
- 3 risks rated HIGH probability + HIGH impact requiring immediate mitigation
- 12 risks rated MEDIUM-HIGH requiring active monitoring
- All risks have defined owners and contingency plans

---

## 1. POLITICAL/POLICY RISKS

### 1.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| POL-001 | **Nigeria Export Ban Policy** | Nigerian government imposes fish import restrictions or bans to protect domestic producers (historical precedent: 2015-2016 rice ban, periodic poultry bans) | HIGH | HIGH | AFSTI Policy Team + AGRA | 1) Pre-negotiate quota agreements with FMARD 2) Build relationships with Nigerian Aquaculture Society 3) Position as "complementary" not competitive to local production 4) Secure letters of intent from Lagos offtakers with political risk clauses | Pivot to 100% domestic CIV/Ghana markets; Phase 1 profitable standalone at $1.80/kg domestic price |
| POL-002 | **Border Closure (Nigeria-Benin)** | Nigeria closes Seme-Kraké border (historically: 2019 rice/poultry ban lasted 2+ years) | MEDIUM | HIGH | AFSTI + ECOWAS Secretariat | 1) Diversify export routes (Togo, Ghana ports) 2) Pre-position inventory at Hub 2 buffer 3) Secure fast-track perishable corridor agreements 4) Build Ghana market as alternative | Route through Lomé port to eastern Nigeria; Air freight premium fillets to Lagos; Domestic market absorption |
| POL-003 | **ECOWAS Fragmentation** | Burkina Faso and Mali ECOWAS exit creates trade barriers, visa restrictions, customs complexity | HIGH | MEDIUM | AFSTI + Regional Trade Advisors | 1) Focus Phase 1-2 on CIV-Ghana-Nigeria triangle 2) Build bilateral agreements outside ECOWAS framework 3) Establish separate legal entities per country 4) Avoid Burkina/Mali routing until stability returns | Exclude Burkina/Mali from corridor logistics; Use maritime routes exclusively; Wait for reintegration |
| POL-004 | **CIV Government Commitment Change** | Post-election policy shift reduces PSTACI support, ZEAD access delays, permit revocations | MEDIUM | MEDIUM | AFSTI + CIV Ministry of Fisheries | 1) Multi-party MoU with binding terms 2) Performance-linked incentives (jobs, FX savings) 3) Opposition party briefings for continuity 4) International visibility (World Bank, AfDB) | Accelerate Ghana anchor farm development; Reduce CIV exposure to processing only |
| POL-005 | **Ghana Election Cycle Disruption** | 2024/2028 elections create policy uncertainty, tomato processing incentives change | MEDIUM | MEDIUM | AFSTI + Ghana MOFA | 1) Cross-party engagement before elections 2) Local employment commitments in swing regions 3) Align with "Planting for Food and Jobs" program 4) Secure parliamentary committee endorsements | Shift tomato volumes to CIV processing; Delay Ghana expansion until post-election clarity |
| POL-006 | **ZEAD Land Tenure Issues** | Disputes over aquaculture zone allocations, community resistance, overlapping claims | MEDIUM | HIGH | Anchor Farm Operator + CIV Govt | 1) Pre-investment land audits with traditional authorities 2) Community benefit-sharing agreements (5-10% employment) 3) Formal registration with CNRA 4) Escrow for land compensation | Relocate to secondary ZEAD sites; Negotiate lease terms vs. ownership; Legal arbitration |
| POL-007 | **SPS/Phytosanitary Rule Changes** | New certification requirements, testing protocols, border inspection delays | MEDIUM | MEDIUM | ColdChainCo + National Standards Bodies | 1) Pre-emptive compliance with EU-equivalent standards 2) Laboratory partnerships for rapid testing 3) Digital certification systems 4) Training for border officials | In-country processing to bypass raw material restrictions; Upgrade to meet new standards |
| POL-008 | **Trade Finance Regulatory Changes** | Central bank restrictions on foreign currency lending, interest rate caps, DFI eligibility | LOW | MEDIUM | Trade Finance Facility Manager | 1) Multi-currency facility structures 2) Local currency hedging instruments 3) Relationships with central bank governors 4) Compliance with Basel/IFC standards | Shift to supplier credit structures; Reduce facility size; Focus on hard currency commodities |

### 1.2 Political Risk Deep Dive

**Nigeria Export Ban (POL-001) — CRITICAL RISK**

Nigeria has demonstrated willingness to impose import bans despite WTO/ECOWAS commitments:
- 2015: Rice import ban (still partially enforced)
- 2016-2019: Poultry import ban (intermittent)
- 2019: Border closure with Benin (2+ years)

**Probability Assessment: HIGH (60-70%)**
- Nigerian aquaculture production growing 15% annually
- Government "backward integration" policy push
- Election cycles drive protectionist rhetoric

**Impact Assessment: HIGH**
- Export volumes: 50K MT at risk by 2035 ($142M revenue)
- ColdChainCo utilisation drops 40%
- IRR falls from 22% to 8-10% (bear case)

**Mitigation Effectiveness:**
| Strategy | Effectiveness | Cost | Timeline |
|----------|--------------|------|----------|
| FMARD quota negotiation | 70% | $200K lobbying | 12-18 months |
| Position as complementary | 60% | $100K positioning | Ongoing |
| Political risk insurance | 80% | 2-3% premium | Immediate |
| Domestic market pivot | 100% | Lost upside | Contingency |

---

## 2. ECONOMIC/MARKET RISKS

### 2.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ECO-001 | **Chinese Frozen Fish Dumping** | Chinese tilapia imports flood market at $1.45/kg, depressing local prices | HIGH | HIGH | Anchor Farm + Industry Association | 1) Quality differentiation (fresh vs. frozen) 2) "Made in CIV" branding campaign 3) Lobby for anti-dumping duties 4) Premium segment focus (hotels, restaurants) | Shift to processed/fillet products with higher margins; Export to premium West African markets |
| ECO-002 | **Feed Price Volatility** | Global soy/corn prices spike, De Heus factory delays, feed costs exceed $0.65/kg | MEDIUM | HIGH | Anchor Farm + Feed Partner | 1) 3-year feed price lock at $0.55/kg with De Heus 2) Strategic soy inventory (6-month buffer) 3) Alternative protein sources (insect meal, local soy) 4) Price escalation clauses in offtake contracts | Reduce FCR through genetics; Extend grow-out periods; Blend lower-cost feeds |
| ECO-003 | **CFA Franc Devaluation** | 15-20% devaluation against USD increases import costs, debt service burden | MEDIUM | HIGH | CFO + Treasury | 1) USD revenue matching (50%+ exports) 2) Local currency debt where possible 3) Natural hedging through CFA-denominated costs 4) Currency hedging instruments (forward contracts) | Accelerate export ratio; Renegotiate debt terms; Cost pass-through to customers |
| ECO-004 | **Lagos Price Collapse** | Nigerian wholesale prices drop below $2.30/kg due to oversupply or demand shock | MEDIUM | MEDIUM | Commercial Team | 1) Diversified customer base (5+ offtakers) 2) Long-term contracts with floor prices 3) Value-added processing (fillets command $3.50+/kg) 4) Alternative markets (Accra, Lomé, Dakar) | Shift volumes to domestic markets; Reduce export ratio; Activate cold storage buffer |
| ECO-005 | **Tomato Price Volatility** | Ghana tomato prices swing ±40% due to seasonal gluts, import competition | HIGH | MEDIUM | Tomato VC Manager | 1) Processing capacity to absorb gluts 2) Cold storage for price arbitrage 3) Contract farming with floor prices 4) Export to Nigeria during scarcity | Process to paste for shelf stability; Reduce fresh tomato exposure; Pivot to other vegetables |
| ECO-006 | **Palm Oil Price Collapse** | Global CPO prices drop below $700/MT making CIV processing uneconomic | MEDIUM | MEDIUM | Palm Oil VC Manager | 1) Conditional investment triggers at price thresholds 2) Integrated processing (refining adds margin) 3) Long-term supply contracts with manufacturers 4) Biodiesel offtake agreements | Delay palm oil investment; Focus on high-value derivatives; Exit to traders at cost |
| ECO-007 | **Interest Rate Spike** | Regional rates rise above 15%, increasing debt service, reducing project IRR | MEDIUM | MEDIUM | CFO + DFI Partners | 1) Fixed-rate concessional debt (8-10%) 2) Long tenors (10-12 years) 3) Grace periods during ramp (3-5 years) 4) Blended finance to reduce weighted cost | Extend grace periods; Convert to equity; Reduce leverage ratio |
| ECO-008 | **Global Recession/Demand Shock** | Economic downturn reduces protein demand, hotel/restaurant closures | MEDIUM | MEDIUM | Commercial Team | 1) Retail channel diversification 2) Lower-cost product lines 3) Government institutional contracts 4) Regional market diversification | Focus on affordable whole fish; Reduce premium segment exposure; Activate domestic programs |

### 2.2 Economic Risk Deep Dive

**Chinese Frozen Fish Dumping (ECO-001) — CRITICAL RISK**

China exported 2.3M MT of frozen tilapia globally in 2023, with significant volumes reaching West Africa at $1.20-1.50/kg landed cost.

**Market Dynamics:**
| Segment | Chinese Price | CIV Target Price | Competitive Position |
|---------|---------------|------------------|---------------------|
| Frozen whole | $1.45/kg | N/A | Chinese advantage |
| Fresh whole | N/A | $1.80/kg | CIV advantage |
| Frozen fillets | $2.80/kg | $3.20/kg | Quality differentiation |
| Fresh fillets | N/A | $4.50/kg | Premium positioning |

**Mitigation Strategy Effectiveness:**
- Fresh positioning: 80% effective (transport cost barrier for Chinese)
- Premium branding: 60% effective (requires consumer education)
- Anti-dumping duties: 40% effective (enforcement challenges)

---

## 3. OPERATIONAL/TECHNICAL RISKS

### 3.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| OPR-001 | **Hatchery Failure/Broodstock Disease** | GIFT strain underperforms, disease outbreak wipes out broodstock, fry supply interrupted | MEDIUM | HIGH | Hatchery Manager + CNRA | 1) Multiple broodstock sources (WorldFish, Yalelo, local) 2) Biosecurity protocols (quarantine, testing) 3) Backup hatchery arrangements 4) Genetic diversity maintenance | Import fry from Ghana/Zambia; Extend grow-out cycles; Emergency restocking protocol |
| OPR-002 | **Feed Quality Inconsistency** | De Heus factory produces substandard feed, FCR exceeds 1.8, growth rates decline | MEDIUM | HIGH | Production Manager + QA | 1) Feed specification contracts with penalties 2) Monthly laboratory testing 3) Alternative supplier agreements (Skretting, local) 4) On-site feed storage quality control | Switch to alternative suppliers; Adjust feeding regimes; Source from Ghana/Zambia |
| OPR-003 | **Cold Chain Equipment Failure** | Hub refrigeration fails, reefer trucks break down, product spoilage | MEDIUM | HIGH | ColdChainCo Operations | 1) Redundant cooling systems (N+1) 2) Preventive maintenance contracts 3) 24/7 monitoring systems 4) Emergency repair networks | Backup generators; Mobile refrigeration units; Insurance coverage for spoilage |
| OPR-004 | **Border Delays Exceeding Limits** | Customs processing >48 hours, documentation errors, inspection backlogs | HIGH | MEDIUM | ColdChainCo + Border Facilitation | 1) Pre-clearance systems (single window) 2) Dedicated perishable lanes 3) Digital documentation 4) Relationships with customs officials | Air freight for premium products; Local processing to bypass raw restrictions; Buffer inventory |
| OPR-005 | **Anchor Farm Underperformance** | Production fails to reach 5K MT by Year 3, mortality >20%, FCR >1.8 | MEDIUM | HIGH | Anchor Farm GM + AFSTI TA | 1) Sequential gating with performance milestones 2) Yalelo/Tropo technical assistance 3) Monthly production reviews 4) Early intervention protocols | Extend timeline; Reduce outgrower commitments; Bring in professional operator |
| OPR-006 | **Outgrower Coordination Failure** | Smallholders don't meet quality standards, delivery unreliable, side-selling | HIGH | MEDIUM | Outgrower Coordinator | 1) Formal contracts with penalties/incentives 2) Extension services and training 3) Input financing (fingerlings, feed on credit) 4) Collection center network | Reduce outgrower ratio; Increase anchor farm capacity; Vertical integration |
| OPR-007 | **Processing Equipment Failure** | Filleting line breakdown, blast freezer malfunction, packaging issues | LOW | MEDIUM | Processing Manager | 1) Equipment redundancy (backup lines) 2) Maintenance contracts with OEMs 3) Spare parts inventory 4) Operator training programs | Outsource processing to third parties; Manual processing backup; Reduce processing ratio |
| OPR-008 | **Water Quality Degradation** | Lake Kossou pollution, algae blooms, oxygen depletion affecting fish health | MEDIUM | MEDIUM | Environmental Manager | 1) Water quality monitoring (weekly) 2) Cage positioning optimization 3) Aeration systems 4) Government pollution control advocacy | Relocate cages to deeper water; Reduce stocking density; Water treatment systems |
| OPR-009 | **Skills Gap/Staff Turnover** | Key technical staff leave, local talent pool insufficient, knowledge loss | MEDIUM | MEDIUM | HR Manager + Training | 1) Competitive compensation packages 2) Career development programs 3) International training placements 4) Documentation and SOPs | Expat technical support; Regional recruitment; University partnerships |

### 3.2 Operational Risk Deep Dive

**Anchor Farm Underperformance (OPR-005) — CRITICAL RISK**

The entire corridor play depends on anchor farm reaching 5K MT by Year 3 and 10K MT by Year 5.

**Performance Gating Framework:**
| Gate | Timeline | Target | Review Criteria | Decision |
|------|----------|--------|-----------------|----------|
| Gate 0 | Yr 1 Q4 | 1,500 MT | Hatchery operational, FCR <1.6 | Proceed to Phase 2 |
| Gate 1 | Yr 2 Q4 | 5,000 MT | Mortality <15%, cash flow positive | Proceed to Phase 3 |
| Gate 2 | Yr 3 Q4 | 8,000 MT | Processing economics proven | Proceed to ColdChainCo |
| Gate 3 | Yr 4 Q4 | 10,000 MT | Export volumes confirmed | Full corridor activation |

**Early Warning Indicators:**
- Monthly mortality rate >10% for 2 consecutive months
- FCR >1.7 for 3 consecutive months
- Growth rate <80% of target for 2 consecutive cycles

---

## 4. ENVIRONMENTAL/CLIMATE RISKS

### 4.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| ENV-001 | **Lake Water Quality Deterioration** | Agricultural runoff, industrial pollution, eutrophication affecting fish health | MEDIUM | HIGH | Environmental Manager + Govt | 1) Watershed management programs 2) Regular water quality monitoring 3) Cage site rotation 4) Advocacy for pollution controls | Filtered water systems; Relocate to better sites; Intensive water quality management |
| ENV-002 | **Climate Change Production Impact** | Rising water temperatures reduce growth rates, alter seasonal patterns | HIGH | MEDIUM | Production Manager | 1) Heat-tolerant strain selection (GIFT+) 2) Deeper cage positioning 3) Shade structures 4) Seasonal stocking adjustments | Adjust feeding regimes; Reduce stocking density; Genetic improvement program |
| ENV-003 | **Extreme Weather Events** | Floods damage cages, storms disrupt logistics, drought affects water levels | MEDIUM | MEDIUM | Operations + Risk Manager | 1) Weather monitoring and early warning 2) Reinforced cage anchoring 3) Insurance coverage (crop, asset) 4) Emergency response plans | Emergency harvesting; Temporary relocation; Insurance claims |
| ENV-004 | **Fish Disease Outbreak** | Streptococcus, columnaris, or viral outbreaks cause mass mortality | MEDIUM | HIGH | Veterinary Manager | 1) Biosecurity protocols (quarantine, disinfection) 2) Vaccination programs 3) Health monitoring (weekly sampling) 4) Rapid response isolation | Emergency harvest; Antibiotic treatment (last resort); Restocking from clean sources |
| ENV-005 | **Harmful Algal Blooms** | Toxic algae reduce oxygen, produce toxins affecting fish and human health | MEDIUM | MEDIUM | Environmental Manager | 1) Algae monitoring systems 2) Early warning protocols 3) Aeration systems 4) Site selection away from nutrient sources | Emergency relocation; Water exchange; Filtration systems |
| ENV-006 | **Drought/Water Level Decline** | Lake Kossou water levels drop, reducing cage volume, concentrating pollutants | LOW | MEDIUM | Production Manager | 1) Multi-site diversification 2) Flexible cage configurations 3) Water level monitoring 4) Alternative water sources | Reduce stocking density; Emergency harvest; Temporary suspension |

### 4.2 Environmental Risk Deep Dive

**Climate Change Production Impact (ENV-002) — HIGH PRIORITY**

West African temperatures projected to rise 1.5-2.0°C by 2050, with significant impacts on aquaculture.

**Temperature-Growth Relationship:**
| Water Temperature | Growth Rate Impact | Mitigation Required |
|-------------------|-------------------|---------------------|
| 26-28°C (optimal) | 100% | None |
| 28-30°C | 90% | Increased aeration |
| 30-32°C | 75% | Shade, deeper cages |
| >32°C | 60% | Major intervention |

**Adaptation Measures:**
1. Strain selection: GIFT+ heat-tolerant lines (WorldFish program)
2. Infrastructure: Shade nets, deeper cages (8-10m vs 5m)
3. Management: Reduced stocking density, adjusted feeding times

---

## 5. SOCIAL/COMMUNITY RISKS

### 5.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| SOC-001 | **Community Land Conflicts** | Local communities dispute ZEAD allocations, demand compensation, block access | MEDIUM | HIGH | Community Relations + Govt | 1) FPIC (Free, Prior, Informed Consent) process 2) Community benefit-sharing agreements 3) Traditional authority engagement 4) Grievance mechanisms | Legal arbitration; Relocate to alternative sites; Enhanced compensation |
| SOC-002 | **Employment Disputes** | Labor unrest, unionization challenges, wage disputes affecting operations | MEDIUM | MEDIUM | HR Manager + Legal | 1) Competitive wages (above minimum +20%) 2) Clear employment contracts 3) Worker representation 4) Dispute resolution mechanisms | Mediation; Legal action; Operational adjustments |
| SOC-003 | **Gender Inclusion Challenges** | Women excluded from outgrower programs, leadership positions, technical roles | MEDIUM | MEDIUM | Gender Specialist + HR | 1) 40% women target for employment 2) Women-focused extension services 3) Childcare facilities 4) Leadership training programs | Partner with women's cooperatives; Targeted recruitment; Flexible work arrangements |
| SOC-004 | **Smallholder Integration Difficulties** | Outgrowers lack technical capacity, cannot meet standards, drop out of program | HIGH | MEDIUM | Outgrower Coordinator | 1) Comprehensive training programs 2) Input financing and credit 3) Technical assistance (extension agents) 4) Group formation for collective bargaining | Reduce outgrower targets; Increase anchor farm focus; Pay premium for lower quality |
| SOC-005 | **Youth Unemployment Tensions** | High youth unemployment creates social pressure, expectations not met | MEDIUM | MEDIUM | Community Relations | 1) Youth employment targets (60% under 35) 2) Skills training and apprenticeships 3) Local procurement preferences 4) Community development projects | Expand training programs; Partner with vocational schools; Increase local hiring |
| SOC-006 | **Conflict with Existing Fishers** | Wild capture fishers view aquaculture as competition, sabotage cages | LOW | HIGH | Community Relations | 1) Inclusive dialogue with fisher associations 2) Employment opportunities for fishers 3) No-fishing zone compensation 4) Co-management agreements | Security measures; Legal protection; Relocation |

### 5.2 Social Risk Deep Dive

**Community Land Conflicts (SOC-001) — HIGH PRIORITY**

Lake Kossou and ZEAD zones involve complex land tenure systems combining customary, state, and individual rights.

**Stakeholder Mapping:**
| Stakeholder | Interest | Influence | Engagement Strategy |
|-------------|----------|-----------|---------------------|
| Traditional chiefs | Land authority, community welfare | HIGH | Direct negotiation, ceremonial recognition |
| Local government | Tax revenue, employment | MEDIUM | Formal agreements, reporting |
| Community members | Jobs, development | HIGH | FPIC process, benefit-sharing |
| Existing users | Access rights | MEDIUM | Compensation, alternative livelihoods |
| National government | Policy alignment | HIGH | PSTACI coordination, permits |

**Benefit-Sharing Framework:**
- 5-10% of jobs reserved for local community
- 2% of revenue to community development fund
- Preferential procurement from local suppliers
- Infrastructure investments (roads, water, schools)

---

## 6. FINANCIAL/CURRENCY RISKS

### 6.1 Risk Register

| Risk ID | Risk | Description | Probability | Impact | Risk Owner | Mitigation Strategy | Contingency |
|---------|------|-------------|-------------|--------|------------|---------------------|-------------|
| FIN-001 | **DFI Funding Gap** | DFI commitments don't materialize, funding shortfall delays project | MEDIUM | HIGH | CFO + AFSTI Fundraising | 1) Multiple DFI pipeline (AfDB, IFC, Finnfund, BII) 2) Phased commitments linked to milestones 3) Alternative funding sources (impact investors) 4) Contingency budget reduction | Reduce Phase 1 scope; Delay non-critical investments; Seek commercial co-investors |
| FIN-002 | **Currency Mismatch (USD Debt vs Local Revenue)** | CFA revenue cannot service USD debt during devaluation | MEDIUM | HIGH | CFO + Treasury | 1) 50%+ USD revenue from exports 2) Local currency debt where available 3) Currency hedging (forwards, options) 4) Natural hedging (CFA-denominated costs) | Renegotiate debt terms; Increase export ratio; Debt rescheduling |
| FIN-003 | **Working Capital Constraints** | Trade finance facility insufficient, SME borrowers default, liquidity crisis | MEDIUM | MEDIUM | Trade Finance Manager | 1) Conservative facility sizing ($30-75M range) 2) First-loss protection from grants 3) Credit risk assessment protocols 4) Diversified borrower portfolio | Reduce facility size; Tighten credit standards; Recapitalize from DFIs |
| FIN-004 | **Counterparty Default (Offtakers)** | Lagos wholesalers fail to pay, contracts unenforceable across borders | MEDIUM | HIGH | Commercial Manager | 1) Credit insurance (ATPC, ECIC) 2) Letters of credit for exports 3) Diversified customer base (5+ offtakers) 4) Parent company guarantees | Domestic market pivot; Legal action; Credit insurance claims |
| FIN-005 | **Interest Rate Volatility** | Regional rates rise, debt service increases, project economics deteriorate | MEDIUM | MEDIUM | CFO | 1) Fixed-rate concessional debt 2) Long tenors (10-12 years) 3) Grace periods (3-5 years) 4) Interest rate caps | Refinancing; Extend grace periods; Equity conversion |
| FIN-006 | **Cash Flow Timing Mismatch** | Revenue lags behind costs during ramp, liquidity crisis in Years 2-3 | HIGH | HIGH | CFO + Treasury | 1) Working capital facility ($2-3M) 2) Phased CAPEX deployment 3) Grant funding for early years 4) Contingency reserves (10% of CAPEX) | Draw on contingency; Delay non-essential spending; Seek bridge financing |
| FIN-007 | **Tax/Regulatory Changes** | New taxes, withholding changes, double taxation issues | MEDIUM | MEDIUM | Tax Advisor + Legal | 1) Tax incentive negotiations 2) Double taxation treaties 3) Transfer pricing documentation 4) Local tax compliance | Tax planning; Legal challenges; Pass-through to customers |
| FIN-008 | **Insurance Market Capacity** | Political risk, crop insurance unavailable or prohibitively expensive | LOW | MEDIUM | Risk Manager | 1) DFI political risk guarantees 2) Regional insurance pools 3) Self-insurance reserves 4) Multilateral insurance (MIGA, ATPC) | Self-insurance; Risk retention; Alternative structures |

### 6.2 Financial Risk Deep Dive

**Cash Flow Timing Mismatch (FIN-006) — CRITICAL RISK**

Years 2-3 represent the highest liquidity risk as production ramps but revenue insufficient to cover costs.

**Cash Flow Profile:**
| Year | CAPEX | Operating Cash Flow | Net Cash Flow | Cumulative |
|------|-------|---------------------|---------------|------------|
| 1 | $8M | -$2M | -$10M | -$10M |
| 2 | $6M | -$1M | -$7M | -$17M |
| 3 | $4M | $1M | -$3M | -$20M |
| 4 | $2M | $3M | $1M | -$19M |
| 5 | $1M | $5M | $4M | -$15M |

**Liquidity Management:**
- Working capital facility: $2-3M (revolving)
- Contingency reserve: 10% of total CAPEX ($2-2.5M)
- Grant funding: Front-loaded to cover early losses
- Milestone-based DFI disbursements

---

## 7. RISK INTERDEPENDENCY MAP

### 7.1 Risk Cascades and Compounding Effects

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    RISK INTERDEPENDENCY MAP                                  │
│                    Dakar-Lagos Corridor Play                                 │
└─────────────────────────────────────────────────────────────────────────────┘

PRIMARY RISKS (Triggers)
═══════════════════════════════════════════════════════════════════════════════

POL-001: Nigeria Export Ban ──┬──► ECO-004: Lagos Price Collapse
                              │    └──► FIN-004: Counterparty Default
                              │         └──► FIN-006: Cash Flow Crisis
                              │
                              └──► OPR-004: Border Delays
                                   └──► ColdChainCo Underutilization
                                        └──► FIN-003: Working Capital Constraints

POL-002: Border Closure ──────┬──► OPR-004: Border Delays (compounded)
                              │
                              └──► ECO-004: Lagos Price Collapse
                                   └──► [Same cascade as above]

ECO-002: Feed Price Spike ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► FIN-006: Cash Flow Crisis
                              │
                              └──► FIN-002: Currency Mismatch (if USD feed)

ENV-004: Disease Outbreak ────┬──► OPR-005: Anchor Farm Underperformance
                              │    └──► [Same cascade as above]
                              │
                              └──► OPR-001: Hatchery Failure
                                   └──► Production Cascade Failure

FIN-001: DFI Funding Gap ─────┬──► FIN-006: Cash Flow Crisis
                              │
                              └──► Delayed ColdChainCo
                                   └──► ECO-004: Lagos Price Collapse
                                        └──► [Same cascade as above]

SOC-001: Land Conflicts ──────► Delayed Anchor Farm
                              └──► OPR-005: Underperformance
                                   └──► [Same cascade as above]
```

### 7.2 Compound Risk Scenarios

**Scenario A: "Perfect Storm" (Low Probability, Catastrophic Impact)**
- Nigeria export ban (POL-001) 
- + Feed price spike (ECO-002)
- + Disease outbreak (ENV-004)
- = Project failure, full write-off

**Probability:** 5-10% | **Impact:** Project termination

**Mitigation:** Sequential gating ensures exit before full commitment

---

**Scenario B: "Death by a Thousand Cuts" (Medium Probability, High Impact)**
- Border delays increase costs 15% (OPR-004)
- + Chinese competition reduces prices 10% (ECO-001)
- + Currency devaluation 15% (ECO-003)
- + Outgrower coordination issues reduce volumes 20% (OPR-006)
- = IRR drops from 22% to 8%, project marginal

**Probability:** 20-30% | **Impact:** Bear case IRR (8-10%)

**Mitigation:** Price sensitivity analysis shows project viable down to $2.30/kg with $0.60/kg feed

---

**Scenario C: "Cold Chain Collapse" (Medium Probability, Medium Impact)**
- Cold chain equipment failure (OPR-003)
- + Border delays exceed 48 hours (OPR-004)
- + Reefer truck breakdown
- = Product spoilage, customer loss, reputational damage

**Probability:** 15-20% | **Impact:** $500K-1M loss, customer relationships damaged

**Mitigation:** Insurance coverage, redundant systems, buffer inventory

---

### 7.3 Risk Correlation Matrix

| Risk | POL-001 | POL-002 | ECO-001 | ECO-002 | ECO-003 | OPR-001 | OPR-003 | OPR-005 | FIN-001 | FIN-006 |
|------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| POL-001 | 1.0 | 0.7 | 0.3 | 0.2 | 0.4 | 0.1 | 0.3 | 0.5 | 0.3 | 0.6 |
| POL-002 | 0.7 | 1.0 | 0.2 | 0.1 | 0.3 | 0.1 | 0.5 | 0.3 | 0.2 | 0.4 |
| ECO-001 | 0.3 | 0.2 | 1.0 | 0.4 | 0.5 | 0.2 | 0.1 | 0.4 | 0.2 | 0.5 |
| ECO-002 | 0.2 | 0.1 | 0.4 | 1.0 | 0.6 | 0.3 | 0.1 | 0.6 | 0.3 | 0.7 |
| ECO-003 | 0.4 | 0.3 | 0.5 | 0.6 | 1.0 | 0.1 | 0.2 | 0.4 | 0.4 | 0.8 |
| OPR-001 | 0.1 | 0.1 | 0.2 | 0.3 | 0.1 | 1.0 | 0.2 | 0.7 | 0.2 | 0.5 |
| OPR-003 | 0.3 | 0.5 | 0.1 | 0.1 | 0.2 | 0.2 | 1.0 | 0.3 | 0.2 | 0.4 |
| OPR-005 | 0.5 | 0.3 | 0.4 | 0.6 | 0.4 | 0.7 | 0.3 | 1.0 | 0.4 | 0.8 |
| FIN-001 | 0.3 | 0.2 | 0.2 | 0.3 | 0.4 | 0.2 | 0.2 | 0.4 | 1.0 | 0.7 |
| FIN-006 | 0.6 | 0.4 | 0.5 | 0.7 | 0.8 | 0.5 | 0.4 | 0.8 | 0.7 | 1.0 |

*Correlation values: 0 = independent, 1 = perfectly correlated*

---

## 8. EARLY WARNING INDICATORS FRAMEWORK

### 8.1 Indicator Dashboard

| Risk Category | Indicator | Threshold | Monitoring Frequency | Data Source | Owner |
|---------------|-----------|-----------|---------------------|-------------|-------|
| **POLITICAL** | | | | | |
| POL-001 | Nigerian aquaculture production growth | >20% YoY for 2 quarters | Quarterly | FMARD reports | Policy Team |
| POL-001 | Import ban rhetoric in media | >5 negative articles/month | Monthly | Media monitoring | Policy Team |
| POL-002 | Border crossing time | >24 hours average | Weekly | ColdChainCo logs | Operations |
| POL-003 | ECOWAS meeting outcomes | Suspension/expulsion votes | Per meeting | ECOWAS Secretariat | Policy Team |
| POL-006 | Land dispute complaints | >3 formal grievances | Monthly | Community relations | Community Mgr |
| **ECONOMIC** | | | | | |
| ECO-001 | Chinese import volumes | >15% YoY increase | Monthly | Customs data | Commercial |
| ECO-001 | CIV wholesale price | <$1.65/kg for 4 weeks | Weekly | Market surveys | Commercial |
| ECO-002 | Global soy price (CBOT) | >$500/MT for 3 months | Daily | Commodity exchanges | Procurement |
| ECO-002 | De Heus contract price | >$0.60/kg | Monthly | Contract reviews | Procurement |
| ECO-003 | CFA/USD exchange rate | >5% depreciation in 30 days | Daily | Central bank | Treasury |
| ECO-004 | Lagos wholesale price | <$2.30/kg for 4 weeks | Weekly | Offtaker reports | Commercial |
| **OPERATIONAL** | | | | | |
| OPR-001 | Hatchery mortality rate | >5% weekly | Weekly | Production reports | Hatchery Mgr |
| OPR-002 | Feed FCR | >1.7 for 2 cycles | Per cycle | Production data | Production Mgr |
| OPR-003 | Cold chain uptime | <98% monthly | Daily | Monitoring systems | ColdChainCo Ops |
| OPR-004 | Border clearance time | >48 hours | Per shipment | Logistics tracking | ColdChainCo Ops |
| OPR-005 | Anchor farm production | <80% of target for 2 quarters | Quarterly | Production reports | Farm GM |
| OPR-005 | Mortality rate | >15% for 2 months | Monthly | Health records | Veterinary |
| OPR-006 | Outgrower delivery compliance | <70% of contracted volume | Monthly | Collection data | Outgrower Coord |
| **ENVIRONMENTAL** | | | | | |
| ENV-001 | Water quality index | Below Class II for 2 weeks | Weekly | Lab testing | Environmental |
| ENV-002 | Water temperature | >30°C for 5 consecutive days | Daily | Monitoring systems | Production |
| ENV-004 | Disease incidence | >2% weekly mortality | Weekly | Health monitoring | Veterinary |
| **SOCIAL** | | | | | |
| SOC-001 | Community grievances | >5 unresolved complaints | Monthly | Grievance log | Community Relations |
| SOC-004 | Outgrower dropout rate | >20% in 6 months | Semi-annual | Program data | Outgrower Coord |
| **FINANCIAL** | | | | | |
| FIN-001 | DFI commitment delays | >6 months beyond target | Quarterly | Funding pipeline | CFO |
| FIN-002 | USD/CFA rate movement | >10% depreciation | Daily | FX markets | Treasury |
| FIN-003 | Trade finance utilization | >90% of facility | Monthly | Facility reports | Trade Finance Mgr |
| FIN-004 | Offtaker payment delays | >30 days past due | Monthly | AR aging | Commercial |
| FIN-006 | Cash position | <3 months operating expenses | Monthly | Cash flow forecast | CFO |

### 8.2 Escalation Protocols

| Alert Level | Trigger | Response Time | Action Required |
|-------------|---------|---------------|-----------------|
| **GREEN** | Indicator within normal range | N/A | Continue monitoring |
| **AMBER** | Indicator approaches threshold | 48 hours | Risk owner investigates, reports to management |
| **RED** | Threshold breached | 24 hours | Emergency response, board notification if material |
| **CRITICAL** | Multiple RED indicators or cascading risks | Immediate | Crisis management activation, stakeholder communication |

---

## 9. RISK ALLOCATION FRAMEWORK

### 9.1 Risk Allocation Matrix

| Risk ID | Risk | Public Sector (Govt/ECOWAS) | Private Operator (Anchor/ColdChainCo) | DFIs (AfDB/IFC/etc.) | Shared/Transfer |
|---------|------|----------------------------|--------------------------------------|---------------------|-----------------|
| **POLITICAL** | | | | | |
| POL-001 | Nigeria Export Ban | 40% (policy) | 30% (market pivot) | 20% (PRI) | 10% (insurance) |
| POL-002 | Border Closure | 50% (infrastructure) | 30% (alternative routes) | 10% (advocacy) | 10% (buffer) |
| POL-003 | ECOWAS Fragmentation | 40% (regional) | 30% (bilateral) | 20% (diplomatic) | 10% (diversification) |
| POL-004 | CIV Govt Commitment | 60% (policy continuity) | 25% (relationships) | 10% (MoU) | 5% (monitoring) |
| POL-006 | ZEAD Land Tenure | 40% (land admin) | 35% (community engagement) | 15% (governance) | 10% (legal) |
| **ECONOMIC** | | | | | |
| ECO-001 | Chinese Dumping | 30% (trade policy) | 40% (differentiation) | 10% (advocacy) | 20% (market) |
| ECO-002 | Feed Price Volatility | 10% (strategic reserves) | 50% (contracts/hedging) | 20% (price locks) | 20% (market) |
| ECO-003 | CFA Devaluation | 20% (monetary policy) | 40% (natural hedge) | 20% (USD revenue) | 20% (hedging) |
| ECO-004 | Lagos Price Collapse | 10% (market info) | 50% (diversification) | 20% (contracts) | 20% (insurance) |
| **OPERATIONAL** | | | | | |
| OPR-001 | Hatchery Failure | 10% (research support) | 60% (operations/QA) | 20% (technical assist) | 10% (backup) |
| OPR-002 | Feed Quality | 10% (standards) | 60% (QA/contracts) | 20% (supplier dev) | 10% (alternatives) |
| OPR-003 | Cold Chain Failure | 10% (infrastructure) | 60% (maintenance/redundancy) | 15% (technical) | 15% (insurance) |
| OPR-004 | Border Delays | 50% (customs reform) | 30% (systems/process) | 15% (facilitation) | 5% (buffer) |
| OPR-005 | Farm Underperformance | 10% (extension) | 65% (management/TA) | 20% (technical assist) | 5% (gating) |
| OPR-006 | Outgrower Issues | 15% (rural dev) | 55% (coordination/finance) | 25% (capacity building) | 5% (adjustment) |
| **ENVIRONMENTAL** | | | | | |
| ENV-001 | Water Quality | 40% (regulation) | 35% (monitoring/adaptation) | 15% (research) | 10% (insurance) |
| ENV-002 | Climate Change | 30% (adaptation policy) | 40% (resilient practices) | 20% (R&D) | 10% (diversification) |
| ENV-004 | Disease Outbreak | 20% (veterinary services) | 50% (biosecurity) | 20% (health management) | 10% (insurance) |
| **SOCIAL** | | | | | |
| SOC-001 | Land Conflicts | 35% (land admin) | 45% (community engagement) | 15% (governance) | 5% (legal) |
| SOC-004 | Outgrower Integration | 20% (rural dev) | 50% (program design) | 25% (capacity building) | 5% (adjustment) |
| **FINANCIAL** | | | | | |
| FIN-001 | DFI Funding Gap | 10% (enabling env) | 30% (bankability) | 55% (commitment) | 5% (alternatives) |
| FIN-002 | Currency Mismatch | 15% (FX policy) | 45% (hedging/structure) | 30% (USD debt) | 10% (natural hedge) |
| FIN-003 | Working Capital | 10% (financial sector) | 45% (management) | 40% (facility design) | 5% (reserves) |
| FIN-004 | Counterparty Default | 10% (legal framework) | 45% (credit mgmt) | 30% (guarantees) | 15% (insurance) |
| FIN-006 | Cash Flow Timing | 5% (fiscal) | 50% (planning) | 40% (structure) | 5% (contingency) |

### 9.2 Risk Transfer Mechanisms

| Mechanism | Coverage | Cost | Provider | Applicable Risks |
|-----------|----------|------|----------|-----------------|
| Political Risk Insurance (PRI) | 80-95% of loss | 2-3% of insured value | MIGA, ATPC, ECIC | POL-001, POL-002, POL-004 |
| Trade Credit Insurance | 85-95% of receivables | 1-2% of turnover | Coface, Euler Hermes, ATPC | FIN-004 |
| Crop/Livestock Insurance | 70-80% of production value | 3-5% of value | Regional pools, commercial | ENV-004, OPR-005 |
| Property Insurance | Full replacement value | 0.5-1% of asset value | Commercial insurers | OPR-003 |
| Currency Hedging | 100% of exposure | 1-3% p.a. (forward premium) | Banks, DFIs | ECO-003, FIN-002 |
| Performance Bonds | 100% of contract value | 1-2% of value | Surety providers | OPR-006, OPR-002 |

---

## 10. RISK MONITORING & GOVERNANCE

### 10.1 Risk Governance Structure

```
                    ┌─────────────────────────────────────┐
                    │     AFSTI BOARD / STEERCO           │
                    │  (Quarterly risk review)            │
                    └──────────────┬──────────────────────┘
                                   │
                    ┌──────────────▼──────────────────────┐
                    │   RISK COMMITTEE                    │
                    │   (Monthly risk review)             │
                    │   Chair: AFSTI Risk Manager         │
                    └──────────────┬──────────────────────┘
                                   │
        ┌──────────────────────────┼──────────────────────────┐
        │                          │                          │
┌───────▼────────┐      ┌──────────▼──────────┐    ┌─────────▼────────┐
│  OPERATIONAL   │      │   FINANCIAL/ECONOMIC │    │   POLICY/SOCIAL  │
│  RISK OWNER    │      │   RISK OWNER         │    │   RISK OWNER     │
│  (Anchor Farm  │      │   (CFO)              │    │   (Policy Team)  │
│   GM)          │      │                      │    │                  │
└───────┬────────┘      └──────────┬───────────┘    └─────────┬────────┘
        │                          │                          │
        └──────────────────────────┼──────────────────────────┘
                                   │
                    ┌──────────────▼──────────────────────┐
                    │   RISK MONITORING SYSTEM            │
                    │   (Real-time dashboards)            │
                    └─────────────────────────────────────┘
```

### 10.2 Reporting Requirements

| Report | Frequency | Audience | Content |
|--------|-----------|----------|---------|
| Risk Dashboard | Weekly | Management | Traffic light status, threshold breaches |
| Risk Register Update | Monthly | Risk Committee | New risks, probability/impact changes |
| Risk Report | Quarterly | Board/SteerCo | Comprehensive review, mitigation effectiveness |
| Risk Deep Dive | Ad-hoc | Board | Specific risk analysis (as needed) |
| Incident Report | Within 24h | All stakeholders | Risk event occurrence, response actions |

### 10.3 Risk Review Cycle

| Activity | Frequency | Responsible |
|----------|-----------|-------------|
| Indicator monitoring | Daily/Weekly | Risk owners |
| Risk register review | Monthly | Risk Manager |
| Mitigation effectiveness assessment | Quarterly | Risk Committee |
| Strategy adjustment | Annually | Board |
| External risk audit | Bi-annually | Independent auditor |

---

## 11. CONTINGENCY PLANNING

### 11.1 Scenario-Based Contingency Plans

**Scenario 1: Nigeria Export Ban Imposed**
| Timeline | Action | Responsible | Cost |
|----------|--------|-------------|------|
| Week 1 | Activate domestic market sales plan | Commercial | $50K marketing |
| Week 2-4 | Increase Ghana/Togo offtaker engagement | Commercial | $30K travel |
| Month 2 | Reduce export-oriented processing | Operations | $100K adjustment |
| Month 3 | Reassess ColdChainCo Hub 2 timing | Management | Review only |
| Ongoing | Maintain Lagos relationships for future reopening | Policy | $20K/year |

**Scenario 2: Anchor Farm Underperformance (<5K MT by Yr 3)**
| Timeline | Action | Responsible | Cost |
|----------|--------|-------------|------|
| Month 6 (if trending down) | Intensive technical assistance | AFSTI TA | $200K |
| Month 9 | Consider operator replacement | Board | Transition costs |
| Month 12 | If still <4K MT, delay ColdChainCo | Management | Opportunity cost |
| Month 18 | Reassess entire corridor play | Board | Strategic review |

**Scenario 3: Major Currency Devaluation (>20%)**
| Timeline | Action | Responsible | Cost |
|----------|--------|-------------|------|
| Week 1 | Activate currency hedges | Treasury | Pre-arranged |
| Week 2 | Renegotiate debt service terms | CFO | Legal fees |
| Month 1 | Increase export ratio to 70%+ | Commercial | Logistics costs |
| Month 2 | Pass-through price increases to domestic market | Commercial | Volume risk |
| Month 3 | Reduce CFA-denominated costs | Operations | Efficiency investment |

### 11.2 Exit Strategies

| Scenario | Exit Option | Timeline | Recovery Value |
|----------|-------------|----------|----------------|
| Project non-viable | Sell to strategic investor (Yalelo, Tropo) | 6-12 months | 40-60% of CAPEX |
| Partial success | Convert to domestic-only operation | 3-6 months | 60-80% of NPV |
| ColdChainCo failure | Sell hubs to logistics companies | 6-12 months | 50-70% of investment |
| Trade finance failure | Wind down facility, recover collateral | 12-18 months | 80-90% of principal |

---

## 12. SUMMARY RISK RATINGS

### 12.1 Overall Risk Summary

| Risk Category | Number of Risks | High P/I | Med P/I | Low P/I | Overall Rating |
|---------------|-----------------|----------|---------|---------|----------------|
| Political/Policy | 8 | 2 | 4 | 2 | **AMBER-RED** |
| Economic/Market | 8 | 2 | 5 | 1 | **AMBER** |
| Operational/Technical | 9 | 2 | 5 | 2 | **AMBER** |
| Environmental/Climate | 6 | 1 | 4 | 1 | **AMBER-GREEN** |
| Social/Community | 6 | 1 | 5 | 0 | **AMBER** |
| Financial/Currency | 8 | 2 | 5 | 1 | **AMBER** |
| **TOTAL** | **45** | **10** | **28** | **7** | **AMBER** |

### 12.2 Top 10 Critical Risks

| Rank | Risk ID | Risk | Probability | Impact | Combined Score |
|------|---------|------|-------------|--------|----------------|
| 1 | POL-001 | Nigeria Export Ban | HIGH | HIGH | **CRITICAL** |
| 2 | ECO-001 | Chinese Fish Dumping | HIGH | HIGH | **CRITICAL** |
| 3 | FIN-006 | Cash Flow Timing | HIGH | HIGH | **CRITICAL** |
| 4 | OPR-005 | Anchor Farm Underperformance | MEDIUM | HIGH | **HIGH** |
| 5 | ECO-002 | Feed Price Volatility | MEDIUM | HIGH | **HIGH** |
| 6 | POL-002 | Border Closure | MEDIUM | HIGH | **HIGH** |
| 7 | FIN-002 | Currency Mismatch | MEDIUM | HIGH | **HIGH** |
| 8 | OPR-001 | Hatchery Failure | MEDIUM | HIGH | **HIGH** |
| 9 | OPR-003 | Cold Chain Failure | MEDIUM | HIGH | **HIGH** |
| 10 | SOC-001 | Community Land Conflicts | MEDIUM | HIGH | **HIGH** |

### 12.3 Risk-Adjusted Returns

| Scenario | Probability | IRR | NPV @ 10% |
|----------|-------------|-----|-----------|
| Bull Case (risks mitigated) | 25% | 25% | $30M |
| Base Case (expected risks) | 50% | 22% | $10.2M |
| Bear Case (major risk event) | 20% | 8-10% | $2-5M |
| Failure (catastrophic) | 5% | -10% | -$5M |
| **Probability-Weighted** | **100%** | **18.5%** | **$12.8M** |

---

## 13. RECOMMENDATIONS

### 13.1 Immediate Actions (0-6 months)

1. **Secure Political Risk Insurance** for Nigeria export exposure (MIGA/ATPC)
2. **Negotiate feed price lock** with De Heus at $0.55/kg for 3 years
3. **Establish working capital facility** of $2-3M for cash flow management
4. **Complete FPIC process** for all ZEAD sites before construction
5. **Secure letters of intent** from 3+ Lagos offtakers with risk clauses

### 13.2 Short-Term Actions (6-18 months)

1. **Implement sequential gating** with clear go/no-go criteria
2. **Establish risk monitoring dashboard** with automated alerts
3. **Negotiate quota agreements** with Nigerian FMARD
4. **Diversify export routes** through Togo and Ghana ports
5. **Build community benefit-sharing** agreements with local stakeholders

### 13.3 Medium-Term Actions (18-36 months)

1. **Develop alternative protein sources** to reduce feed cost risk
2. **Establish regional insurance pool** participation for crop/disease coverage
3. **Build strategic feed inventory** (6-month buffer)
4. **Develop Ghana anchor farm** as CIV backup
5. **Create crisis management protocols** for compound risk scenarios

---

## APPENDICES

### Appendix A: Risk Scoring Methodology

**Probability Scale:**
- HIGH: >50% likelihood within project lifetime
- MEDIUM: 20-50% likelihood
- LOW: <20% likelihood

**Impact Scale:**
- HIGH: >20% NPV impact or project viability threat
- MEDIUM: 10-20% NPV impact or significant operational disruption
- LOW: <10% NPV impact or manageable disruption

**Combined Score:**
- CRITICAL: HIGH probability + HIGH impact
- HIGH: MEDIUM probability + HIGH impact OR HIGH probability + MEDIUM impact
- MEDIUM: All other combinations
- LOW: LOW probability + LOW impact

### Appendix B: Glossary

| Term | Definition |
|------|------------|
| AFSTI | African Food Systems Transformation Initiative |
| AGRA | Alliance for a Green Revolution in Africa |
| ATPC | African Trade Policy Centre |
| CAPEX | Capital Expenditure |
| CIV | Côte d'Ivoire |
| ColdChainCo | Cold chain infrastructure company |
| DFI | Development Finance Institution |
| ECOWAS | Economic Community of West African States |
| FCR | Feed Conversion Ratio |
| FPIC | Free, Prior, and Informed Consent |
| FX | Foreign Exchange |
| GIFT | Genetically Improved Farmed Tilapia |
| IRR | Internal Rate of Return |
| MoU | Memorandum of Understanding |
| MT | Metric Tonnes |
| NPV | Net Present Value |
| PEA | Political Economy Assessment |
| PRI | Political Risk Insurance |
| PSTACI | Programme de Structuration de la Filière Aquaculture en Côte d'Ivoire |
| SPS | Sanitary and Phytosanitary |
| TA | Technical Assistance |
| VC | Value Chain |
| ZEAD | Zone d'Exploitation Agricole Durable |

### Appendix C: Key Contacts

| Role | Organization | Responsibility |
|------|--------------|----------------|
| Risk Manager | AFSTI | Overall risk framework |
| Policy Lead | AGRA | Political risk mitigation |
| CFO | Anchor Farm | Financial risk management |
| Operations Manager | ColdChainCo | Operational risk |
| Community Relations | Anchor Farm | Social risk |

---

*Document Version: 1.0*
*Date: February 2026*
*Next Review: Quarterly*

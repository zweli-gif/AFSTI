# LIKELY PLAYERS TO OPERATE - DAKAR-LAGOS CORRIDOR PLAY
## Comprehensive Operator Analysis for AFSTI Investment Components

---

## 1. AQUACULTURE (CIV Tilapia) - COMPONENT OPERATORS

### 1.1 HATCHERY (Public Good) - $3-5M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Aquaculture | Hatchery (Public Good) | **Public-Private Partnership** | **ProDeCAP / AfDB + CNRA + Private Operator** | ProDeCAP is already funded ($25.6M) with hatchery establishment as core objective; CNRA has existing genetic program; requires private sector efficiency | ProDeCAP approved 2024-2030; CNRA operates existing breeding nucleus; WorldFish GIFT strain proven across 17 countries | Critical fit - provides public good infrastructure with commercial sustainability through fingerling sales |
| Aquaculture | Hatchery (Public Good) | **International Technical Partner** | **WorldFish Center** | WorldFish manages GIFT genetics globally; has established African programs in Egypt, Malawi, Zambia; provides technical backbone for broodstock quality | GIFT strain in 17 countries; 28 years of selective breeding; 10-15% gains per generation; recently supplied equipment to Malawi National Aquaculture Center | Essential for genetic quality assurance and knowledge transfer |
| Aquaculture | Hatchery (Public Good) | **Regional Hatchery Operator** | **Victory Farms (Kenya) - Technical Partner** | Victory Farms operates successful hatcheries in Kenya/Rwanda; has innovative HEAP outgrower model for egg production; proven at 18,000 MT scale | 18,000 MT annual production; vertically integrated from hatchery to retail; ASC improver program participant; AgDevCo portfolio company | Could provide technical consultancy or joint venture for hatchery design and operation |
| Aquaculture | Hatchery (Public Good) | **Local Private Operator** | **Emerging CIV Entrepreneur (500+ MT operator)** | Local operators understand market dynamics; can leverage existing relationships with farmers; lower operational costs | Several emerging operators already producing 500-1000 MT in CIV; familiar with local conditions and distribution | Important for local ownership and long-term sustainability |

---

### 1.2 FEED PARTNERSHIP - $2-4M (De Heus Partnership)

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Aquaculture | Feed Partnership | **International Feed Major (EXISTING)** | **De Heus / Koudijs (Netherlands)** | De Heus already inaugurated 120K MT feed factory in Abidjan (2023); expressed commitment to Ivorian aquaculture; partnership framework exists | EUR multi-million investment in Abidjan factory; operates in 75+ countries; strong technical support for farmers; established distribution network | **EXISTING PARTNER** - Natural fit for aquaculture feed production through existing facility |
| Aquaculture | Feed Partnership | **Alternative International** | **Skretting (Nutreco/Netherlands)** | Skretting is world's largest aquafeed producer; has Africa presence (Egypt, Nigeria); recently bought out Nigerian JV partner; strong tilapia expertise | 2M+ MT annual production; 19 countries; 60+ species; recently expanded Nigeria operations; produces specialized broodstock feeds (Vitalis) | Alternative if De Heus partnership doesn't materialize; strong technical credentials |
| Aquaculture | Feed Partnership | **Alternative International** | **Cargill/EWOS** | Cargill major aquafeed player; focuses on tilapia in China, Indonesia, Thailand, Vietnam; expanding emerging market presence | 80+ years EWOS experience; 120 years Cargill animal nutrition; strong R&D capabilities; global supply chain | Potential partner for specialized aquafeed formulations |
| Aquaculture | Feed Partnership | **Regional Model** | **Victory Farms Feed Mill JV (Kenya)** | Victory Farms operates successful feed mill joint venture in Kenya; produces at scale for own use and external sales; understands African feed challenges | Produces feed for 18,000 MT production; vertically integrated model; AgDevCo supported; proven at scale | Could provide technical assistance for feed mill design/formulation |

---

### 1.3 ANCHOR FARM + OUTGROWERS - $5-8M (Target: 10K MT/yr)

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Aquaculture | Anchor Farm | **International Proven (EXISTING)** | **Yalelo (Zambia/Uganda) - First Wave Group** | Yalelo is largest freshwater fish producer in Sub-Saharan Africa (18K MT); proven DFI relationships ($18M from Finnfund, Norfund, AfDB); 5-country export experience; sophisticated operations | 18,000 MT annual production; 1,500 employees; full lifecycle from feed to retail; $84M project financing; 5-country export; gender-focused investment | **EXISTING CANDIDATE** - Proven at scale with DFI consortium; regional expansion ambition |
| Aquaculture | Anchor Farm | **Regional West Africa (EXISTING)** | **Tropo Farms (Ghana)** | Tropo is largest tilapia producer in West Africa; recently received $10M AgDevCo investment for expansion to 30K MT; explicitly stated West Africa expansion ambitions; CEO has regional experience | 15,000 MT current (expanding to 30K MT); 917 employees; 3,000 market traders (majority women); Lake Volta cage operations; $10M AgDevCo backing | **EXISTING CANDIDATE** - Strongest regional fit; explicit expansion interest; proven West Africa operations |
| Aquaculture | Anchor Farm | **East Africa Fast-Grower** | **Victory Farms (Kenya)** | Fastest-growing tilapia farm in SSA; 18K MT production; vertically integrated model; innovative outgrower schemes; mission to feed 2 billion Africans | 18,000 MT annual; 750+ employees; 15,000+ market women customers; HEAP outgrower program (30% of eggs from community ponds); ASC improver program; $4M AgDevCo investment | Strong model for outgrower integration; proven African operations; could expand to West Africa |
| Aquaculture | Anchor Farm | **Southern Africa Integrated** | **Lake Harvest (Zimbabwe/Zambia/Uganda)** | Largest integrated tilapia operation in Africa; indigenous African fish breeding focus; multi-country operations; premium quality positioning | Operations in Zimbabwe, Zambia, Uganda, Kenya, Malawi, South Africa; cage farming on Lake Kariba and Lake Victoria; focus on quality over volume; established distribution | Strong technical expertise; proven multi-country African operations |
| Aquaculture | Anchor Farm | **Local Private/Cooperative** | **CIV Cooperative (50-100 farmers near ZEAD)** | PSTACI program developing 30 ZEAD zones; local cooperatives have existing farmer relationships; government support through PONADEPA program | FISH4ACP supporting cooperative strengthening; existing farmer groups in Western, Eastern, Southern regions; CNRA providing technical support | Critical for outgrower scheme success; local ownership and community integration |
| Aquaculture | Anchor Farm | **Local Entrepreneur** | **Emerging CIV 500+ MT Operator** | Several emerging operators already achieving commercial scale; understand local market dynamics; established distribution relationships; lower cost structure | Multiple operators producing 500-1,000 MT annually; familiar with local conditions; established buyer relationships | Potential anchor farm candidates with growth capital and technical support |

---

### 1.4 PROCESSING FACILITY - $3-4M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Aquaculture | Processing | **Anchor Farm Integrated** | **Tropo Farms / Yalelo / Victory Farms** | All major aquaculture operators are vertically integrated or building processing; Tropo building modern processing facility with AgDevCo funding; Yalelo has processing capabilities | Tropo: constructing processing facility for 30K MT capacity; Yalelo: full lifecycle including processing; Victory Farms: processing + retail network | Natural fit - processing integrated with production ensures quality and traceability |
| Aquaculture | Processing | **Regional Fish Processor** | **Mr Fish Processing Hub (Ghana/Uganda)** | Specialized freshwater fish processor; operates in Ghana and Uganda; supplies tilapia fillets, whole fish, value-added products; export experience | Nile Perch & Tilapia fillets; fresh and frozen products; smoked/salted traditional products; air and sea freight capability; HACCP compliance | Established African fish processor; understands regional markets |
| Aquaculture | Processing | **Local CIV Processor** | **IPF Commercial Logistics Park (Abidjan)** | Chinese-invested facility near Port of Abidjan; 120,000 ton cold storage capacity; blast freezing; seafood processing focus; established cold chain | 12 hectare park; 2 low-temp warehouses; 1,000 sqm fast-freezing line; seafood import/export operations; cashew export capabilities | Existing cold chain infrastructure; port proximity; experience with seafood |
| Aquaculture | Processing | **International Processor** | **Pioneer Food Cannery (Ghana) / GIHOC** | Established Ghanaian fish processors; canning and freezing capabilities; export experience; compliance with international standards | Pioneer Food Cannery: major Ghanaian processor; GIHOC: state-owned with historical processing experience | Could provide technical partnership or contract processing |

---

### 1.5 BORDER + REEFER OPERATIONS - $3-4M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Aquaculture | Border/Reefer | **International Logistics Major** | **AGL (Africa Global Logistics) - MSC Group** | AGL (formerly Bolloré Africa Logistics) is largest logistics operator in Africa; 21,000 employees; 49 countries; cold storage and reefer expertise; now part of MSC Group | 100+ years Africa experience; tri-temperature platform at Abidjan airport (6,000 sqm); bonded warehousing; cold room facilities; port operations across West Africa | Strongest candidate - established cold chain capabilities; port and border expertise |
| Aquaculture | Border/Reefer | **Global Port Operator** | **DP World** | Major port operator in West Africa (Dakar, Maputo, Congo); developing $1.2B Ndayane Port in Senegal; cold chain and reefer capabilities; investment in African logistics | $1.2B Ndayane Port development; cold storage at Dakar; reefer capacity expansion (450 to 715 plugs at Maputo); digital tracking systems | Strong port and logistics capabilities; significant West Africa investment |
| Aquaculture | Border/Reefer | **International Freight Forwarder** | **Kuehne+Nagel** | Expanded Africa network to 18 countries; healthcare/pharma cold chain expertise; control tower in Durban; perishables logistics focus | OR Tambo airside facility; temperature-controlled pharma logistics; cold chain solutions; compliance focus | Strong cold chain credentials; expanding West Africa presence |
| Aquaculture | Border/Reefer | **International Express** | **DHL Group** | EUR 300M+ investment in Sub-Saharan Africa; cold chain and perishables logistics; temperature-controlled transport; life sciences expertise | GDP-certified healthcare facilities (Johannesburg, Nairobi); expanding cold chain for agriculture; digital customs tools | Strong investment commitment; cold chain expertise |
| Aquaculture | Border/Reefer | **Shipping Line Reefer** | **Maersk / CMA CGM** | Major container lines with reefer fleets; Maersk investing $100M+ in South African cold chain; CMA CGM has West Africa reefer operations | Maersk: Belcon, Cato, PreCool facilities in South Africa; CMA CGM: reefer services to West Africa; global reefer fleet | Container and reefer capabilities; established West Africa routes |
| Aquaculture | Border/Reefer | **Local West African Operator** | **Benin/Ghana Transport Cooperatives** | Local operators have established cross-border relationships; lower cost structure; community connections; flexibility | Established trucking networks; cross-border ECOWAS experience; relationships with border officials | Important for last-mile distribution and local market knowledge |

---

## 2. COLDCHAINCO - THE SPINE ENABLER

### 2.1 HUB 1: ABIDJAN PORT ZONE - $5-7M (Aggregation + Blast Freeze)

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| ColdChainCo | Hub 1 Abidjan | **International Logistics Major** | **AGL (Africa Global Logistics)** | AGL has existing tri-temperature facility at Abidjan airport (Aerohub - 6,000 sqm); expanding to 9,000 sq m logistics base; cold room facilities; port zone presence | Aerohub: 3,500 sq m warehouse with cold room; bonded area; pharmaceutical packaging; EDGE certified; intelligent temperature control | **STRONGEST CANDIDATE** - Existing cold infrastructure; port zone location; expansion underway |
| ColdChainCo | Hub 1 Abidjan | **Chinese Infrastructure Investor** | **IPF Commercial Logistics Park** | 12-hectare facility near Port of Abidjan; 120,000 ton annual capacity; 2 low-temp warehouses; 1,000 sqm blast-freezing line; seafood focus | 120,000 ton processing/storage capacity; 3 x 5,000 sqm logistics warehouses; fast-freezing production line; seafood import/export operations | Existing large-scale cold storage; blast freezing capability; port proximity |
| ColdChainCo | Hub 1 Abidjan | **Port Terminal Operator** | **APM Terminals + AGL JV** | APM Terminals operates Abidjan container terminal; JV with AGL for equipment; expanding capacity with new gantry cranes; reefer plug expansion | Modern terminal equipment; reefer container handling; port logistics integration; MSC/AGL partnership | Port integration; container handling capabilities |
| ColdChainCo | Hub 1 Abidjan | **Local Private Operator** | **SOTRA / Local Cold Storage Operators** | Local operators understand market dynamics; established customer relationships; lower cost structure; government relationships | Existing cold storage operations in Abidjan; serving local market; some port zone presence | Local market knowledge; potential JV partners |

---

### 2.2 HUB 2: SEME-KRAKE BORDER BUFFER - $3-4M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| ColdChainCo | Hub 2 Seme-Krake | **Regional Logistics Operator** | **AGL Border Logistics** | AGL has extensive West Africa border operations; experience with ECOWAS transit; customs expertise; can integrate with Abidjan hub | Cross-border operations throughout West Africa; customs clearing; bonded transport; regional network | Established border logistics; can create seamless Abidjan-border corridor |
| ColdChainCo | Hub 2 Seme-Krake | **Benin National Operator** | **Benin Logistics Company (State/Private JV)** | Benin has vested interest in border efficiency; Seme-Krake is critical trade corridor; local knowledge of border procedures | Seme-Krake is major Benin-Nigeria border; Benin government investment in border infrastructure | Local ownership; government support; border expertise |
| ColdChainCo | Hub 2 Seme-Krake | **Nigeria-Benin Cross-Border Operator** | **Nigerian Logistics Companies with Benin Operations** | Nigerian operators understand Lagos market; established relationships; can ensure last-mile delivery | Lagos-based distributors; cross-border experience; market women networks | Market access; distribution capabilities |
| ColdChainCo | Hub 2 Seme-Krake | **Cold Chain Specialist** | **DHL / Kuehne+Nagel Border Solutions** | International operators have border clearance expertise; temperature monitoring; compliance systems | Cross-border cold chain solutions; customs expertise; tracking systems | Technical expertise; compliance; reliability |

---

### 2.3 REEFER FLEET: 10-15 TRUCKS - $2-4M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| ColdChainCo | Reefer Fleet | **International Logistics Leasing** | **EFAfrica Group (AgDevCo Portfolio)** | EFAfrica is equipment leasing company for African agriculture; $7.2M AgDevCo follow-on investment; serves 1,500+ entrepreneurs; trucks and tractors focus | 1,500+ lessee entrepreneurs across Kenya, Tanzania, Zambia; agricultural equipment leasing; typical lease $10K-$80K; expanding to larger agribusiness leases | AgDevCo relationship; agricultural focus; equipment leasing expertise |
| ColdChainCo | Reefer Fleet | **Regional Transport Operator** | **West African Transport Companies** | Established trucking companies with reefer capabilities; ECOWAS cross-border experience; lower costs than international operators | Reefer trucking in West Africa; cross-border permits; established routes | Local expertise; cost efficiency; established networks |
| ColdChainCo | Reefer Fleet | **International Leasing** | **Equipment Leasing Companies (Caterpillar, etc.)** | Major equipment manufacturers have African leasing arms; can provide modern reefer trucks; maintenance support; training | Equipment leasing across Africa; technical support; maintenance networks | Modern equipment; technical support; reliability |
| ColdChainCo | Reefer Fleet | **Local Cooperative Model** | **Transport Cooperatives / Owner-Driver Networks** | Lower capital requirement; local ownership; flexible operations; community benefit | Truck owner associations; cooperative models; established in West Africa | Local employment; lower costs; community integration |

---

## 3. GHANA TOMATO - SUPPORTING VC

### 3.1 PROCESSING FACILITIES - $8-15M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Ghana Tomato | Processing | **International Food Major (STRONGEST)** | **GBfoods Africa (Spain)** | GBfoods commissioned $5M Tema processing facility (2023); secured 2,428 hectares in Afram Plains (2026); produces Gino and Pomo brands; explicit "seed-to-shelf" strategy; called for import quotas to protect local industry | $5M Tema facility operational; 2,428 hectares secured (3x larger than Nigeria farm); yields improved to 60-70 tonnes/acre in Nigeria; 20 tonnes/acre in Ghana pilot; targeting 40 tonnes/acre | **STRONGEST CANDIDATE** - Already invested; expanding rapidly; committed to local production |
| Ghana Tomato | Processing | **Local Ghanaian Processor** | **Trusty Foods / Expom Ghana Ltd** | Trusty Foods established 2003 in Tema; supplies West African market; sources some Ghana tomatoes; predominantly imports bulk paste for repacking | Tema processing facility; West African market supply; 7% Ghana fresh tomatoes, 93% bulk paste imports; renamed Expom Ghana Ltd | Existing facility; market relationships; potential for expansion |
| Ghana Tomato | Processing | **Revived State Facility** | **Northern Star Tomato Company (Pwalugu)** | Former state tomato factory refurbished 2006-2007; reopened 2010; configured to supply Trusty Foods Tema; located in tomato-growing region | Pwalugu factory refurbishment; Ministry of Trade involvement; local tomato sourcing | Government support; located in production area; potential PPP |
| Ghana Tomato | Processing | **Private-Public Partnership** | **Afrique Link Ltd (Wenchi) / TOMACAN** | Former GIHOC cannery; produces natural tomato pulp and chopped tomatoes; niche market focus; exploring own high-tech farm | Wenchi location in production area; natural pulp/chopped tomatoes; South African technical expertise | Niche product positioning; local production focus |
| Ghana Tomato | Processing | **International Agribusiness** | **OLAM / SIFCA (if diversifying)** | Major West African agribusiness players; existing processing capabilities; regional distribution networks | OLAM: integrated supply chains; SIFCA: palm oil, rubber, sugar processing; established West Africa presence | Potential diversifiers; strong regional networks |

---

## 4. PALM OIL CIV - CONDITIONAL VC

### 4.1 MILLING UPGRADE - $5-10M

| Component | Sub-Component | Likely Operator Type | Specific Candidates | Rationale | Track Record | Strategic Fit |
|-----------|---------------|---------------------|---------------------|-----------|--------------|---------------|
| Palm Oil CIV | Milling Upgrade | **West Africa Palm Major (STRONGEST)** | **SIFCA Group / PalmCI (Cote d'Ivoire)** | SIFCA is West Africa's largest fully integrated palm player; 39,000 hectares industrial plantations; 27,000 village plantation planters; 10 palm oil mills; listed on BRVM; Wilmar has 27% stake | PalmCI: 60% of supply from private planters; comprehensive village plantation rehabilitation program; Dinor and Palme d'Or brands; leading UEMOA market share | **STRONGEST CANDIDATE** - Dominant CIV player; existing mill network; smallholder integration |
| Palm Oil CIV | Milling Upgrade | **International Palm Major** | **Wilmar International (Singapore)** | Wilmar has 27% strategic stake in SIFCA; sources from PalmCI mills; world's largest palm oil trader; African expansion strategy (recently acquired full ownership of Nigerian PZ Wilmar) | 27% SIFCA stake; PZ Wilmar full acquisition ($70M); 3 African refineries; 8 refineries through associates; committed to African palm development | Existing SIFCA relationship; capital for expansion; global market access |
| Palm Oil CIV | Milling Upgrade | **International Agribusiness** | **OLAM International (Singapore)** | OLAM has African palm operations (Gabon); joint venture with Wilmar (Nauvu Investments); 50:50 partnership for African palm, rubber, sugar | 64,000 hectares in Gabon; Nauvu JV with Wilmar; acquired 27% SIFCA stake; 50.5% of SIFCA refining business | Existing African palm presence; Wilmar partnership |
| Palm Oil CIV | Milling Upgrade | **Regional Palm Operator** | **Socfin Group (Luxembourg/Belgium)** | Socfin is major African palm player; operations in Cameroon, Cote d'Ivoire, Ghana, Liberia, Nigeria, Sierra Leone; 91,000+ hectares planted | 91,207 hectares across 7 African countries; 319,289 MT palm oil production; Socapalm in Cameroon; Plantation Socfinaf Ghana | Regional expertise; Cote d'Ivoire presence through SOGB |
| Palm Oil CIV | Milling Upgrade | **Cooperative/Outgrower Model** | **PalmCI Village Plantation Program Expansion** | PalmCI already works with 27,000 village planters; 60% of supply from private planters; rehabilitation program in place; could expand cooperative milling | 133,000 hectares village plantations; 27,000 planters; rehabilitation program (economic, material, technical support) | Smallholder integration; rural development; existing structure |

---

## SUMMARY: RECOMMENDED OPERATOR PRIORITIES

### Tier 1: Strongest Strategic Fit (Immediate Engagement)

| Component | Recommended Operator | Rationale |
|-----------|---------------------|-----------|
| **Hatchery** | ProDeCAP/AfDB + CNRA + WorldFish technical partnership | Public good mandate; existing funding; genetic expertise |
| **Feed** | De Heus/Koudijs (existing partnership) | Abidjan facility operational; partnership framework exists |
| **Anchor Farm** | Tropo Farms (Ghana) | Regional leader; explicit expansion interest; $10M AgDevCo backing |
| **Processing** | Integrated with Anchor Farm (Tropo/Yalelo) | Vertical integration ensures quality and traceability |
| **Border/Reefer** | AGL (MSC Group) | Existing cold infrastructure; port zone presence; border expertise |
| **Cold Hub Abidjan** | AGL + IPF partnership | Complementary capabilities; scale and expertise |
| **Cold Hub Seme-Krake** | AGL border logistics + Benin operator | Cross-border expertise; local knowledge |
| **Reefer Fleet** | EFAfrica (AgDevCo) + local operators | Equipment leasing expertise; local flexibility |
| **Ghana Tomato** | GBfoods Africa | Already invested; rapid expansion; committed to local production |
| **Palm Oil Milling** | SIFCA/PalmCI + Wilmar | Dominant CIV player; existing smallholder integration |

### Tier 2: Alternative/Backup Options

| Component | Alternative Operators |
|-----------|----------------------|
| Anchor Farm | Yalelo (Zambia), Victory Farms (Kenya), Lake Harvest (Zimbabwe) |
| Feed | Skretting (Nigeria expansion), Cargill/EWOS |
| Cold Chain | DP World, Kuehne+Nagel, DHL |
| Tomato Processing | Trusty Foods/Expom, Northern Star (PPP) |
| Palm Oil | Socfin (regional), OLAM (Gabon expertise) |

---

## KEY STRATEGIC PARTNERSHIPS TO LEVERAGE

1. **DFI Consortium**: AfDB (lead) + Finnfund + Norfund + IFC + AgDevCo
2. **Feed Partnership**: De Heus/Koudijs (existing)
3. **Technical Genetics**: WorldFish GIFT program
4. **Government Programs**: PSTACI (30 ZEAD zones) + ProDeCAP ($25.6M)
5. **Research**: CNRA (Cote d'Ivoire) + FISH4ACP
6. **Logistics**: AGL/MSC + DP World
7. **Regional Offtakers**: Lagos wholesale distributors (2-3 identified)

---

*Analysis prepared for AFSTI Dakar-Lagos Corridor Play*
*Based on publicly available information as of research date*
